import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { BillsService } from '../../services/common/bills/bills.service';

@Component({
  selector: 'app-view-bills',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './view-bills.component.html',
  styleUrl: './view-bills.component.css'
})
export class ViewBillsComponent {

  constructor(
    public billsService: BillsService,
    private router: Router
  ) {}

  get totalPayable(): number {
  return this.billsService.bills
    .filter(b => b.selected)
    .reduce((sum, b) => sum + b.dueAmount, 0);
}


  proceedToPay() {
  this.router.navigate(['/bill-summary']);
}

}


