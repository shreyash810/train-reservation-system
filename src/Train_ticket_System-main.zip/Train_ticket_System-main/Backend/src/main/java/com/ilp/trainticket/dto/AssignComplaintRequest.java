
package com.ilp.trainticket.dto;

public class AssignComplaintRequest {
 public Long complaintId;
 public Long staffId;
}
