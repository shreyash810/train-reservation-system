
package com.ilp.trainticket.dto;

public class ComplaintRequest {
 public Long passengerId;
 public String category;
 public String title;
 public String description;
}
