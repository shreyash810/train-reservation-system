
package com.ilp.trainticket.dto;

public class LoginRequest {
    public String email;
    public String password;
}
