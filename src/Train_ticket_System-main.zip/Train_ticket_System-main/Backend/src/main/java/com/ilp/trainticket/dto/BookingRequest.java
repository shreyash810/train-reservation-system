
package com.ilp.trainticket.dto;

import java.time.LocalDate;

public class BookingRequest {
 public Long passengerId;
 public Long trainId;
 public LocalDate travelDate;
}
