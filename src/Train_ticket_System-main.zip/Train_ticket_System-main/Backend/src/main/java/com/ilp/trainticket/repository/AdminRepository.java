
package com.ilp.trainticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ilp.trainticket.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, Long> {}
