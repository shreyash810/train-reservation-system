
package com.ilp.trainticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ilp.trainticket.entity.Staff;

public interface StaffRepository extends JpaRepository<Staff, Long> {}
