
package com.ilp.trainticket.dto;

public class TrainRequest {
 public String trainNumber;
 public String trainName;
 public String origin;
 public String destination;
 public int totalSeats;
}
