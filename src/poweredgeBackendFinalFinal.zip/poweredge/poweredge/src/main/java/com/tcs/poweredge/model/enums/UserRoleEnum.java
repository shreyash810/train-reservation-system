package com.tcs.poweredge.model.enums;

public enum UserRoleEnum {
    CUSTOMER,
    ADMIN,
    SME
}
