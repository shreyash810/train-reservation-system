package com.tcs.poweredge.dto;


import com.tcs.poweredge.model.enums.ConnectionStatus;
import com.tcs.poweredge.model.enums.ConnectionType;
import com.tcs.poweredge.model.enums.PaymentStatus;

import jakarta.validation.constraints.Pattern;
import lombok.*;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BillListForCustomer {

    // Optional filters
    private Long billId;

    // Exact "YYYY-MM" format (e.g., 2025-12)
    @Pattern(regexp = "^[0-9]{4}-[0-9]{2}$", message = "billingPeriod must be in 'YYYY-MM' format")
    private String billingPeriod;

    private PaymentStatus paymentStatus;
    private ConnectionType connectionType;
    private ConnectionStatus connectionStatus;
}
