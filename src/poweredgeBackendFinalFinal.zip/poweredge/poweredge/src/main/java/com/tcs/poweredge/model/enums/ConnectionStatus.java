package com.tcs.poweredge.model.enums;


public enum ConnectionStatus {
    CONNECTED, DISCONNECTED
}

