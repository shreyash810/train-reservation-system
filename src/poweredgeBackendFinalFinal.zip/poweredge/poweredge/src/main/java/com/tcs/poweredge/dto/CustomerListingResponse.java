
package com.tcs.poweredge.dto;

import com.tcs.poweredge.model.enums.CustomerTypeEnum;
import com.tcs.poweredge.model.enums.ElectricalSectionEnum;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for customer listing view.
 * Mirrors fields needed for list screens and avoids exposing relations.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerListingResponse {

    private Long customerId;

    /**
     * String representation like RES000001 / COM000123, sourced from Customer#getRefinedCustomerId().
     */
    private String refinedCustomerId;

    /**
     * Note: Field name intentionally matches the entity field (cousumerNumber).
     */
    private String cousumerNumber;

    private String fname;
    private String lname;
    private String address;
    private String mobileNumber;

    private ElectricalSectionEnum electricalSection;
    private CustomerTypeEnum customerType;
}