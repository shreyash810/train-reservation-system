package com.tcs.poweredge.dto;


import com.tcs.poweredge.model.enums.CustomerTypeEnum;
import com.tcs.poweredge.model.enums.ElectricalSectionEnum;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class RegisterRequest {
    @NotBlank(message = "Username is required")
    @Size(min = 3, max = 50, message = "Username must be 3–50 characters")
    private String username;

    @NotBlank(message = "Password is required")
    @Size(min = 8, max = 100, message = "Password must be at least 8 characters")
    private String password;

    @NotBlank(message = "Email is required")
    @Email(message = "Email must be valid")
    private String email;

    @Size(max = 100, message = "at most 100 characters")
    @NotBlank(message = "consumer number is required")
    private String cousumerNumber;
    
    @Size(max = 100, message = "First name must be at most 100 characters")
    private String fname;

    @Size(max = 100, message = "Last name must be at most 100 characters")
    private String lname;

    @Size(max = 255, message = "Address must be at most 255 characters")
    private String address;

    
    @Size(max = 15, message = "Mobile number must be at most 15 characters")
    private String mobileNumber;

    private ElectricalSectionEnum electricalSection;

    private CustomerTypeEnum customerType;


}


    