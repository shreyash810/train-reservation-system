
package com.tcs.poweredge.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for listing SMEs for admin view.
 * Mirrors scalar fields from Sme entity; avoids exposing relations (e.g., User).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SmeListingResponse {

    private Long smeId;

    private String username;

    private String fname;

    private String lname;

    private String mobileNumber;

    private Long userId;

    private String email;
}
