package com.tcs.poweredge.mapper;

import org.springframework.stereotype.Component;

import com.tcs.poweredge.dto.RegisterRequest;
import com.tcs.poweredge.model.Customer;

@Component
public class CustomerMapper {
    
    public Customer toEntity(RegisterRequest request){
        Customer customer = new Customer();
        
        customer.setFname(request.getFname());
        customer.setLname(request.getLname());
        customer.setAddress(request.getAddress());
        customer.setMobileNumber(request.getMobileNumber());
        customer.setElectricalSection(request.getElectricalSection());
        customer.setCustomerType(request.getCustomerType());
        customer.setCousumerNumber(request.getCousumerNumber());
        return customer;
    } 
}
