package com.tcs.poweredge.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.poweredge.security.UserDetailsImpl;

@RestController
@RequestMapping("/test")
public class testToCheckAuthorization {
    @GetMapping("/users")
    @PreAuthorize("hasRole('CUSTOMER')")
    public String listUsers(
        Authentication authentication
    ) {
        UserDetailsImpl admin = (UserDetailsImpl) authentication.getPrincipal();
        // Print admin username and email
        return "Customer: " + admin.getUsername() + " (" + admin.getEmail() + ")";
    }
}
