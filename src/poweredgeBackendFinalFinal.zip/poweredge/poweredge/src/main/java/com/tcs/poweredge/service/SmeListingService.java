
package com.tcs.poweredge.service;

import java.util.Collections;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.poweredge.dto.SmeListingResponse;
import com.tcs.poweredge.model.Sme;
import com.tcs.poweredge.repository.SmeRepository;

@Service
@Transactional(readOnly = true)
public class SmeListingService {

    private final SmeRepository smeRepository;

    public SmeListingService(final SmeRepository smeRepository) {
        this.smeRepository = smeRepository;
    }

    /**
     * Get SMEs with optional filter by smeId.
     * - If smeId is provided, returns a single-element page (or empty page if not found).
     * - If smeId is null, returns the standard paged list of all SMEs.
     */
    public Page<SmeListingResponse> getSmes(Long smeId, Pageable pageable) {
        if (smeId != null) {
            return smeRepository.findById(smeId)
                    .map(this::toSmeListingResponse)
                    .map(dto -> new PageImpl<>(Collections.singletonList(dto), pageable, 1))
                    .orElseGet(() -> new PageImpl<>(Collections.emptyList(), pageable, 0));
        }

        // No filter -> full paginated list
        return smeRepository.findAll(pageable)
                .map(this::toSmeListingResponse);
    }

    // --- Existing method kept (optional). You may remove if not used elsewhere. ---
    public Page<SmeListingResponse> getSmes(Pageable pageable) {
        return smeRepository.findAll(pageable)
                .map(this::toSmeListingResponse);
    }

    // --- Mapping ---
    private SmeListingResponse toSmeListingResponse(Sme sme) {
        return SmeListingResponse.builder()
                .smeId(sme.getSmeId())
                .fname(sme.getFname())
                .lname(sme.getLname())
                .mobileNumber(sme.getMobileNumber())
                .userId(sme.getUser().getId())
                .email(sme.getUser().getEmail())
                .username(sme.getUser().getUsername())
                .build();
    }
}
