package com.tcs.poweredge.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

import com.tcs.poweredge.model.enums.ComplaintCategory;
import com.tcs.poweredge.model.enums.ComplaintStatus;
import com.tcs.poweredge.model.enums.ComplaintType;
import com.tcs.poweredge.model.enums.PreferredContactMethod;

@Entity
@Table(
    name = "complaints",
    indexes = {
        @Index(name = "idx_complaints_status", columnList = "status"),
        @Index(name = "idx_complaints_date_submitted", columnList = "dateSubmitted"),
        @Index(name = "idx_complaints_assigned_to", columnList = "assigned_to_user_id")
    }
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Complaint {

    // PK: complaint_id
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "complaint_id")
    private Long complaintId;

    // FK: customer_id -> CUSTOMER.customer_id
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    // Complaint type (e.g., BILLING_ISSUE, POWER_OUTAGE)
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "complaint_type", length = 50)
    private ComplaintType complaintType;

    // Category: derived by type (stored for querying)
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "category", length = 50)
    private ComplaintCategory category;

    // Description: TEXT, required
    @NotBlank
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    // Preferred contact method
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "preferred_contact_method", length = 10)
    private PreferredContactMethod preferredContactMethod;

    // Editable contact details; default from CUSTOMER/USER
    @Email
    @Size(max = 255)
    @Column(name = "contact_email")
    private String contactEmail;

    @Size(max = 15)
    @Column(name = "contact_phone")
    private String contactPhone;

    // Submitted/updated timestamps
    @Column(name = "date_submitted", nullable = false)
    private LocalDateTime dateSubmitted;

    // Status: OPEN/IN_PROGRESS/RESOLVED/CLOSED
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20)
    private ComplaintStatus status;

    @Column(name = "last_updated_date", nullable = false)
    private LocalDateTime lastUpdatedDate;

    // Notes: TEXT (status change notes)
    @Column(name = "notes", columnDefinition = "TEXT")
    private String notes;

    // Assignee: FK to USER.id (ADMIN/SME)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_to_user_id", referencedColumnName = "id")
    private User assignedTo;

    // Lifecycle hooks for defaults and timestamps
    @PrePersist
    protected void onCreate() {
        this.dateSubmitted = LocalDateTime.now();
        this.lastUpdatedDate = LocalDateTime.now();

        // Derive category from complaintType
        if (this.complaintType != null) {
            this.category = ComplaintCategory.fromType(this.complaintType);
        }

        // Default status
        if (this.status == null) {
            this.status = ComplaintStatus.OPEN;
        }

        // Default contact details from Customer/User if not provided
        if (this.contactPhone == null && this.customer != null) {
            this.contactPhone = this.customer.getMobileNumber();
        }
        if (this.contactEmail == null && this.customer != null && this.customer.getUser() != null) {
            this.contactEmail = this.customer.getUser().getEmail();
        }

        // Default preferred contact method based on availability
        if (this.preferredContactMethod == null) {
            this.preferredContactMethod = (this.contactEmail != null)
                    ? PreferredContactMethod.EMAIL
                    : PreferredContactMethod.PHONE;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        this.lastUpdatedDate = LocalDateTime.now();

        // Keep category in sync if type changes
        if (this.complaintType != null) {
            this.category = ComplaintCategory.fromType(this.complaintType);
        }
    }
}
