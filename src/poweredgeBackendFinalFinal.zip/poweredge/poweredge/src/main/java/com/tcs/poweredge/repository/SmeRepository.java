package com.tcs.poweredge.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcs.poweredge.model.Sme; 

@Repository
public interface SmeRepository extends JpaRepository<Sme,Long> {
    
    Optional<Sme> findByMobileNumber(String mobileNumber);

    // Common helpers (non-breaking and useful)
    boolean existsByMobileNumber(String mobileNumber);

    Optional<Sme> findByUserUsername(String username);


}
