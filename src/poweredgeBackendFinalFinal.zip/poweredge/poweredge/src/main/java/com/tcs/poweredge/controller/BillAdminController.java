package com.tcs.poweredge.controller;


import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.tcs.poweredge.dto.BillDTO;
import com.tcs.poweredge.dto.BillListForCustomer;
import com.tcs.poweredge.dto.BillListRequest;
import com.tcs.poweredge.dto.CreateBillRequest;
import com.tcs.poweredge.dto.PaymentCreateRequest;
import com.tcs.poweredge.dto.PaymentResponse;
import com.tcs.poweredge.service.BillService;
import com.tcs.poweredge.service.PaymentService;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import org.springframework.security.core.Authentication;

import com.tcs.poweredge.security.UserDetailsImpl;



@RestController
@RequestMapping("/api/bills")
@RequiredArgsConstructor
public class BillAdminController {

    private final BillService billService;
    private final PaymentService paymentService;

    // POST /api/admin/customers/{customerId}/bills
    @PostMapping("/admin/customers/{customerId}/bills")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BillDTO> createBill(    
        Authentication authentication,    
        @PathVariable("customerId") Long customerId,
        @Valid @RequestBody CreateBillRequest request
    ) throws Exception {

        BillDTO dto = billService.createBillForCustomer(customerId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }

    
    @GetMapping("/admin/bills")
    @PreAuthorize("hasRole('ADMIN')")
    public Page<BillDTO> listBills(
            Authentication authentication,  
            @Valid @ModelAttribute BillListRequest request,
            @PageableDefault(size = 20, sort = "dueDate") Pageable pageable
    ) {
        return billService.listBillsForAdmin(request, pageable);
    }

    @GetMapping("/customer/me/bills")
    @PreAuthorize("hasRole('CUSTOMER')")
    public Page<BillDTO> listBillsforCustomer(
            Authentication authentication,
            @Valid @ModelAttribute BillListForCustomer request,
            @PageableDefault(size = 20, sort = "dueDate") Pageable pageable
    ) throws Exception {
        UserDetailsImpl user = (UserDetailsImpl) authentication.getPrincipal();
        Long userId = user.getId();
        return billService.listBillsForCustomer(request, userId, pageable);
    }


    
    @PostMapping("/payment")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<PaymentResponse> create(
            @Valid @RequestBody PaymentCreateRequest request,
            Authentication authentication) throws Exception {
        UserDetailsImpl user = (UserDetailsImpl) authentication.getPrincipal();
        Long userId = user.getId();

        PaymentResponse response = paymentService.createPayment(request, userId);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

}
