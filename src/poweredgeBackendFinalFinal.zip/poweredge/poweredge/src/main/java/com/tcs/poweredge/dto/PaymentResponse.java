package com.tcs.poweredge.dto;



import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.tcs.poweredge.model.enums.ModeOfPayment;
import com.tcs.poweredge.model.enums.TransactionStatus;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentResponse {
    private Long paymentId;
    private String transactionId;
    private LocalDateTime transactionDate;
    private BigDecimal transactionAmount;
    private TransactionStatus transactionStatus;
    private ModeOfPayment modeOfPayment;
    private Long billId;
    private Long customerId;
    private LocalDateTime createdAt;
}

