package com.tcs.poweredge.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcs.poweredge.model.Customer;
import com.tcs.poweredge.model.enums.CustomerTypeEnum;
import com.tcs.poweredge.model.enums.ElectricalSectionEnum;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    boolean existsByMobileNumber(String mobileNumber);
    Optional<Customer> findByUserUsername(String username);

    // --- Pagination is already supported via inherited method:
    // Page<Customer> findAll(Pageable pageable);

    // --- Filtering + Pagination ---

    /**
     * Filter customers by Electrical Section with pagination.
     */
    Page<Customer> findByElectricalSection(ElectricalSectionEnum electricalSection, Pageable pageable);

    /**
     * Filter customers by Customer Type with pagination.
     */
    Page<Customer> findByCustomerType(CustomerTypeEnum customerType, Pageable pageable);

    /**
     * Filter customers by both Electrical Section and Customer Type with pagination.
     */
    Page<Customer> findByElectricalSectionAndCustomerType(
            ElectricalSectionEnum electricalSection,
            CustomerTypeEnum customerType,
            Pageable pageable
    );
}

