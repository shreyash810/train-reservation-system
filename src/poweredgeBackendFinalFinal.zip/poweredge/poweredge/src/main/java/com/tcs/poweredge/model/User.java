package com.tcs.poweredge.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


import com.tcs.poweredge.model.enums.UserRoleEnum;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String password;
    private String email;

    @Enumerated(EnumType.STRING)
    private UserRoleEnum role;

    @OneToOne(fetch = FetchType.LAZY , cascade = CascadeType.ALL, optional = true)
    @JoinColumn(name = "customer_id" , unique = true , nullable = true)
    private Customer customer;

    @OneToOne(fetch = FetchType.LAZY , cascade = CascadeType.ALL, optional = true)
    @JoinColumn(name = "sme_id" , unique = true , nullable = true)
    private Sme sme;

    
    @OneToMany(mappedBy = "assignedTo", fetch = FetchType.LAZY)
    private List<Complaint> complaintsAssigned = new ArrayList<>();


    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}

