package com.tcs.poweredge.model.enums;

public enum ModeOfPayment {
    UPI, CARD, NETBANKING, WALLET, CASH
}
