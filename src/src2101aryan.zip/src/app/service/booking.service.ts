import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AdminBookingListDTO } from '../dtos/admin-booking-list.dto';
import { BookingResponse } from '../model/booking-response.model';
import { Booking } from '../model/booking.model';

@Injectable({ providedIn: 'root' })
export class AdminBookingService {

  private baseUrl = 'http://localhost:8080/admin/bookings';

  constructor(private http: HttpClient) {}

  // 1️⃣ Get all bookings

getAllBookings(): Observable<AdminBookingListDTO[]> {
  return this.http.get<AdminBookingListDTO[]>(
    `${this.baseUrl}`
  );
}

createBooking(payload: any) {
  return this.http.post<BookingResponse>(
    'create',
    payload
  );
}


  // 3️⃣ Update booking
  updateBooking(
    bookingId: string,
    payload: { roomId: string; fromDate: string; toDate: string }
  ) {
    return this.http.put(`${this.baseUrl}/update/${bookingId}`, payload);
  }

  // 4️⃣ Cancel booking
  cancelBooking(bookingId: string) {
    return this.http.post(`${this.baseUrl}/cancel/${bookingId}`, {});
  }
}
