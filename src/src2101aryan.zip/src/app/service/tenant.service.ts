import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class TenantService {

  private baseUrl = 'http://localhost:8080';

  constructor(private http: HttpClient) {}

  getTenants() {
    return this.http.get<any[]>(`${this.baseUrl}/list`);
  }

  createTenant(payload: any) {
  return this.http.post(
    `${this.baseUrl}/create`,
    payload,
    { responseType: 'text' }   // ⭐ IMPORTANT
  );
}


  updateTenant(payload: any) {
  return this.http.put(
    `${this.baseUrl}/update`,
    payload,
    { responseType: 'text' }   // ⭐ IMPORTANT
  );
}


  toggleStatus(userId: string) {
  return this.http.post(
    `${this.baseUrl}/admin/user/status`,
    { userId },
    { responseType: 'text' }
  );
}



  resetPassword(userId: string) {
    return this.http.post(
      `${this.baseUrl}/reset-password`,
      { userId },
      { responseType: 'text' }
    );
  }
}
