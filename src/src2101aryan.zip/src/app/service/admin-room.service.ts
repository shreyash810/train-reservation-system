import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Room } from '../model/room.model';
import { AddRoomRequest } from '../dtos/add-room.dto';
import { RoomUpdateRequest } from '../dtos/room-update.dto';

@Injectable({ providedIn: 'root' })
export class AdminRoomService {

  private BASE_URL = 'http://localhost:8080/admin/rooms';

  constructor(private http: HttpClient) {}

  // US14 – Fetch all rooms
  getAllRooms() {
    return this.http.get<Room[]>(`${this.BASE_URL}`);
  }

  // US15 

  // US14 – Update room
  updateRoom(roomId: string, payload: any) {
  return this.http.put(
    `http://localhost:8080/admin/rooms/update/${roomId}`,
    payload,
    { responseType: 'text' }   // 👈 VERY IMPORTANT
  );
}

addRoom(payload: {
  roomType: string;
  pricePerDay: number;
  availability: boolean;
  amenities: string[];
  description?: string;
}) {
  return this.http.post(
    'http://localhost:8080/admin/rooms/add',
    payload
  );
}

}
