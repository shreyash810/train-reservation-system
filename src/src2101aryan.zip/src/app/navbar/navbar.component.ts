
import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ProfileComponent } from '../profile/profile.component';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  imports: [RouterLink],
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  // Static personalized welcome. Change as needed.
  adminName = 'Aryan Murali';

  constructor(private router: Router) {}

  goHome() {
    this.router.navigateByUrl('/admin');
  }

  goProfile() {
    this.router.navigateByUrl('/profile');
  }

  logout() {
    // Static behavior for now: just navigate to not-authorized.
    // (No localStorage clearing until auth is wired in.)
    this.router.navigateByUrl('/not-authorized');
  }
}
``
