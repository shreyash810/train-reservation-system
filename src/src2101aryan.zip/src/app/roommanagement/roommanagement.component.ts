import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AdminRoomService } from '../service/admin-room.service';

/* =======================
   TYPES (MATCH HTML)
======================= */
type Amenity = 'Internet' | 'HouseKeeping' | 'Meals' | 'Parking' | 'AC';
type RoomStatus = 'Available' | 'Occupied' | 'Under Maintenance';
type RoomType = 'Shared' | 'Single' | 'Double' | 'Deluxe' | 'Suite';

type Room = {
  roomId: string;
  roomNo: number;
  type: RoomType;
  price: number;
  status: RoomStatus;
  amenities: Amenity[];
  isEditing?: boolean;
};

@Component({
  selector: 'app-roommanagement',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './roommanagement.component.html',
  styleUrls: ['./roommanagement.component.css']
})
export class RoomManagementComponent implements OnInit {

  constructor(private adminRoomService: AdminRoomService) {}

  /* =======================
     FILTERS / SORT / PAGINATION
  ======================= */
  search = '';
  filterRoomType: RoomType | '' = '';
  priceMin: number | null = null;
  priceMax: number | null = null;
  filterAvailabilityToday: '' | 'Available' | 'Not Available' = '';
  amenitiesFilter: Amenity[] = [];
  availableFrom = '';
  availableTo = '';

  sortColumn: keyof Room | 'availabilityLabel' = 'roomNo';
  sortDir: 'asc' | 'desc' = 'asc';

  pageSize = 10;
  currentPage = 1;

  successMessage = '';

  amenityOptions: Amenity[] = [
    'Internet',
    'HouseKeeping',
    'Meals',
    'Parking',
    'AC'
  ];

  // ==========================
// ADD ROOM FORM
// ==========================
showAddRoomForm = false;

newRoom = {
  roomType: '',
  pricePerDay: 0,
  availability: true,
  amenities: [] as Amenity[],
  description: ''
};


  /* =======================
     DATA
  ======================= */
  rooms: Room[] = [];

  private editBuffer: Record<number, Room> = {};

  /* =======================
     INIT (SAFE)
  ======================= */
  ngOnInit(): void {
    console.log('RoomManagementComponent loaded');
    this.loadRooms();
  }

  loadRooms(): void {
    this.adminRoomService.getAllRooms().subscribe({
      next: (data: any[]) => {
        if (!Array.isArray(data)) {
          console.error('Invalid room response', data);
          this.rooms = [];
          return;
        }

        this.rooms = data.map(br => this.mapBackendRoom(br));
      },
      error: (err) => {
        console.error('Failed to load rooms', err);
        this.rooms = [];
      }
    });
  }

  /* =======================
     BACKEND → UI MAPPER
  ======================= */
  private mapBackendRoom(br: any): Room {
    return {
      roomId: br.roomId,
      roomNo: Number((br.roomNumber || '0').replace(/\D/g, '')),
      type: br.roomType,
      price: br.pricePerDay,
      status: br.availability ? 'Available' : 'Occupied',
      amenities: br.amenities ?? [],
      isEditing: false
    };
  }

  /* =======================
     AVAILABILITY
  ======================= */
  availabilityLabel(room: Room): 'Available' | 'Not Available' {
    return room.status === 'Available' ? 'Available' : 'Not Available';
  }

  /* =======================
     FILTER + SORT
  ======================= */
  get processedRooms(): Room[] {
    let list = [...this.rooms];

    const q = this.search.toLowerCase().trim();
    if (q) {
      list = list.filter(r =>
        r.roomNo.toString().includes(q) ||
        r.type.toLowerCase().includes(q)
      );
    }

    if (this.filterRoomType) {
      list = list.filter(r => r.type === this.filterRoomType);
    }

    if (this.priceMin !== null) list = list.filter(r => r.price >= this.priceMin!);
    if (this.priceMax !== null) list = list.filter(r => r.price <= this.priceMax!);

    if (this.filterAvailabilityToday) {
      list = list.filter(r => this.availabilityLabel(r) === this.filterAvailabilityToday);
    }

    if (this.amenitiesFilter.length > 0) {
      list = list.filter(r =>
        this.amenitiesFilter.every(a => r.amenities.includes(a))
      );
    }

    list.sort((a, b) => {
      const A: any = this.sortColumn === 'availabilityLabel'
        ? this.availabilityLabel(a)
        : a[this.sortColumn];

      const B: any = this.sortColumn === 'availabilityLabel'
        ? this.availabilityLabel(b)
        : b[this.sortColumn];

      return this.sortDir === 'asc'
        ? (typeof A === 'number' ? A - B : String(A).localeCompare(String(B)))
        : (typeof A === 'number' ? B - A : String(B).localeCompare(String(A)));
    });

    return list;
  }

  /* =======================
     PAGINATION
  ======================= */
  get totalPages(): number {
    return Math.max(1, Math.ceil(this.processedRooms.length / this.pageSize));
  }

  get pages(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  get pagedRooms(): Room[] {
    const start = (this.currentPage - 1) * this.pageSize;
    return this.processedRooms.slice(start, start + this.pageSize);
  }

  goToPage(p: number) {
    if (p < 1 || p > this.totalPages) return;
    this.currentPage = p;
  }

  setSort(col: keyof Room | 'availabilityLabel') {
    if (this.sortColumn === col) {
      this.sortDir = this.sortDir === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = col;
      this.sortDir = 'asc';
    }
  }

  resetFilters() {
    this.search = '';
    this.filterRoomType = '';
    this.priceMin = null;
    this.priceMax = null;
    this.filterAvailabilityToday = '';
    this.amenitiesFilter = [];
    this.availableFrom = '';
    this.availableTo = '';
    this.currentPage = 1;
  }

  onAmenityFilterChange(amenity: Amenity, event: Event) {
  const checked = (event.target as HTMLInputElement).checked;

  if (checked) {
    if (!this.amenitiesFilter.includes(amenity)) {
      this.amenitiesFilter = [...this.amenitiesFilter, amenity];
    }
  } else {
    this.amenitiesFilter = this.amenitiesFilter.filter(a => a !== amenity);
  }

  this.currentPage = 1; // reset pagination after filter
}


  /* =======================
     EDITING
  ======================= */
  startEdit(room: Room) {
    if (room.status === 'Occupied') {
      alert('Occupied rooms cannot be updated');
      return;
    }
    room.isEditing = true;
    this.editBuffer[room.roomNo] = { ...room };
  }

  updateField(room: Room, key: keyof Room, value: any) {
    if (key === 'price') {
      room.price = Number(value);
      return;
    }
    (room as any)[key] = value;
  }

  toggleAmenity(room: Room, amenity: Amenity) {
    room.amenities = room.amenities.includes(amenity)
      ? room.amenities.filter(a => a !== amenity)
      : [...room.amenities, amenity];
  }

  save(room: Room) {
    if (room.price <= 0) {
      alert('Price must be positive');
      return;
    }

    const payload = {
      roomType: room.type,
      pricePerDay: room.price,
      availability: room.status === 'Available',
      amenities: room.amenities
    };

    this.adminRoomService.updateRoom(room.roomId, payload).subscribe({
      next: () => {
        room.isEditing = false;
        delete this.editBuffer[room.roomNo];
        this.successMessage = `rooms<${room.roomNo}> details are updated successfully.`;
        setTimeout(() => this.successMessage = '', 4000);
      },
      error: (err) => {
  console.error(err);
  alert(err.error?.message || 'Update failed');
  this.cancel(room);
}

    });
  }

  cancel(room: Room) {
    const backup = this.editBuffer[room.roomNo];
    if (backup) Object.assign(room, backup);
    room.isEditing = false;
    delete this.editBuffer[room.roomNo];
  }

  openAddRoom() {
  this.showAddRoomForm = true;
}

closeAddRoom() {
  this.showAddRoomForm = false;
  this.resetAddRoomForm();
}

resetAddRoomForm() {
  this.newRoom = {
    roomType: '',
    pricePerDay: 0,
    availability: true,
    amenities: [],
    description: ''
  };
}

toggleAddAmenity(a: Amenity) {
  this.newRoom.amenities = this.newRoom.amenities.includes(a)
    ? this.newRoom.amenities.filter(x => x !== a)
    : [...this.newRoom.amenities, a];
}

submitAddRoom() {
  if (!this.newRoom.roomType || this.newRoom.pricePerDay <= 0) {
    alert('Room Type and valid Price are required');
    return;
  }

  this.adminRoomService.addRoom(this.newRoom).subscribe({
    next: (res: any) => {
      this.successMessage = res.message || 'Room added successfully';
      this.closeAddRoom();
      this.loadRooms(); // 🔄 refresh list
      setTimeout(() => (this.successMessage = ''), 4000);
    },
    error: (err) => {
      alert(err.error?.message || 'Failed to add room');
    }
  });
}

}


