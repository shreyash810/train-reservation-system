
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

type AdminProfile = {
  name: string;
  email: string;
  role: 'admin' | 'staff' | 'viewer';
};

@Component({
  selector: 'app-profile',
  imports: [CommonModule, FormsModule],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {
  profile: AdminProfile = {
    name: 'Aryan Murali',
    email: 'aryan@example.com',
    role: 'admin'
  };

  editModel: AdminProfile = { ...this.profile };

  isEditing = false;
  message = '';

  constructor(private router: Router) {}

  startEdit() {
    this.editModel = { ...this.profile };
    this.isEditing = true;
    this.message = '';
  }

  cancelEdit() {
    this.isEditing = false;
    this.message = '';
  }

  saveProfile() {
    if (!this.editModel.name.trim()) {
      this.message = 'Name is required.';
      return;
    }
    if (!this.isValidEmail(this.editModel.email)) {
      this.message = 'Please enter a valid email.';
      return;
    }

    this.profile = { ...this.editModel };
    this.isEditing = false;
    this.message = 'Profile updated (static, no persistence).';
  }

  logout() {
    this.router.navigateByUrl('/not-authorized');
  }

  private isValidEmail(email: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }
}
