import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AdminBookingService } from '../service/booking.service';
import { AdminBookingListDTO } from '../dtos/admin-booking-list.dto';
import { Booking } from '../model/booking.model';

@Component({
  selector: 'app-bookingmanagement',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bookingmanagement.component.html',
  styleUrls: ['./bookingmanagement.component.css']
})
export class BookingManagementComponent implements OnInit {

  constructor(private bookingService: AdminBookingService) {}

  bookings: Booking[] = [];

  search = '';
  filterStatus = '';
  dateFrom = '';
  dateTo = '';

  sortColumn: keyof Booking = 'startDate';
  sortDir: 'asc' | 'desc' = 'asc';

  pageSize = 10;
  currentPage = 1;
  successMessage = '';

  newBooking = {
    tenantId: '',
    roomId: '',
    startDate: '',
    endDate: '',
    paymentMethod: 'CREDIT_CARD'
  };

  ngOnInit(): void {
    this.loadBookings();
  }

  loadBookings() {
    this.bookingService.getAllBookings().subscribe({
      next: (data: AdminBookingListDTO[]) => {
        this.bookings = data.map(b => ({
          id: b.bookingId,
          roomId: b.roomId,
          roomNo: b.roomNumber,
          tenantName: b.tenantName,
          startDate: b.fromDate,
          endDate: b.toDate,
          status: b.status,
          totalAmount: b.totalAmount,
          isEditing: false
        }));
      },
      error: () => alert('Failed to load bookings')
    });
  }

  get processedBookings(): Booking[] {
    let list = [...this.bookings];

    if (this.search) {
      const q = this.search.toLowerCase();
      list = list.filter(b =>
        b.id.toLowerCase().includes(q) ||
        b.tenantName.toLowerCase().includes(q)
      );
    }

    if (this.filterStatus) {
      list = list.filter(b => b.status === this.filterStatus);
    }

    if (this.dateFrom) list = list.filter(b => b.endDate >= this.dateFrom);
    if (this.dateTo) list = list.filter(b => b.startDate <= this.dateTo);

    list.sort((a, b) =>
      this.sortDir === 'asc'
        ? String(a[this.sortColumn]).localeCompare(String(b[this.sortColumn]))
        : String(b[this.sortColumn]).localeCompare(String(a[this.sortColumn]))
    );

    return list;
  }

  get pagedBookings() {
    const start = (this.currentPage - 1) * this.pageSize;
    return this.processedBookings.slice(start, start + this.pageSize);
  }

  get totalPages() {
    return Math.max(1, Math.ceil(this.processedBookings.length / this.pageSize));
  }

  get pages() {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  goToPage(p: number) {
    if (p >= 1 && p <= this.totalPages) this.currentPage = p;
  }

  setSort(col: keyof Booking) {
    this.sortDir =
      this.sortColumn === col && this.sortDir === 'asc' ? 'desc' : 'asc';
    this.sortColumn = col;
  }

  resetFilters() {
    this.search = '';
    this.filterStatus = '';
    this.dateFrom = '';
    this.dateTo = '';
    this.currentPage = 1;
  }

  startEdit(b: Booking) {
    b.isEditing = true;
  }

save(b: Booking) {
  this.bookingService.updateBooking(b.id, {
    roomId: b.roomId,
    fromDate: b.startDate,
    toDate: b.endDate
  }).subscribe({
    next: () => {
      this.successMessage = `Booking ${b.id} updated successfully`;

      // 🔥 THIS IS THE KEY LINE
      this.loadBookings();      

      setTimeout(() => this.successMessage = '', 3000);
    },
    error: err => alert(err.error?.message || 'Update failed')
  });
}



  cancelEdit(b: Booking) {
    b.isEditing = false;
    this.loadBookings();
  }

  cancelBooking(b: Booking) {
    if (!confirm(`Cancel booking ${b.id}?`)) return;

    this.bookingService.cancelBooking(b.id).subscribe({
      next: () => {
        b.status = 'CANCELLED';
        this.successMessage = `Booking ${b.id} cancelled`;
        setTimeout(() => this.successMessage = '', 3000);
      },
      error: err => alert(err.error?.message)
    });
  }

  addBooking() {
    this.bookingService.createBooking({
      userId: this.newBooking.tenantId,
      roomId: this.newBooking.roomId,
      fromDate: this.newBooking.startDate,
      toDate: this.newBooking.endDate,
      paymentMethod: this.newBooking.paymentMethod
    }).subscribe({
      next: () => {
        this.successMessage = 'Booking created successfully';
        this.loadBookings();
        this.resetNewBooking();
        setTimeout(() => this.successMessage = '', 4000);
      },
      error: err => alert(err.error?.message || 'Creation failed')
    });
  }

  resetNewBooking() {
    this.newBooking = {
      tenantId: '',
      roomId: '',
      startDate: '',
      endDate: '',
      paymentMethod: 'CREDIT_CARD'
    };
  }

  removeBooking(id: string) {
    if (!confirm(`Remove booking ${id}?`)) return;
    this.bookings = this.bookings.filter(b => b.id !== id);
  }
}
