export interface AdminBookingListDTO {
  bookingId: string;
  roomId: string;
  tenantName: string;
  roomNumber: string;
  fromDate: string;
  toDate: string;
  status: string;
  totalAmount: number;
}
