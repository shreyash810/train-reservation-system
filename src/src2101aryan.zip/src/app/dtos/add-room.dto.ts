export interface AddRoomRequest {
  roomType: string;
  pricePerDay: number;
  availability: boolean;
  amenities?: string[];
  description?: string;
}