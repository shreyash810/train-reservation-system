export interface RoomUpdateRequest {
  roomType: string;
  pricePerDay: number;
  availability: boolean;
  amenities?: string[];
}
