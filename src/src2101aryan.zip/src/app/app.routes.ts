import { Routes } from '@angular/router';
import { ProfileComponent } from './profile/profile.component';
import { RoomManagementComponent } from './roommanagement/roommanagement.component';
import { BookingManagementComponent } from './bookingmanagement/bookingmanagement.component';
import { PaymentManagerComponent } from './payment-manager/payment-manager.component';
import { TenantManagerComponent } from './tenant-manager/tenant-manager.component';

export const routes: Routes = [
  {path: "profile", component: ProfileComponent},
  {path: "rooms", component: RoomManagementComponent},
  {path: "bookings", component: BookingManagementComponent},
  {path: "users", component: PaymentManagerComponent},
  {path: "payment", component: TenantManagerComponent}
];
