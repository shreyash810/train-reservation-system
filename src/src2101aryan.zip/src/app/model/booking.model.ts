export interface Booking {
  id: string;
  roomId: string;      // ✅ REQUIRED
  roomNo: string;
  tenantName: string;
  startDate: string;
  endDate: string;
  status: string;
  totalAmount: number;
  isEditing?: boolean;
}
