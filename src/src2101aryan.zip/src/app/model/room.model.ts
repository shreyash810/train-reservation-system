export interface Room {
  roomId: string;
  roomNumber: string;
  address?: string;
  roomType: string;
  pricePerDay: number;
  availability: boolean;
  roomSize: number;
  amenities: string[];
  imageUrl?: string;
}
