export interface Tenant {
  id: string;              // UUID
  username: string;
  email?: string;
  role: string;
  status: 'Active' | 'Inactive';
}
