export interface BookingResponse {
  bookingId: string;
  message: string;
  totalAmount: number;
  status: string;
}
