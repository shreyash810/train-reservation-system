import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  FormsModule
} from '@angular/forms';
import { TenantService } from '../service/tenant.service';

interface Tenant {
  id: string;
  username: string;
  email?: string; // backend may add later
  role: string;
  status: 'Active' | 'Inactive';
}

@Component({
  selector: 'app-tenant-manager',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule
  ],
  templateUrl: './tenant-manager.component.html',
  styleUrls: ['./tenant-manager.component.css']
})
export class TenantManagerComponent implements OnInit {

  tenants: Tenant[] = [];
  filteredTenants: Tenant[] = [];
  pagedTenants: Tenant[] = [];

  // 🔍 Filters
  searchQuery = '';
  statusFilter: 'All' | 'Active' | 'Inactive' = 'All';

  // 📄 Pagination
  currentPage = 1;
  pageSize = 5;

  // 🔃 Sorting
  sortCol: keyof Tenant = 'username';
  sortAsc = true;

  // 🪟 UI
  showModal = false;
  showConfirmModal = false;
  isEditMode = false;

  selectedTenant: Tenant | null = null;
  tenantForm: FormGroup;

  toastMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private tenantService: TenantService
  ) {
    this.tenantForm = this.fb.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      role: ['TENANT', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadTenants();
  }

  // ================= BACKEND =================

  loadTenants(): void {
    this.tenantService.getTenants().subscribe({
      next: res => {
        console.log('TENANTS FROM BACKEND:', res);

        this.tenants = res.map(u => ({
          id: u.userId,
          username: u.username,
          email: u.email ?? '-', // safe even if backend doesn’t send it
          role: u.role,
          status: u.status
        }));

        this.applyAll();
      },
      error: err => console.error('LOAD TENANTS ERROR:', err)
    });
  }

  // ================= DATA PIPELINE =================

  applyAll(): void {
    let data = [...this.tenants];

    // 🔍 Filter
    if (this.statusFilter !== 'All') {
      data = data.filter(t => t.status === this.statusFilter);
    }

    if (this.searchQuery.trim()) {
      const q = this.searchQuery.toLowerCase();
      data = data.filter(t =>
        t.username.toLowerCase().includes(q) ||
        (t.email ?? '').toLowerCase().includes(q)
      );
    }

    // 🔃 Sort
    data.sort((a, b) => this.compare(a, b));

    this.filteredTenants = data;
    this.currentPage = 1;
    this.applyPagination();
  }

  applyPagination(): void {
    const start = (this.currentPage - 1) * this.pageSize;
    this.pagedTenants = this.filteredTenants.slice(
      start,
      start + this.pageSize
    );
  }

  // ================= SORT =================

  onSort(col: keyof Tenant): void {
    if (this.sortCol === col) {
      this.sortAsc = !this.sortAsc;
    } else {
      this.sortCol = col;
      this.sortAsc = true;
    }
    this.applyAll();
  }

  compare(a: Tenant, b: Tenant): number {
    const va = String(a[this.sortCol] ?? '').toLowerCase();
    const vb = String(b[this.sortCol] ?? '').toLowerCase();
    const cmp = va < vb ? -1 : va > vb ? 1 : 0;
    return this.sortAsc ? cmp : -cmp;
  }

  // ================= PAGINATION =================

  get totalPages(): number {
    return Math.ceil(this.filteredTenants.length / this.pageSize);
  }

  changePage(p: number): void {
    this.currentPage = p;
    this.applyPagination();
  }

  // ================= UI =================

  onSearch(): void {
    this.applyAll();
  }

  openAddModal(): void {
    this.isEditMode = false;
    this.selectedTenant = null;
    this.tenantForm.reset({ role: 'TENANT' });
    this.showModal = true;
  }

  openEditModal(t: Tenant): void {
    this.isEditMode = true;
    this.selectedTenant = t;
    this.tenantForm.patchValue({
      username: t.username,
      email: t.email ?? '',
      role: t.role
    });
    this.showModal = true;
  }

  closeModal(): void {
    this.showModal = false;
    this.showConfirmModal = false;
    this.selectedTenant = null;
  }

  onSubmit(): void {
  if (this.tenantForm.invalid) return;

  const raw = this.tenantForm.getRawValue();

  // ===== EDIT MODE =====
  if (this.isEditMode && this.selectedTenant) {

    const payload: any = { userId: this.selectedTenant.id };

    if (raw.username && raw.username.trim() !== '') {
      payload.username = raw.username;
    }

    if (raw.email && raw.email.trim() !== '') {
      payload.email = raw.email;
    }

    if (raw.role && raw.role.trim() !== '') {
      payload.role = raw.role;
    }

    this.tenantService.updateTenant(payload).subscribe({
      next: () => {
        this.showToast('User updated successfully');
        this.closeModal();
        this.loadTenants();
      },
      error: err => {
        console.error('UPDATE ERROR:', err);
        this.showToast('Update failed');
      }
    });

  } 
  // ===== CREATE MODE =====
  else {

    this.tenantService.createTenant({
      username: raw.username,
      email: raw.email,
      role: raw.role,
      countryCode: '+91',
      mobileNumber: '9999999999',
      address: 'NA'
    }).subscribe({
      next: () => {
        this.showToast('User created successfully');
        this.closeModal();
        this.loadTenants();
      },
      error: err => {
        console.error('CREATE ERROR:', err);
        this.showToast('Creation failed');
      }
    });
  }
}


  initiateStatusToggle(t: Tenant): void {
    this.selectedTenant = t;
    this.showConfirmModal = true;
  }

  confirmStatusToggle(): void {
  if (!this.selectedTenant) return;

  this.tenantService.toggleStatus(this.selectedTenant.id)
    .subscribe(msg => {
      this.showToast(msg);
      this.showConfirmModal = false;
      this.loadTenants();
    });
}


  triggerPasswordReset(t: Tenant): void {
    if (!confirm(`Reset password for ${t.username}?`)) return;

    this.tenantService.resetPassword(t.id).subscribe(msg => {
      this.showToast(msg);
    });
  }

  showToast(msg: string): void {
    this.toastMessage = msg;
    setTimeout(() => (this.toastMessage = null), 3000);
  }
}
