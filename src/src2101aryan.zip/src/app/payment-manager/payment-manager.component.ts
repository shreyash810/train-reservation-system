
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

export interface Payment {
  billId: string;
  tenantName: string;
  amount: number;
  status: 'Paid' | 'Pending' | 'Overdue';
  dateOfIssue: string;
  dueDate?: string;
  reference?: string;
  remarks?: string;
}

@Component({
  selector: 'app-payment-manager',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './payment-manager.component.html',
  styleUrls: ['./payment-manager.component.css']
})
export class PaymentManagerComponent implements OnInit {
  payments: Payment[] = [];

  private paymentsAll: Payment[] = this.seedPayments();

  totalRecords = 0;
  isLoading = false;

  searchTerm = '';
  statusFilter: 'All' | Payment['status'] = 'All';
  startDate: string = '';
  endDate: string = '';

  currentPage = 1;
  pageSize = 10;
  sortCol: keyof Payment = 'dateOfIssue';
  sortAsc = false;

  errorMessage: string | null = null;

  ngOnInit(): void {
    this.loadPayments();
  }

  loadPayments(): void {
    if (this.startDate && this.endDate && this.startDate > this.endDate) {
      this.errorMessage = 'Start Date cannot be later than End Date.';
      return;
    }
    this.errorMessage = null;
    this.isLoading = true;

    const res = this.getPaymentsLocal(
      this.searchTerm,
      this.statusFilter,
      this.startDate || null,
      this.endDate || null,
      this.sortCol,
      this.sortAsc,
      this.currentPage,
      this.pageSize
    );

    this.payments = res.data;
    this.totalRecords = res.total;
    this.isLoading = false;
  }

  onSearch(): void {
    this.currentPage = 1;
    this.loadPayments();
  }

  resetFilters(): void {
    this.searchTerm = '';
    this.statusFilter = 'All';
    this.startDate = '';
    this.endDate = '';
    this.currentPage = 1;
    this.loadPayments();
  }

  onSort(col: string): void {
    if (this.sortCol === col) {
      this.sortAsc = !this.sortAsc;
    } else {
      this.sortCol = col as keyof Payment;
      this.sortAsc = true;
    }
    this.loadPayments();
  }

  changePage(newPage: number): void {
    this.currentPage = newPage;
    this.loadPayments();
  }

  get totalPages(): number {
    return Math.ceil(this.totalRecords / this.pageSize);
  }

  trackByBillId(index: number, item: Payment) {
    return item.billId;
  }

  private getPaymentsLocal(
    searchTerm: string,
    statusFilter: 'All' | Payment['status'],
    startDate: string | null,
    endDate: string | null,
    sortCol: keyof Payment,
    sortAsc: boolean,
    page: number,
    pageSize: number
  ): { data: Payment[]; total: number } {
    let items = [...this.paymentsAll];

    if (statusFilter !== 'All') {
      items = items.filter(p => p.status === statusFilter);
    }

    if (startDate) {
      items = items.filter(p => p.dateOfIssue >= startDate);
    }
    if (endDate) {
      items = items.filter(p => p.dateOfIssue <= endDate);
    }

    const term = searchTerm.trim().toLowerCase();
    if (term) {
      items = items.filter(p => {
        return (
          p.billId.toLowerCase().includes(term) ||
          p.tenantName.toLowerCase().includes(term) ||
          String(p.amount).includes(term) ||
          p.status.toLowerCase().includes(term) ||
          p.dateOfIssue.toLowerCase().includes(term) ||
          (p.reference?.toLowerCase().includes(term) ?? false) ||
          (p.remarks?.toLowerCase().includes(term) ?? false)
        );
      });
    }

    items.sort((a, b) => this.compareByKey(a, b, sortCol, sortAsc));

    const total = items.length;
    const startIndex = Math.max(0, (page - 1) * pageSize);
    const data = items.slice(startIndex, startIndex + pageSize);

    return { data, total };
  }

  private compareByKey(
    a: Payment,
    b: Payment,
    key: keyof Payment,
    asc: boolean
  ): number {
    const va = a[key] as unknown;
    const vb = b[key] as unknown;

    let cmp = 0;
    if (typeof va === 'number' && typeof vb === 'number') {
      cmp = va - vb;
    } else {
      const sa = String(va ?? '').toLowerCase();
      const sb = String(vb ?? '').toLowerCase();
      cmp = sa < sb ? -1 : sa > sb ? 1 : 0;
    }

    return asc ? cmp : -cmp;
  }


  private seedPayments(): Payment[] {
    return [
      {
        billId: 'BILL-1001',
        tenantName: 'Acme Corp',
        amount: 12500,
        status: 'Paid',
        dateOfIssue: '2025-12-12',
        dueDate: '2025-12-20',
        reference: 'INV-AC-2025-12',
        remarks: 'Wire transfer received'
      },
      {
        billId: 'BILL-1002',
        tenantName: 'Globex Ltd',
        amount: 9800,
        status: 'Pending',
        dateOfIssue: '2026-01-02',
        dueDate: '2026-01-15',
        reference: 'INV-GL-2026-01',
        remarks: 'Awaiting approval'
      },
      {
        billId: 'BILL-1003',
        tenantName: 'Soylent Co',
        amount: 3400,
        status: 'Overdue',
        dateOfIssue: '2025-12-30',
        dueDate: '2026-01-05',
        reference: 'INV-SY-2026-01',
        remarks: 'Payment overdue by 3 days'
      },
      {
        billId: 'BILL-1004',
        tenantName: 'Initech',
        amount: 15200,
        status: 'Paid',
        dateOfIssue: '2025-12-28',
        dueDate: '2026-01-05',
        reference: 'INV-IT-2025-12',
        remarks: 'Customer refund processed'
      },
      {
        billId: 'BILL-1005',
        tenantName: 'Umbrella Inc',
        amount: 7200,
        status: 'Pending',
        dateOfIssue: '2026-01-08',
        dueDate: '2026-01-18',
        reference: 'INV-UM-2026-01',
        remarks: 'Card on hold'
      }
    ];
  }
}
