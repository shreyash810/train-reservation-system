import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Admin } from '../../services/admin';
import { AlertService } from '../../shared/alert.service';

@Component({
  selector: 'app-search-appointments',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './search-appointments.html',
  styleUrls: ['./search-appointments.css']
})
export class SearchAppointments implements OnInit {

  searchText = '';
  searchDate = '';
  appointments: any[] = [];
  today = new Date().toISOString().split('T')[0];

  constructor(private adminService: Admin, private alertService: AlertService) {}

  ngOnInit() {
    this.loadAppointments();
  }

  loadAppointments() {
    this.adminService.getAllAppointments().subscribe({
      next: (res: any) => {
        this.appointments = res;
      },
      error: () => this.alertService.showAlert('Error loading appointments', 'error')
    });
  }

  get filteredAppointments() {
    return this.appointments.filter(appt =>
      (!this.searchText ||
        appt.patientName?.toLowerCase().includes(this.searchText.toLowerCase()) ||
        appt.specialization?.toLowerCase().includes(this.searchText.toLowerCase())) &&
      (!this.searchDate || appt.appointmentDate === this.searchDate)
    );
  }
}