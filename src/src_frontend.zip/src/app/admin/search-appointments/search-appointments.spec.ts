import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchAppointments } from './search-appointments';

describe('SearchAppointments', () => {
  let component: SearchAppointments;
  let fixture: ComponentFixture<SearchAppointments>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SearchAppointments]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchAppointments);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
