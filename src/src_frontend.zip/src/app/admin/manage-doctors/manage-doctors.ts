import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Admin } from '../../services/admin';
import { AlertService } from '../../shared/alert.service';

@Component({
  selector: 'app-manage-doctors',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './manage-doctors.html',
  styleUrls: ['./manage-doctors.css']
})
export class ManageDoctors implements OnInit {

  doctors: any[] = [];
  doctorForm: FormGroup;
  isEditMode = false;
  selectedDoctorId: string | null = null;

  constructor(private fb: FormBuilder, private adminService: Admin, private alertService: AlertService) {
    this.doctorForm = this.fb.group({
      doctorId: ['', Validators.required],
      name: ['', Validators.required],
      specialization: ['', Validators.required],
      qualification: ['', Validators.required],
      experience: [0, [Validators.required, Validators.min(0)]],
      availability: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.loadDoctors();
  }

  loadDoctors() {
    this.adminService.getDoctors().subscribe({
      next: (res: any) => {
        this.doctors = res;
      },
      error: () => this.alertService.showAlert('Error loading doctors', 'error')
    });
  }

  editDoctor(doctor: any) {
    this.isEditMode = true;
    this.selectedDoctorId = doctor.doctorId;
    this.doctorForm.patchValue(doctor);
  }

  saveDoctor() {
    if (this.doctorForm.invalid) return;

    const doctorData = this.doctorForm.value;

    if (this.isEditMode && this.selectedDoctorId) {
      this.adminService.updateDoctor(doctorData).subscribe({
        next: (res: string) => {
          if (res === 'UPDATED') {
            this.alertService.showAlert('Doctor updated successfully', 'success');
            this.loadDoctors();
            this.resetForm();
          } else {
            this.alertService.showAlert('Error updating doctor', 'error');
          }
        },
        error: () => this.alertService.showAlert('Server error', 'error')
      });
    } else {
      this.adminService.addDoctor(doctorData).subscribe({
        next: (res: string) => {
          if (res === 'ADDED') {
            this.alertService.showAlert('Doctor added successfully', 'success');
            this.loadDoctors();
            this.resetForm();
          } else {
            this.alertService.showAlert(res, 'error');
          }
        },
        error: () => this.alertService.showAlert('Server error', 'error')
      });
    }
  }

  deleteDoctor(doctorId: string) {
    if (confirm('Are you sure you want to delete this doctor?')) {
      this.adminService.deleteDoctor(doctorId).subscribe({
        next: () => {
          this.alertService.showAlert('Doctor deleted successfully', 'success');
          this.loadDoctors();
        },
        error: () => this.alertService.showAlert('Server error', 'error')
      });
    }
  }

  resetForm() {
    this.doctorForm.reset();
    this.isEditMode = false;
    this.selectedDoctorId = null;
  }
}