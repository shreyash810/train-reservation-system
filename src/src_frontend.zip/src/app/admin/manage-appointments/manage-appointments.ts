import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Admin } from '../../services/admin';
import { AlertService } from '../../shared/alert.service';

@Component({
  selector: 'app-manage-appointments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './manage-appointments.html',
  styleUrls: ['./manage-appointments.css']
})
export class ManageAppointments implements OnInit {

  appointments: any[] = [];

  constructor(private adminService: Admin, private alertService: AlertService) {}

  ngOnInit() {
    this.loadAppointments();
  }

  loadAppointments() {
    this.adminService.getAllAppointments().subscribe({
      next: (res: any) => {
        this.appointments = res;
      },
      error: () => this.alertService.showAlert('Error loading appointments', 'error')
    });
  }

  updateStatus(appointment: any, newStatus: string) {
    // For now, no update endpoint, just display
    appointment.status = newStatus;
  }
}