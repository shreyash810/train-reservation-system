import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlertService {
  private alertSubject = new BehaviorSubject<{ message: string, type: string } | null>(null);
  public alert$ = this.alertSubject.asObservable();

  showAlert(message: string, type: 'success' | 'error' | 'info' = 'info') {
    this.alertSubject.next({ message, type });
  }

  hideAlert() {
    this.alertSubject.next(null);
  }
}