import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
// import { AuthService } from '../services/auth.service';
import { AuthService } from '../../services/auth.serivce';
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './homepage.html',
  styleUrls: ['./homepage.css']
})
export class Homepage {

  constructor(
    public auth: AuthService,
    private router: Router
  ) {}

  // Navigate to patient registration
  goToRegister() {
    this.router.navigate(['/auth/patient-register']);
  }

  // Navigate to patient login
  goToLogin() {
    this.router.navigate(['/auth/patient-login']);
  }

  // Navigate to doctor login
  goToDoctorLogin() {
    this.router.navigate(['/auth/doctor-login']);
  }

  // Navigate to admin login
  goToAdminLogin() {
    this.router.navigate(['/auth/admin-login']);
  }

  
}