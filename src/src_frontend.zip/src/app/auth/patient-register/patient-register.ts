import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  AbstractControl
} from '@angular/forms';
import { AuthService } from '../../services/auth.serivce';
import { Patient } from '../../services/patient';
import { AlertService } from '../../shared/alert.service';
@Component({
  selector: 'app-patient-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './patient-register.html',
  styleUrls: ['./patient-register.css']
})
export class PatientRegister {

  registerForm: FormGroup;
  showSuccessToast = false;


  constructor(private fb: FormBuilder,private auth:AuthService,private router:Router,private Patient:Patient,private alertService: AlertService) {
    this.registerForm = this.fb.group(
      {
        name: [
          '',
          [
            Validators.required,
            Validators.minLength(3),
            Validators.pattern(/^[A-Za-z ]+$/)
          ]
        ],
        email: ['', [Validators.required, Validators.email]],
        countryCode: ['', Validators.required],
        mobile: [
          '',
          [
            Validators.required,
            Validators.pattern(/^[0-9]{8,10}$/)
          ]
        ],
        address: ['', [Validators.required, Validators.minLength(10)]],
        username: [
          '',
          [
            Validators.required,
            Validators.minLength(5),
            Validators.pattern(/^\S+$/)
          ]
        ],
        password: [
          '',
          [
            Validators.required,
            Validators.pattern(
              /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/
            )
          ]
        ],
        confirmPassword: ['', Validators.required]
      },
      { validators: this.passwordMatchValidator }
    );
  }

  passwordMatchValidator(form: AbstractControl) {
    return form.get('password')?.value ===
      form.get('confirmPassword')?.value
      ? null
      : { passwordMismatch: true };
  }

  

  register() {
  if (this.registerForm.invalid) return;

  const payload = this.registerForm.value;

  this.Patient.registerPatient(payload).subscribe({
    next: (res: string) => {

      if (res === 'EMAIL_EXISTS') {
        this.registerForm.get('email')?.setErrors({ duplicate: true });
        return;
      }

      if (res === 'MOBILE_EXISTS') {
        this.registerForm.get('mobile')?.setErrors({ duplicate: true });
        return;
      }

      if (res === 'USERNAME_EXISTS') {
        this.registerForm.get('username')?.setErrors({ duplicate: true });
        return;
      }

      // SUCCESS
      this.showSuccessToast = true;
      localStorage.setItem('username', payload.username);
      this.registerForm.reset();

      setTimeout(() => this.showSuccessToast = false, 3000);
    },
    error: () => {
      this.alertService.showAlert('Server error', 'error');
    }
  });

  this.auth.login('PATIENT');
  this.router.navigate(['/patient/home']);
}
  
  reset() {
    this.registerForm.reset();
  }

  get f() {
    return this.registerForm.controls;
  }
}