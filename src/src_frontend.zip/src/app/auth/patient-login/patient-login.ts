  import { Component } from '@angular/core';
  import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
  import { CommonModule } from '@angular/common';
  import { Router } from '@angular/router';
  import { AuthService } from '../../services/auth.serivce';
  import { Patient } from '../../services/patient';
  import { AlertService } from '../../shared/alert.service';
  @Component({
    selector: 'app-patient-login',
    standalone: true,
    imports: [CommonModule, ReactiveFormsModule],
    templateUrl: './patient-login.html',
    styleUrls: ['./patient-login.css']
  })
  export class PatientLogin {

    loginForm: FormGroup;
    loginError = '';

    constructor(private fb: FormBuilder, private router: Router,private auth:AuthService,private Patient:Patient,private alertService: AlertService) {
      this.loginForm = this.fb.group({
        username: ['', Validators.required],
        password: ['', Validators.required]
      });
    }

    login() {
    if (this.loginForm.invalid) return;

    const loginData = this.loginForm.value;

    this.Patient.loginPatient(loginData).subscribe({
      next: (res: string) => {

        if (res === 'SUCCESS') {
          this.auth.login('PATIENT');
          localStorage.setItem('username', loginData.username);
          this.router.navigate(['/patient/home']);
        } else {
          this.alertService.showAlert('User does not exist', 'error');
          this.router.navigate(['/']);
        }

      },
      error: () => {
        this.alertService.showAlert('Server error', 'error');
      }
    });
  }
  
goToRegister() {
  this.router.navigate(['/auth/patient-register']);
}


    resetForm() {
      this.loginForm.reset();
      this.loginError = '';
    }
  }