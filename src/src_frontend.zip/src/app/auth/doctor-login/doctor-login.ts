import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.serivce';
import { Doctor } from '../../services/doctor';
import { AlertService } from '../../shared/alert.service';

@Component({
  selector: 'app-doctor-login',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './doctor-login.html',
  styleUrls: ['./doctor-login.css']
})
export class DoctorLogin implements OnInit {

  doctorLoginForm!: FormGroup;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private auth: AuthService,
    private doctorService: Doctor,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.doctorLoginForm = this.fb.group({
      doctorId: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  login(): void {
    if (this.doctorLoginForm.invalid) return;

    const loginData = this.doctorLoginForm.value;

    this.doctorService.login(loginData).subscribe({
      next: (res) => {
        if (res === 'SUCCESS') {
          this.auth.login('DOCTOR');
          localStorage.setItem('doctorId', loginData.doctorId);
          this.router.navigate(['/doctor/appointments']);
        } else {
          this.alertService.showAlert('Doctor not found', 'error');
          this.router.navigate(['/']);
        }
      },
      error: () => this.alertService.showAlert('Server error', 'error')
    });
  }
}