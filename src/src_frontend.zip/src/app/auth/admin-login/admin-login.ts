import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.serivce';
import { Admin } from '../../services/admin';
import { AlertService } from '../../shared/alert.service';
@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule   // ✅ THIS FIXES THE ERROR
  ],
  templateUrl: './admin-login.html',
  styleUrls: ['./admin-login.css']
})
export class AdminLogin implements OnInit {

  adminLoginForm!: FormGroup;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private auth:AuthService,
    private Admin:Admin,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.adminLoginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  login(): void {
  if (this.adminLoginForm.invalid) return;

  const loginData = this.adminLoginForm.value;

  this.Admin.login(loginData).subscribe({
    next: (res) => {
      if (res === 'SUCCESS') {
        this.auth.login('ADMIN');
        this.router.navigate(['/admin/dashboard']);
      } else {
        this.alertService.showAlert('Admin not found', 'error');
        this.router.navigate(['/']);
      }
    },
    error: () => {
      this.alertService.showAlert('Server error', 'error');
    }
  });
}


  reset(): void {
    this.adminLoginForm.reset();
  }
}