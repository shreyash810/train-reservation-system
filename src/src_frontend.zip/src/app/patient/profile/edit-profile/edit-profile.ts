
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './edit-profile.html',
  styleUrls: ['./edit-profile.css']
})
export class EditProfile {
  patient = {
    name: '',
    email: '',
    phone: ''
  };

  constructor(private router: Router) {
    // Initialize strictly from localStorage, not hardcoded fallback
    this.patient.name = localStorage.getItem('name') || '';
    this.patient.email = localStorage.getItem('email') || '';
    this.patient.phone = localStorage.getItem('phone') || '';
  }

  save() {
    // Persist back to localStorage
    if (this.patient.name)  localStorage.setItem('name', this.patient.name);
    if (this.patient.email) localStorage.setItem('email', this.patient.email);
    if (this.patient.phone) localStorage.setItem('phone', this.patient.phone);

    // Navigate back to view
    this.router.navigate(['/patient/profile/view']);
  }

  cancel() {
    this.router.navigate(['/patient/profile/view']);
  }
}
``
