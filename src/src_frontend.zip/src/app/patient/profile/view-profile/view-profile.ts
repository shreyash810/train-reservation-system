
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Patient } from '../../../services/patient';
import { AlertService } from '../../../shared/alert.service';

@Component({
  selector: 'app-view-profile',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './view-profile.html',
  styleUrls: ['./view-profile.css']
})
export class ViewProfile implements OnInit {
  patient: any = {};
  username = '';

  constructor(
    private router: Router,
    private patientService: Patient,
    private alertService: AlertService
  ) {
    this.username = localStorage.getItem('username') || '';
  }

  ngOnInit() {
    this.loadProfile();
  }

  private mergeWithLocalStorage(base: any): any {
    // Read from localStorage (if user edited locally)
    const lsName = localStorage.getItem('name');
    const lsEmail = localStorage.getItem('email');
    const lsPhone = localStorage.getItem('phone');
    const lsUsername = localStorage.getItem('username');

    // Merge (localStorage overrides backend for UI display)
    return {
      ...base,
      name: lsName ?? base?.name,
      email: lsEmail ?? base?.email,
      mobile: lsPhone ?? base?.mobile ?? base?.phone,
      phone: lsPhone ?? base?.phone, // keep both keys for safety
      username: lsUsername ?? base?.username
    };
  }

  
loadProfile() {
  this.patientService.getProfile(this.username).subscribe({
    next: (res: any) => {
      // 1) Read any existing local edits
      const ls = {
        name: localStorage.getItem('name'),
        email: localStorage.getItem('email'),
        phone: localStorage.getItem('phone'),
        username: localStorage.getItem('username') || this.username,
      };

      // 2) Only seed localStorage from backend IF keys are missing
      //    (so we don't overwrite user's edits)
      if (!ls.name && res?.name) localStorage.setItem('name', res.name);
      if (!ls.email && res?.email) localStorage.setItem('email', res.email);
      if (!ls.phone && (res?.mobile || res?.phone)) {
        localStorage.setItem('phone', res.mobile ?? res.phone);
      }
      if (!ls.username && res?.username) {
        localStorage.setItem('username', res.username);
      }

      // Refresh ls after potential seeding
      const name = localStorage.getItem('name') ?? res?.name ?? '';
      const email = localStorage.getItem('email') ?? res?.email ?? '';
      const phone = localStorage.getItem('phone') ?? res?.mobile ?? res?.phone ?? '';
      const username = localStorage.getItem('username') ?? res?.username ?? this.username;

      // 3) Merge for UI (localStorage takes precedence)
      this.patient = {
        ...res,
        name,
        email,
        mobile: phone, // keep both keys for template safety
        phone,
        username
      };
    },
    error: () => this.alertService.showAlert('Error loading profile', 'error')
  });
}


  editProfile() {
    this.router.navigate(['/patient/profile/edit']);
  }

  deleteProfile() {
    if (confirm('Are you sure you want to delete your profile?')) {
      this.patientService.deleteProfile(this.username).subscribe({
        next: (res: string) => {
          if (res === 'DELETED') {
            localStorage.clear();
            this.router.navigate(['/']);
          } else {
            this.alertService.showAlert('Error deleting profile', 'error');
          }
        },
        error: () => this.alertService.showAlert('Server error', 'error')
      });
    }
  }
}
``
