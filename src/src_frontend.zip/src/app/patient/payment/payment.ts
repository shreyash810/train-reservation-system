
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, AbstractControl, ValidatorFn } from '@angular/forms';
import { Router } from '@angular/router';
import { Payment as PaymentService } from '../../services/payment';
import { AlertService } from '../../shared/alert.service';

type CardBrand = 'visa' | 'amex';

interface CardPreset {
  cardName: string;
  cardNumber: string;
  expiry: string; // YYYY-MM (for <input type="month">)
  cvv: string;
}

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './payment.html',
  styleUrls: ['./payment.css']
})
export class Payment implements OnInit {

  paymentForm: FormGroup;
  consultationFee = 500; // static for now
  appointment: any = {};

  /** Which brand is hovered (temporary activation) */
  cardHover: CardBrand | null = null;

  /** Optional persisted selection via click */
  get cardType(): CardBrand | '' { return this.paymentForm.value.cardType || ''; }

  /** Hard-coded test presets (you can replace these with your own) */
  readonly CARD_PRESETS: Record<CardBrand, CardPreset> = {
    visa: {
      cardName: 'JOHN DOE',
      cardNumber: '4111111111111111',
      expiry: '2028-12',
      cvv: '123'
    },
    amex: {
      cardName: 'JANE DOE',
      cardNumber: '378282246310005',
      expiry: '2028-09',
      cvv: '1234'
    }
  };

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private paymentService: PaymentService,
    private alertService: AlertService
  ) {
    // Start with no validation; we add exact-match only for active brand
    this.paymentForm = this.fb.group({
      cardType: [''], // 'visa' | 'amex' (set on click)
      cardName: [''],
      cardNumber: [''],
      expiry: [''],
      cvv: ['']
    });

    // If user selects brand by click, keep validators active even after hover
    this.paymentForm.get('cardType')!.valueChanges.subscribe((type: CardBrand | '') => {
      this.setupExactValidators(type || null);
      if (type) this.applyPreset(type, /*patchOnly*/ true);
    });
  }

  ngOnInit() {
    // get appointment
    this.appointment = history.state.appointment || {};
    // ensure no validators initially
    this.setupExactValidators(null);
  }

  /** Equal-to validator factory (hard equality) */
  private equalsTo(expected: string): ValidatorFn {
    return (control: AbstractControl) => {
      return control.value === expected ? null : { notEqual: true };
    };
  }

  /** Apply exact-match validators when brand is active; clear otherwise */
  private setupExactValidators(brand: CardBrand | null) {
    const cName = this.paymentForm.get('cardName')!;
    const cNum  = this.paymentForm.get('cardNumber')!;
    const exp   = this.paymentForm.get('expiry')!;
    const cvv   = this.paymentForm.get('cvv')!;

    // Clear validators first
    [cName, cNum, exp, cvv].forEach(c => c.clearValidators());

    if (brand) {
      const preset = this.CARD_PRESETS[brand];
      cName.setValidators([Validators.required, this.equalsTo(preset.cardName)]);
      cNum.setValidators([Validators.required, this.equalsTo(preset.cardNumber)]);
      exp.setValidators([Validators.required, this.equalsTo(preset.expiry)]);
      cvv.setValidators([Validators.required, this.equalsTo(preset.cvv)]);
    }

    [cName, cNum, exp, cvv].forEach(c => c.updateValueAndValidity({ emitEvent: false }));
  }

  /** Hover handlers — hover activates brand temporarily and auto-fills */
  onHover(type: CardBrand | null) {
    this.cardHover = type;

    const effective = this.activeBrand();
    this.setupExactValidators(effective);

    if (effective) {
      // autofill on hover (or keep selected values)
      this.applyPreset(effective, /*patchOnly*/ true);
    }
  }

  /** Click to persist selection */
  setCardType(type: CardBrand) {
    this.paymentForm.patchValue({ cardType: type });
    this.setupExactValidators(type);
    this.applyPreset(type, /*patchOnly*/ true);
  }

  /** Currently active brand: hover takes precedence over selection */
  activeBrand(): CardBrand | null {
    return (this.cardHover as CardBrand | null) ?? (this.cardType as CardBrand | null) ?? null;
    // hover > selected > null
  }

  /** Editable only for the active panel (hover/selected) */
  isEditable(type: CardBrand): boolean {
    return this.activeBrand() === type;
  }

  /** Autofill the form with selected brand's preset */
  private applyPreset(type: CardBrand, patchOnly = true) {
    const p = this.CARD_PRESETS[type];
    // Keep the name uppercase for clarity; month input requires YYYY-MM format
    this.paymentForm.patchValue({
      cardName: p.cardName,
      cardNumber: p.cardNumber,
      expiry: p.expiry,
      cvv: p.cvv
    }, { emitEvent: false });

    if (!patchOnly) this.paymentForm.updateValueAndValidity({ emitEvent: false });
  }

  /** Check if a specific control has "notEqual" error (mismatch) */
  hasNotEqual(ctrlName: 'cardName' | 'cardNumber' | 'expiry' | 'cvv'): boolean {
    const ctrl = this.paymentForm.get(ctrlName)!;
    return !!ctrl.errors?.['notEqual'];
  }

  /** Show banner error when any of the active brand fields mismatches its preset */
  showWrongDetails(forBrand: CardBrand): boolean {
    if (this.activeBrand() !== forBrand) return false;
    const c = this.paymentForm.controls;
    return !!(c['cardName'].errors || c['cardNumber'].errors || c['expiry'].errors || c['cvv'].errors);
  }

  payNow() {
    const brand = this.activeBrand();

    // Only allow pay if Visa/Amex is active and preset values match exactly
    if (!brand || this.paymentForm.invalid) {
      this.paymentForm.markAllAsTouched();
      this.alertService.showAlert('Please hover/select Visa or Amex and use the exact preset details.', 'error');
      return;
    }

    const paymentData = {
      username: this.appointment.username,
      appointmentId: this.appointment.id,
      amount: this.consultationFee,
      status: 'pending',
      date: new Date().toISOString().split('T')[0]
    };

    this.paymentService.processPayment(paymentData).subscribe({
      next: (res: string) => {
        if (res === 'PAYMENT_SUCCESS') {
          localStorage.setItem('paymentAmount', this.consultationFee.toString());
          this.alertService.showAlert('Appointment booked successfully', 'success');
          this.router.navigate(['/patient/payment-success'], { state: { appointment: this.appointment } });
        } else {
          this.alertService.showAlert('Payment failed', 'error');
        }
      },
      error: () => this.alertService.showAlert('Server error', 'error')
    });
  }

  resetForm() {
    this.paymentForm.reset({ cardType: '' });
    this.cardHover = null;
    this.setupExactValidators(null);
  }
}
