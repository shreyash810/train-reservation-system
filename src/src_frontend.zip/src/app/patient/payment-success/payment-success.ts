import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { jsPDF } from 'jspdf';

@Component({
  selector: 'app-payment-success',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './payment-success.html',
  styleUrls: ['./payment-success.css']
})
export class PaymentSuccess {

  patientName = localStorage.getItem('patientName') || 'Patient';
  amount = localStorage.getItem('paymentAmount') || '500';
  date = new Date().toLocaleDateString();
  appointment: any = {};

  invoiceNumber = '';

  constructor(private router: Router) {
    this.invoiceNumber =
      localStorage.getItem('invoiceNumber') || this.generateInvoiceNumber();

    localStorage.setItem('invoiceNumber', this.invoiceNumber);

    this.appointment = history.state.appointment || {};
  }

  generateInvoiceNumber(): string {
    return 'INV-' + Math.floor(100000 + Math.random() * 900000);
  }

  goToDashboard() {
    this.router.navigate(['/patient/home']);
  }

  downloadReceiptPDF() {
    const pdf = new jsPDF();

    /* LOGO (simple text-based logo for now) */
    pdf.setFontSize(16);
    pdf.setTextColor(13, 110, 253);
    pdf.text('MediCare Hospital', 20, 20);

    pdf.setTextColor(0);
    pdf.setFontSize(11);
    pdf.text(`Invoice No: ${this.invoiceNumber}`, 150, 20);

    pdf.line(20, 25, 190, 25);

    /* TABLE HEADER */
    pdf.setFontSize(12);
    pdf.text('Description', 20, 35);
    pdf.text('Amount (₹)', 170, 35);

    pdf.line(20, 38, 190, 38);

    /* TABLE ROW */
    pdf.text('Consultation Fee', 20, 48);
    pdf.text(this.amount, 170, 48);

    pdf.line(20, 55, 190, 55);

    /* TOTAL */
    pdf.setFontSize(12);
    pdf.text('Total', 120, 65);
    pdf.text(`Rs${this.amount}`, 170, 65);

    /* FOOTER DETAILS */
    pdf.setFontSize(11);
    pdf.text(`Patient Name : ${this.patientName}`, 20, 80);
    pdf.text(`Payment Status : SUCCESS`, 20, 88);
    pdf.text(`Date : ${this.date}`, 20, 96);

    pdf.line(20, 105, 190, 105);
    pdf.text('Thank you for choosing MediCare Hospital', 55, 115);

    pdf.save(`invoice-${this.invoiceNumber}.pdf`);
  }
}