import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Appointment } from '../../services/appointment';
import { AlertService } from '../../shared/alert.service';

@Component({
  selector: 'app-schedule-appointment',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './schedule-appointment.html',
  styleUrls: ['./schedule-appointment.css']
})
export class ScheduleAppointment {

  searchForm: FormGroup;
  appointmentForm: FormGroup;
  doctors: any[] = [];
  selectedDoctor: any = null;
  username = '';
  today = new Date().toISOString().split('T')[0];
  searched = false;

  constructor(private fb: FormBuilder, private router: Router, private appointmentService: Appointment, private alertService: AlertService) {
    this.searchForm = this.fb.group({
      specialization: ['', Validators.required],
      date: ['', Validators.required]
    });

    this.appointmentForm = this.fb.group({
      patientName: ['', Validators.required],
      reason: ['', [Validators.required, Validators.minLength(5)]]
    });

    this.username = localStorage.getItem('username') || '';
  }

  searchDoctors() {
    if (this.searchForm.invalid) return;

    const { specialization, date } = this.searchForm.value;

    this.appointmentService.searchDoctors(specialization, date).subscribe({
      next: (res: any) => {
        this.searched = true;
        this.doctors = res || [];
      },
      error: () => {
        this.alertService.showAlert('Error searching doctors', 'error');
        this.searched = true;
        this.doctors = [];
      }
    });
  }

  selectDoctor(doctor: any) {
    this.selectedDoctor = doctor;
  }

  scheduleAppointment() {
    if (this.appointmentForm.invalid || !this.selectedDoctor) return;

    const { patientName, reason } = this.appointmentForm.value;
    const { specialization, date } = this.searchForm.value;
    localStorage.setItem('patientName',patientName);

    const payload = {
      username: this.username,
      doctorId: this.selectedDoctor.doctorId,
      patientName,
      appointmentDate: date,
      specialization,
      reason,
      status: 'open'
    };

    this.appointmentService.bookAppointment(payload).subscribe({
      next: (res: string) => {
        if (res === 'APPOINTMENT_BOOKED') {
          
          this.router.navigate(['/patient/payment'], { state: { appointment: payload } });
        } else if (res === 'DOCTOR_NOT_AVAILABLE') {
          this.alertService.showAlert('Doctor is not available on the selected date', 'error');
        } else if (res === 'DOCTOR_NOT_FOUND') {
          this.alertService.showAlert('Doctor not found', 'error');
        } else {
          this.alertService.showAlert('Error booking appointment', 'error');
        }
      },
      error: () => this.alertService.showAlert('Server error', 'error')
    });
  }

  resetForm() {
    this.searchForm.reset();
    this.appointmentForm.reset();
    this.doctors = [];
    this.selectedDoctor = null;
  }
}