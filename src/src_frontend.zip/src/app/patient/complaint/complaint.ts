import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Complaint as ComplaintService } from '../../services/complaint';
import { AlertService } from '../../shared/alert.service';

@Component({
  selector: 'app-complaint',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './complaint.html',
  styleUrls: ['./complaint.css']
})
export class Complaint {

  complaintForm: FormGroup;
  username = '';

  constructor(private fb: FormBuilder, private router: Router, private complaintService: ComplaintService, private alertService: AlertService) {
    this.complaintForm = this.fb.group({
      subject: ['', Validators.required],
      description: ['', [Validators.required, Validators.minLength(10)]]
    });

    this.username = localStorage.getItem('username') || '';
  }

  submitComplaint() {
    if (this.complaintForm.invalid) return;

    const complaintData = {
      username: this.username,
      subject: this.complaintForm.value.subject,
      description: this.complaintForm.value.description,
      status: 'open',
      date: new Date().toISOString().split('T')[0]
    };

    this.complaintService.registerComplaint(complaintData).subscribe({
      next: (res: string) => {
        if (res === 'COMPLAINT_REGISTERED') {
          this.alertService.showAlert('Complaint submitted successfully', 'success');
          this.router.navigate(['/patient/home']);
        } else {
          this.alertService.showAlert('Error submitting complaint', 'error');
        }
      },
      error: () => this.alertService.showAlert('Server error', 'error')
    });
  }

  resetForm() {
    this.complaintForm.reset();
  }
}