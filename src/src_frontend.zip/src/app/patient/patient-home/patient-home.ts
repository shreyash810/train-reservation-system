import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patient-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './patient-home.html',
  styleUrls: ['./patient-home.css']
})
export class PatientHome implements OnInit {
  patientName = '';

  constructor(private router: Router) {}

  ngOnInit() {
    this.patientName = localStorage.getItem('username') || 'Patient';
  }

  goToScheduleAppointment() {
    this.router.navigate(['/patient/schedule-appointment']);
  }

  goToMyAppointments() {
    this.router.navigate(['/patient/my-appointments']);
  }

  goToComplaint() {
    this.router.navigate(['/patient/complaint']);
  }

  goToTrackComplaint() {
    this.router.navigate(['/patient/track-complaint']);
  }

  logout() {
    // Later: clear JWT token
    localStorage.clear();
    this.router.navigate(['/']);
  }
}