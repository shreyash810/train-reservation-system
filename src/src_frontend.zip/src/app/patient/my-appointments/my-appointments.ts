import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Appointment } from '../../services/appointment';
import { AlertService } from '../../shared/alert.service';

@Component({
  selector: 'app-my-appointments',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './my-appointments.html',
  styleUrls: ['./my-appointments.css']
})
export class MyAppointments implements OnInit {

  appointments: any[] = [];
  selectedAppointment: any = null;
  username = '';
  today = new Date().toISOString().split('T')[0];

  constructor(private router: Router, private appointmentService: Appointment, private alertService: AlertService) {
    this.username = localStorage.getItem('username') || '';
  }

  ngOnInit() {
    this.loadAppointments();
  }

  loadAppointments() {
    this.appointmentService.getMyAppointments(this.username).subscribe({
      next: (res: any) => {
        this.appointments = res;
      },
      error: () => this.alertService.showAlert('Error loading appointments', 'error')
    });
  }

  cancelAppointment(id: number) {
    if (confirm('Are you sure you want to cancel this appointment?')) {
      this.appointmentService.cancelAppointment(id).subscribe({
        next: (res: string) => {
          if (res === 'CANCELLED') {
            this.alertService.showAlert('Appointment cancelled successfully', 'success');
            this.loadAppointments();
          } else {
            this.alertService.showAlert('Error cancelling appointment', 'error');
          }
        },
        error: () => this.alertService.showAlert('Server error', 'error')
      });
    }
  }

  rescheduleAppointment(appointment: any) {
    this.selectedAppointment = { ...appointment };
  }

  saveReschedule() {
    this.appointmentService.rescheduleAppointment(this.selectedAppointment.id, { newDate: this.selectedAppointment.appointmentDate }).subscribe({
      next: (res: string) => {
        if (res === 'RESCHEDULED') {
          this.alertService.showAlert('Appointment rescheduled successfully', 'success');
          this.selectedAppointment = null;
          this.loadAppointments();
        } else {
          this.alertService.showAlert('Error rescheduling appointment', 'error');
        }
      },
      error: () => this.alertService.showAlert('Server error', 'error')
    });
  }

  backToDashboard() {
    this.router.navigate(['/patient/home']);
  }
}