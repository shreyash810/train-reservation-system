import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Complaint as ComplaintService } from '../../services/complaint';
import { AlertService } from '../../shared/alert.service';

@Component({
  selector: 'app-track-complaint',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './track-complaint.html',
  styleUrls: ['./track-complaint.css']
})
export class TrackComplaint implements OnInit {

  complaints: any[] = [];
  username = '';

  constructor(private complaintService: ComplaintService, private alertService: AlertService) {
    this.username = localStorage.getItem('username') || '';
  }

  ngOnInit() {
    this.loadComplaints();
  }

  loadComplaints() {
    this.complaintService.trackComplaints(this.username).subscribe({
      next: (res: any) => {
        this.complaints = res;
      },
      error: () => this.alertService.showAlert('Error loading complaints', 'error')
    });
  }
}