import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class Admin {

  private baseUrl = 'http://localhost:8080/api/admin';

  constructor(private http: HttpClient) {}

  login(data: any) {
    return this.http.post(`${this.baseUrl}/login`, data, { responseType: 'text' });
  }

  // Doctor management
  addDoctor(data: any) {
    return this.http.post(`${this.baseUrl}/doctor/add`, data, { responseType: 'text' });
  }

  updateDoctor(data: any) {
    return this.http.put(`${this.baseUrl}/doctor/update`, data, { responseType: 'text' });
  }

  getDoctors() {
    return this.http.get(`${this.baseUrl}/doctor/all`);
  }

  deleteDoctor(id: string) {
    return this.http.delete(`${this.baseUrl}/doctor/delete/${id}`);
  }

  // Complaints
  getAllComplaints() {
    return this.http.get(`${this.baseUrl}/complaints/all`);
  }

  updateComplaintStatus(id: number, status: string) {
    return this.http.put(`${this.baseUrl}/complaints/update/${id}`, { status }, { responseType: 'text' });
  }

  // Appointments
  getAllAppointments() {
    return this.http.get(`${this.baseUrl}/appointments/all`);
  }
}

