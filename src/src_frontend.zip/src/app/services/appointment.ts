import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class Appointment {
  private baseUrl = 'http://localhost:8080/api/patient/appointment';

  constructor(private http: HttpClient) {}

  searchDoctors(specialization: string, date: string) {
    return this.http.get(`${this.baseUrl}/search?specialization=${specialization}&date=${date}`);
  }

  bookAppointment(data: any) {
    return this.http.post(`${this.baseUrl}/book`, data, { responseType: 'text' });
  }

  getMyAppointments(username: string) {
    return this.http.get(`http://localhost:8080/api/patient/appointments/my/${username}`);
  }

  rescheduleAppointment(id: number, data: any) {
    return this.http.put(`http://localhost:8080/api/patient/appointments/reschedule/${id}`, data, { responseType: 'text' });
  }

  cancelAppointment(id: number) {
    return this.http.delete(`http://localhost:8080/api/patient/appointments/cancel/${id}`, { responseType: 'text' });
  }
}
