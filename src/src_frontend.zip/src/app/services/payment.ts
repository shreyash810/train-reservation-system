import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class Payment {
  private baseUrl = 'http://localhost:8080/api/patient/payment';

  constructor(private http: HttpClient) {}

  processPayment(data: any) {
    return this.http.post(`${this.baseUrl}/process`, data, { responseType: 'text' });
  }
}