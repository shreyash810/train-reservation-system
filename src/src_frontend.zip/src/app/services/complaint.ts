import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class Complaint {
  private baseUrl = 'http://localhost:8080/api/patient/complaint';

  constructor(private http: HttpClient) {}

  registerComplaint(data: any) {
    return this.http.post(`${this.baseUrl}/register`, data, { responseType: 'text' });
  }

  trackComplaints(username: string) {
    return this.http.get(`${this.baseUrl}/track/${username}`);
  }
}
