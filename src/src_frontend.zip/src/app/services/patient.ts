import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root',
})
export class Patient {
  private baseUrl = 'http://localhost:8080/api/patient';

  constructor(private http: HttpClient) {}

  registerPatient(data: any) {
    return this.http.post(`${this.baseUrl}/register`, data, { responseType: 'text' });
  }
  loginPatient(data: any) {
  return this.http.post(`${this.baseUrl}/login`, data, { responseType: 'text' });
}

  getProfile(username: string) {
    return this.http.get(`${this.baseUrl}/profile/${username}`);
  }

  deleteProfile(username: string) {
    return this.http.delete(`${this.baseUrl}/profile/${username}`, { responseType: 'text' });
  }
}
