import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class Doctor {
  private baseUrl = 'http://localhost:8080/api/doctor';

  constructor(private http: HttpClient) {}

  login(data: any) {
    return this.http.post(`${this.baseUrl}/login`, data, { responseType: 'text' });
  }

  getMyAppointments(doctorId: string) {
    return this.http.get(`${this.baseUrl}/appointments/my/${doctorId}`);
  }

  updateAppointmentStatus(id: number, status: string) {
    return this.http.put(`${this.baseUrl}/appointments/update/${id}`, { status }, { responseType: 'text' });
  }
}