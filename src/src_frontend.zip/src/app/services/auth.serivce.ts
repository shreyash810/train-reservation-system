import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
    login(role:'PATIENT'|'ADMIN'|'DOCTOR'){
      localStorage.setItem('loggedIn','true');
      localStorage.setItem('role',role);
    }

    logout(){
      localStorage.clear();
    }

    isLoggedIn():boolean{
      return localStorage.getItem('loggedIn')==='true';
    }
    getRole():string|null{
      return localStorage.getItem('role');
    }
}
