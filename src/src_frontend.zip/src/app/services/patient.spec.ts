
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface PatientRegistrationPayload {
  name: string;
  email: string;
  countryCode: string;
  mobile: string;
  address: string;
  username: string;
  password: string; // will be encrypted at backend
}

export interface ExistsResponse {
  exists: boolean;
}

@Injectable({ providedIn: 'root' })
export class PatientService {
  private baseUrl = '/api/patients';

  constructor(private http: HttpClient) {}

  registerPatient(payload: PatientRegistrationPayload): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/register`, payload);
  }

  checkEmail(email: string): Observable<ExistsResponse> {
    return this.http.get<ExistsResponse>(`${this.baseUrl}/check-email`, { params: { email } });
  }

  checkUsername(username: string): Observable<ExistsResponse> {
    return this.http.get<ExistsResponse>(`${this.baseUrl}/check-username`, { params: { username } });
  }

  checkMobile(countryCode: string, mobile: string): Observable<ExistsResponse> {
    return this.http.get<ExistsResponse>(`${this.baseUrl}/check-mobile`, {
      params: { countryCode, mobile }
    });
  }
}

