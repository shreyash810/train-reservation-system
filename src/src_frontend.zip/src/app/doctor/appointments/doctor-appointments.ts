import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Doctor } from '../../services/doctor';
import { AlertService } from '../../shared/alert.service';

@Component({
  selector: 'app-doctor-appointments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './doctor-appointments.html',
  styleUrls: ['./doctor-appointments.css']
})
export class DoctorAppointments implements OnInit {

  appointments: any[] = [];
  doctorId = '';

  constructor(private doctorService: Doctor, private router: Router, private alertService: AlertService) {
    this.doctorId = localStorage.getItem('doctorId') || '';
  }

  ngOnInit() {
    this.loadAppointments();
  }

  loadAppointments() {
    this.doctorService.getMyAppointments(this.doctorId).subscribe({
      next: (res: any) => {
        this.appointments = res;
      },
      error: () => this.alertService.showAlert('Error loading appointments', 'error')
    });
  }

  updateStatus(appointment: any, event: Event) {
    const status = (event.target as HTMLSelectElement).value;
    this.doctorService.updateAppointmentStatus(appointment.id, status).subscribe({
      next: (res: string) => {
        if (res === 'UPDATED') {
          appointment.status = status;
        } else {
          this.alertService.showAlert('Error updating status', 'error');
        }
      },
      error: () => this.alertService.showAlert('Server error', 'error')
    });
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/']);
  }
}