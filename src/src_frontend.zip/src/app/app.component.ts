import { Component, OnInit, OnDestroy } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Navbar } from './shared/navbar/navbar';
import { Footer } from './shared/footer/footer';
import { AlertService } from './shared/alert.service';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, Navbar, Footer, CommonModule],
  template: `
    <app-navbar></app-navbar>

    <main class="content">
      <router-outlet></router-outlet>
    </main>

    <app-footer></app-footer>

    <!-- Alert Modal -->
    <div class="modal fade" [class.show]="alert" [style.display]="alert ? 'block' : 'none'" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header" [ngClass]="getHeaderClass()">
            <h5 class="modal-title">{{ alert?.type === 'success' ? 'Success' : alert?.type === 'error' ? 'Error' : 'Info' }}</h5>
            <button type="button" class="btn-close" (click)="closeAlert()"></button>
          </div>
          <div class="modal-body">
            {{ alert?.message }}
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" (click)="closeAlert()">Close</button>
          </div>
        </div>
      </div>
    </div>
    <div class="modal-backdrop fade show" *ngIf="alert"></div>
  `,
  styles: [`
    .content {
      min-height: calc(100vh - 120px);
    }
    .modal-header.success { background-color: #d4edda; }
    .modal-header.error { background-color: #f8d7da; }
    .modal-header.info { background-color: #d1ecf1; }
  `]
})
export class App implements OnInit, OnDestroy {
  alert: { message: string, type: string } | null = null;
  private subscription: Subscription = new Subscription();

  constructor(private alertService: AlertService) {}

  ngOnInit() {
    this.subscription = this.alertService.alert$.subscribe(alert => {
      this.alert = alert;
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  closeAlert() {
    this.alertService.hideAlert();
  }

  getHeaderClass() {
    return this.alert?.type || '';
  }
}
