
import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ComplaintService, ComplaintCategory, ContactPreference, Complaint } from '../../core/complaint.service';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-register-complaint',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './register-complaint.component.html',
  styleUrls: ['./register-complaint.component.css']
})
export class RegisterComplaintComponent {
  form!: FormGroup;

  submitted = signal<boolean>(false);
  complaintId = signal<string>('');
  message = signal<string | null>(null);

  categories: ComplaintCategory[] = [
    'Train Issue', 'Reservation Process Issue', 'Payment Issue', 'Ticket Generation Issue'
  ];
  contactOptions: ContactPreference[] = ['Call', 'Email'];

  constructor(
    private fb: FormBuilder,
    private complaints: ComplaintService,
    private auth: AuthService
  ) {
    this.form = this.fb.group({
      category: ['', [Validators.required]],
      reservationId: ['', [Validators.required]], // required per your friend’s form; can be optional per US010
      title: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(100)]],
      description: ['', [Validators.required, Validators.minLength(20), Validators.maxLength(500)]],
      contact: ['', [Validators.required]]
    });

    if (!this.auth.getSession()) {
      this.message.set('Please log in to submit a complaint.');
    }
  }

  get f() { return this.form.controls; }

  onSubmit() {
    this.message.set(null);
    this.submitted.set(false);
    this.complaintId.set('');

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.message.set('Please fill in all required fields.');
      return;
    }
    const v = this.form.value;

    const created = this.complaints.create({
      reservationId: v['reservationId']?.trim(),
      category: v['category'] as ComplaintCategory,
      title: v['title'],
      description: v['description'],
      contact: v['contact'] as ContactPreference
    });

    if (!created) {
      this.message.set('Please log in to submit a complaint.');
      return;
    }

    this.complaintId.set(created.id);
    this.submitted.set(true);
    // optionally: this.form.reset();
  }

  onReset() {
    this.form.reset();
    this.submitted.set(false);
    this.complaintId.set('');
    this.message.set(null);
  }
}
