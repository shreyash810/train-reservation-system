
// src/app/features/register/register.component.ts
import { Component, computed, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import {
  nameValidator,
  mobileValidator,
  addressMinLengthValidator,
  passwordStrengthValidator,
  matchPasswordsValidator,
  adultValidator
} from '../../shared/form-validators';
import { UserService, PassengerUser } from '../../core/user.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  // Functional DI (available during field initialization)
  private fb = inject(FormBuilder);
  private userService = inject(UserService);
  private router = inject(Router);

  maxDob = this.computeMaxDob();

  submitting = signal(false);
  submitError = signal<string | null>(null);

  registeredUser = signal<PassengerUser | null>(null);
  showSuccess = computed(() => this.registeredUser() !== null);

  form = this.fb.group({
    name: ['', [nameValidator()]],
    email: ['', [Validators.required, Validators.email], [this.userService.emailUniqueValidator()]],
    countryCode: ['', [Validators.required]],
    mobile: ['', [mobileValidator()], [this.userService.mobileUniqueValidator()]],
    address: ['', [addressMinLengthValidator(10)]],
    dob: ['', [adultValidator(18)]],
    password: ['', [passwordStrengthValidator()]],
    confirmPassword: ['', [Validators.required]]
  }, { validators: [matchPasswordsValidator('password', 'confirmPassword')] });

  private computeMaxDob(): string {
    const today = new Date();
    const max = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
    const yyyy = max.getFullYear();
    const mm = String(max.getMonth() + 1).padStart(2, '0');
    const dd = String(max.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  async onRegister() {
    this.submitError.set(null);
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting.set(true);
    const v = this.form.value;
    try {
      const user = await this.userService.registerUser({
        name: v.name!,
        email: v.email!,
        countryCode: v.countryCode!,
        mobile: v.mobile!,
        address: v.address!,
        dob: v.dob!,
        password: v.password!
      });
      this.registeredUser.set(user);
      this.form.reset();
    } catch (err: any) {
      if (err?.message === 'EMAIL_DUPLICATE') {
        this.submitError.set('Email already registered');
        this.form.get('email')?.setErrors({ emailTaken: true });
      } else if (err?.message === 'MOBILE_DUPLICATE') {
        this.submitError.set('Mobile number already registered');
        this.form.get('mobile')?.setErrors({ mobileTaken: true });
      } else {
        this.submitError.set('Registration failed. Please try again.');
      }
    } finally {
      this.submitting.set(false);
    }
  }

  onReset() {
    this.form.reset();
    this.submitError.set(null);
    this.registeredUser.set(null);
  }

  goToLogin() {
    this.registeredUser.set(null);
    this.router.navigate(['/login']);
  }

  get f() { return this.form.controls; }
}
