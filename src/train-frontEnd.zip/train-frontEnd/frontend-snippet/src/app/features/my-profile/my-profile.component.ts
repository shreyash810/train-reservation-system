
import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/auth.service';
import { UserService, PassengerUser } from '../../core/user.service';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-my-profile',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent {
  user = signal<PassengerUser | null>(null);

  constructor(private auth: AuthService, private users: UserService) {
    const session = this.auth.getSession();
    if (!session) return;
    const all = this.users.getUsers();
    const me = all.find(u => u.userId === session.userId) ?? null;
    this.user.set(me);
  }
}
