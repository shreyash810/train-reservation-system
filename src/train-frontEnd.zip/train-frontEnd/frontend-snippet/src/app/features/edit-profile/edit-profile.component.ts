
import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { UserService, PassengerUser } from '../../core/user.service';
import { addressMinLengthValidator, mobileValidator, nameValidator } from '../../shared/form-validators';

@Component({
  selector: 'app-edit-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent {
  form!: FormGroup;
  user = signal<PassengerUser | null>(null);
  message = signal<string | null>(null);
  saving = signal<boolean>(false);

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private users: UserService,
    private router: Router
  ) {
    const session = this.auth.getSession();
    if (!session) {
      this.message.set('Please log in to edit your profile.');
      return;
    }
    const me = this.users.getUsers().find(u => u.userId === session.userId) ?? null;
    this.user.set(me);

    this.form = this.fb.group({
      // Editable fields
      name: [me?.name ?? '', [nameValidator()]],
      countryCode: [me?.countryCode ?? '', [Validators.required]],
      mobile: [me?.mobile ?? '', [mobileValidator()]],
      address: [me?.address ?? '', [addressMinLengthValidator(10)]],

      // Non-editable fields for display-only (disabled controls)
      email: [{ value: me?.email ?? '', disabled: true }],
      userId: [{ value: me?.userId ?? '', disabled: true }],
      dob: [{ value: me?.dob ?? '', disabled: true }],
      createdAt: [{ value: me?.createdAt ?? '', disabled: true }]
    });
  }

  get f() { return this.form.controls; }

  async onSave() {
    this.message.set(null);
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const me = this.user();
    if (!me) return;

    this.saving.set(true);
    const v = this.form.getRawValue();

    try {
      const updated = this.users.updateUserProfile(me.userId, {
        name: v['name'],
        countryCode: v['countryCode'],
        mobile: v['mobile'],
        address: v['address']
      });
      if (!updated) {
        this.message.set('Update failed. Please try again.');
        return;
      }
      // Refresh navbar welcome name
      this.auth.updateSessionName(updated.name);

      this.message.set('Your profile has been updated successfully.');
      // Optionally navigate back after a short delay
      setTimeout(() => this.router.navigate(['/my-profile']), 800);
    } catch (err: any) {
      if (err?.message === 'MOBILE_DUPLICATE') {
        this.message.set('Please enter a valid phone number with country code (mobile already in use).');
        this.form.get('mobile')?.setErrors({ mobileTaken: true });
      } else {
        this.message.set('Please fill in all required fields.');
      }
    } finally {
      this.saving.set(false);
    }
  }
}
