
import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComplaintService, Complaint } from '../../core/complaint.service';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-view-complaints',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './view-complaints.component.html',
  styleUrls: ['./view-complaints.component.css']
})
export class ViewComplaintsComponent {
  message = signal<string | null>(null);
  complaints = signal<Complaint[]>([]);
  selected = signal<Complaint | null>(null);

  constructor(private service: ComplaintService, private auth: AuthService) {
    const session = this.auth.getSession();
    if (!session) {
      this.message.set('You have not registered any complaints.');
      return;
    }
    this.refresh(session.userId);
  }

  refresh(userId: string) {
    try {
      const list = this.service.listForUser(userId);
      this.complaints.set(list);
      if (list.length === 0) this.message.set('You have not registered any complaints.');
      else this.message.set(null);
      this.selected.set(null);
    } catch {
      this.message.set('Unable to fetch complaint status. Please try again later.');
    }
  }

  view(c: Complaint) {
    this.selected.set(c);
  }

  confirmResolution() {
    const c = this.selected();
    if (!c) return;
    const ok = this.service.confirmResolution(c.id);
    if (ok) {
      this.selected.set({ ...c, status: 'Closed', resolutionNotes: 'User confirmed resolution.' });
      const session = this.auth.getSession();
      if (session) this.refresh(session.userId);
    }
  }

  reopenComplaint() {
    const c = this.selected();
    if (!c) return;
    const ok = this.service.reopen(c.id);
    if (ok) {
      const session = this.auth.getSession();
      if (session) this.refresh(session.userId);
    }
  }
}
