
import { Component, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { TrainService, TrainResult, TrainClass } from '../../core/train.service';
import { SeatInventoryService } from '../../core/seat-inventory.service';
import { ReservationService, PassengerInfo } from '../../core/reservation.service';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-book-ticket',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './book-ticket.component.html',
  styleUrls: ['./book-ticket.component.css']
})
export class BookTicketComponent {
  // ✅ Use inject() to avoid constructor DI issues
  private fb = inject(FormBuilder);
  private trains = inject(TrainService);
  private seatInv = inject(SeatInventoryService);
  private reservations = inject(ReservationService);
  private auth = inject(AuthService);
  private router = inject(Router);

  form!: FormGroup;
  passengersForm!: FormGroup;

  results = signal<TrainResult[]>([]);
  searchError = signal<string | null>(null);

  todayISO = this.computeISO(new Date());
  maxISO = this.computeISO(this.addMonths(new Date(), 2));

  selectedTrain = signal<TrainResult | null>(null);
  selectedClass = signal<TrainClass | null>(null);
  seatsRequested = signal<number>(1);
  bookingError = signal<string | null>(null);
  bookingSuccess = signal<string | null>(null);

  showPassengerForm = signal<boolean>(false);
  lastReservationId = signal<string | null>(null);

  constructor() {
    this.form = this.fb.group({
      origin: ['', [Validators.required]],
      destination: ['', [Validators.required]],
      date: ['', [Validators.required]],
      class: ['', [Validators.required]],
    });

    this.passengersForm = this.fb.group({
      passengers: this.fb.array([])
    });
  }

  get f() { return this.form.controls; }
  get passengersArray() { return this.passengersForm.get('passengers') as any; }

  private computeISO(d: Date): string {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }
  private addMonths(d: Date, months: number): Date {
    const copy = new Date(d);
    copy.setMonth(copy.getMonth() + months);
    return copy;
  }

  onSeatInput(ev: Event) {
    const input = ev.target as HTMLInputElement;   // ✅ replace $any with proper cast
    const num = input.valueAsNumber;
    this.seatsRequested.set(Number.isFinite(num) ? Math.max(0, num) : 0);
  }

  onSearch() {
    this.searchError.set(null);
    this.results.set([]);
    this.selectedTrain.set(null);
    this.selectedClass.set(null);
    this.seatsRequested.set(1);
    this.bookingError.set(null);
    this.bookingSuccess.set(null);
    this.showPassengerForm.set(false);
    this.passengersArray.clear();
    this.lastReservationId.set(null);

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const v = this.form.value;
    const chosen = new Date(v['date']);
    const min = new Date(this.todayISO);
    const max = new Date(this.maxISO);

    if (chosen < min) {
      this.searchError.set('You cannot select previous dates. Please choose today or a future date.');
      return;
    }
    if (chosen > max) {
      this.searchError.set('You can book only within 2 months from today.');
      return;
    }

    const data = this.trains.search(v['origin'], v['destination'], v['date']);
    if (data.length === 0) {
      this.searchError.set('No trains found for the selected route and date.');
    }
    this.results.set(data);
  }

  selectTrain(train: TrainResult, clazz: TrainClass) {
    const cls = train.classes.find(c => c.type === clazz);
    if (!cls) return;

    // Init inventory for (train, date, class)
    this.seatInv.getOrInit(train.trainNo, train.date, clazz, cls.coachCount, cls.availableSeats);

    const available = this.seatInv.availableCount(train.trainNo, train.date, clazz);
    this.selectedTrain.set(train);
    this.selectedClass.set(clazz);
    this.seatsRequested.set(1);
    this.bookingError.set(null);
    this.bookingSuccess.set(null);
    this.showPassengerForm.set(false);
    this.passengersArray.clear();
    this.lastReservationId.set(null);

    if (available <= 0) {
      this.bookingError.set('No seats available. Select a different class or train.');
    }
  }

  proceedToBook() {
    this.bookingError.set(null);
    this.bookingSuccess.set(null);
    const train = this.selectedTrain();
    const clazz = this.selectedClass();
    const seats = this.seatsRequested();

    if (!train || !clazz) {
      this.bookingError.set('Please select a train and class before booking.');
      return;
    }
    const available = this.seatInv.availableCount(train.trainNo, train.date, clazz);
    if (seats <= 0) {
      this.bookingError.set('Please enter at least 1 seat.');
      return;
    }
    if (seats > available) {
      this.bookingError.set(`Only ${available} seats are available. Please select fewer seats or choose another class/train.`);
      return;
    }

    this.passengersArray.clear();
    for (let i = 0; i < seats; i++) {
      this.passengersArray.push(this.fb.group({
        name: ['', [Validators.required, Validators.pattern(/^[A-Za-z ]{2,}$/)]],
        age: ['', [Validators.required, Validators.min(1), Validators.max(120)]],
        gender: ['', [Validators.required]],
        idType: ['Aadhaar'],
        idNumber: ['XXXX-XXXX-0000']
      }));
    }
    this.showPassengerForm.set(true);
  }

  onBook() {
    if (!this.showPassengerForm()) {
      this.bookingError.set('Please click "Proceed to Book" and enter passenger details.');
      return;
    }
    if (this.passengersForm.invalid) {
      this.passengersForm.markAllAsTouched();
      this.bookingError.set('Please fill passenger details correctly.');
      return;
    }
    const train = this.selectedTrain()!;
    const clazz = this.selectedClass()!;
    const seats = this.seatsRequested();

    const allocated = this.seatInv.allocate(train.trainNo, train.date, clazz, seats);
    if (!allocated || allocated.length !== seats) {
      this.bookingError.set('Unable to allocate seats together. Please try fewer seats or another class/train.');
      return;
    }

    const passengers: PassengerInfo[] = this.passengersArray.controls.map((ctrl: any, idx: number) => ({
      name: ctrl.get('name').value,
      age: ctrl.get('age').value,
      gender: ctrl.get('gender').value,
      idType: ctrl.get('idType').value,
      idNumber: ctrl.get('idNumber').value,
      seatNumber: allocated[idx]
    }));

    const session = this.auth.getSession();
    if (!session) {
      this.bookingError.set('Your session has expired. Please log in.');
      return;
    }

    const baseAmount = train.classes.find(c => c.type === clazz)!.price * seats;

    try {
      const reservation = this.reservations.createReservation({
        userId: session.userId,
        email: session.email,
        travelDate: train.date,
        train: {
          trainNo: train.trainNo,
          trainName: train.trainName,
          origin: train.origin,
          destination: train.destination,
          originStation: train.originStation,
          destinationStation: train.destinationStation,
          departureTime: train.departureTime,
          arrivalTime: train.arrivalTime,
          class: clazz
        },
        passengers,
        seatNumbers: allocated,
        baseAmount
      });

      this.lastReservationId.set(reservation.reservationId);
      this.bookingSuccess.set(`Seats allocated: ${allocated.join(', ')}.`);
    } catch (err: any) {
      if (err?.message === 'SEAT_DUPLICATE') {
        this.bookingError.set('Duplicate seat assignment detected. Please try again.');
      } else {
        this.bookingError.set('Reservation creation failed. Please try again.');
      }
    }
  }

  goToPayment() {
    const resId = this.lastReservationId();
    if (!resId) {
      this.bookingError.set('Reservation not created yet. Please confirm seats.');
      return;
    }
    this.router.navigate(['/payments'], { queryParams: { reservationId: resId } });
  }
}
