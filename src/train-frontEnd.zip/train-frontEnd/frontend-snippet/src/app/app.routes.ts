
import { Routes } from '@angular/router';
import { authGuard } from './core/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  // public
  {
    path: 'login',
    loadComponent: () => import('./features/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'register',
    loadComponent: () => import('./features/register/register.component').then(m => m.RegisterComponent)
  },
  {
    path: 'forgot-password',
    loadComponent: () => import('./features/forgot-password/forgot-password.component').then(m => m.ForgotPasswordComponent)
  },

  // protected
  {
    path: 'home',
    canActivate: [authGuard],
    loadComponent: () => import('./features/home/home.component').then(m => m.HomeComponent)
  },
  {
    path: 'book-ticket',
    canActivate: [authGuard],
    loadComponent: () => import('./features/book-ticket/book-ticket.component').then(m => m.BookTicketComponent)
  },
  {
    path: 'my-reservations',
    canActivate: [authGuard],
    loadComponent: () => import('./features/my-reservations/my-reservations.component').then(m => m.MyReservationsComponent)
  },
  {
    path: 'payments',
    canActivate: [authGuard],
    loadComponent: () => import('./features/payments/payments.component').then(m => m.PaymentsComponent)
  },
  {
    path: 'ticket',
    canActivate: [authGuard],
    loadComponent: () => import('./features/ticket/ticket.component').then(m => m.TicketComponent)
  },


  {
    path: 'my-profile',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/my-profile/my-profile.component').then(m => m.MyProfileComponent),
  },
  {
    path: 'edit-profile',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/edit-profile/edit-profile.component').then(m => m.EditProfileComponent),
  },
  {
    path: 'register-complaint',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/register-complaint/register-complaint.component').then(m => m.RegisterComplaintComponent),
  },
  {
    path: 'view-complaints',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/view-complaints/view-complaints.component').then(m => m.ViewComplaintsComponent),
  },

  { path: '**', redirectTo: 'login' }
];
