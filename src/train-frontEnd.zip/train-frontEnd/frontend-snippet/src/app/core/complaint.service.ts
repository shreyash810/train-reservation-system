
import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';

export type ComplaintStatus = 'Open' | 'In Progress' | 'Resolved' | 'Closed';
export type ComplaintCategory =
  | 'Train Issue'
  | 'Reservation Process Issue'
  | 'Payment Issue'
  | 'Ticket Generation Issue';
export type ContactPreference = 'Call' | 'Email';

export interface Complaint {
  id: string;                     // CMP-<base36>-<rnd>
  userId: string;
  email: string;

  reservationId?: string;
  category: ComplaintCategory;
  title: string;                  // 10–100 chars
  description: string;            // 20–500 chars
  contact: ContactPreference;

  status: ComplaintStatus;        // Open → In Progress → Resolved → Closed
  createdAt: string;
  updatedAt: string;

  expectedResolutionDate?: string;
  assignedTo?: string;            // staff/dept
  response?: string;              // staff response (optional)
  resolutionNotes?: string;       // when resolved/closed
}

@Injectable({ providedIn: 'root' })
export class ComplaintService {
  private readonly LS_KEY = 'railInComplaints';

  constructor(private auth: AuthService) {}

  private getAll(): Complaint[] {
    const raw = localStorage.getItem(this.LS_KEY);
    if (!raw) return [];
    try { return JSON.parse(raw) as Complaint[]; } catch { return []; }
  }
  private setAll(list: Complaint[]) {
    localStorage.setItem(this.LS_KEY, JSON.stringify(list));
  }
  private genId(): string {
    const ts = Date.now().toString(36).toUpperCase();
    const rnd = Math.floor(Math.random() * 1e6).toString(36).toUpperCase();
    return `CMP-${ts}-${rnd}`;
  }

  /** Create a complaint for the logged-in user */
  create(payload: {
    reservationId?: string;
    category: ComplaintCategory;
    title: string;
    description: string;
    contact: ContactPreference;
  }): Complaint | null {
    const session = this.auth.getSession();
    if (!session) return null;

    const now = new Date();
    const expected = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 5);

    const c: Complaint = {
      id: this.genId(),
      userId: session.userId,
      email: session.email,
      reservationId: payload.reservationId,
      category: payload.category,
      title: payload.title.trim(),
      description: payload.description.trim(),
      contact: payload.contact,
      status: 'Open',
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
      expectedResolutionDate: expected.toISOString()
    };

    const all = this.getAll();
    all.push(c);
    this.setAll(all);
    return c;
  }

  /** List complaints for logged-in user */
  listForUser(userId: string): Complaint[] {
    return this.getAll()
      .filter(c => c.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  /** Get one complaint for user */
  getForUser(userId: string, id: string): Complaint | null {
    return this.getAll().find(c => c.userId === userId && c.id === id) ?? null;
  }

  /** Update editable fields only when status is Open */
  updateOpen(id: string, updates: Partial<Pick<Complaint, 'title'|'description'|'contact'|'category'>>): boolean {
    const all = this.getAll();
    const idx = all.findIndex(c => c.id === id);
    if (idx === -1) return false;
    if (all[idx].status !== 'Open') return false;
    all[idx] = { ...all[idx], ...updates, updatedAt: new Date().toISOString() };
    this.setAll(all);
    return true;
  }

  /** Set complaint status (staff/admin simulated) */
  setStatus(id: string, status: ComplaintStatus, notes?: string, response?: string): boolean {
    const all = this.getAll();
    const idx = all.findIndex(c => c.id === id);
    if (idx === -1) return false;
    if (all[idx].status === 'Closed') return false;

    all[idx].status = status;
    all[idx].updatedAt = new Date().toISOString();
    if (notes) all[idx].resolutionNotes = notes;
    if (response) all[idx].response = response;
    this.setAll(all);
    return true;
  }

  /** User confirms resolution → Closed */
  confirmResolution(id: string): boolean {
    return this.setStatus(id, 'Closed', 'User confirmed resolution.');
  }

  /** User reopens a Resolved complaint → Open */
  reopen(id: string): boolean {
    const all = this.getAll();
    const idx = all.findIndex(c => c.id === id);
    if (idx === -1) return false;
    if (all[idx].status !== 'Resolved') return false;
    all[idx].status = 'Open';
    all[idx].updatedAt = new Date().toISOString();
    all[idx].resolutionNotes = undefined;
    this.setAll(all);
    return true;
  }
}
