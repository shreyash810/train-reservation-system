
import { Injectable, signal } from '@angular/core';
import { Router } from '@angular/router';
import { UserService, PassengerUser } from './user.service';

/** Auth lock & session records kept in localStorage */
interface AuthRecord {
  failedAttempts: number;
  locked: boolean;
}

interface SessionState {
  email: string;
  userId: string;
  name: string;
  loggedInAt: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  /** Keys for localStorage buckets */
  private readonly AUTH_KEY = 'railInAuth';       // map of email -> AuthRecord
  private readonly SESSION_KEY = 'railInSession'; // current session
  private readonly USERS_KEY = 'railInUsers';     // users list persisted by UserService

  /**
   * Reactive session state.
   * Navbar and other components can subscribe via computed(() => auth.sessionSig()).
   */
  sessionSig = signal<SessionState | null>(this.readSessionFromStorage());

  constructor(private userService: UserService, private router: Router) { }

  // ----------------------------
  // Helpers: storage & auth map
  // ----------------------------

  /** Read current session from localStorage at service init */
  private readSessionFromStorage(): SessionState | null {
    const raw = localStorage.getItem(this.SESSION_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as SessionState;
    } catch {
      return null;
    }
  }

  /** Read the entire per-email auth map */
  private loadAuthMap(): Record<string, AuthRecord> {
    const raw = localStorage.getItem(this.AUTH_KEY);
    if (!raw) return {};
    try {
      return JSON.parse(raw) as Record<string, AuthRecord>;
    } catch {
      return {};
    }
  }

  /** Persist the auth map */
  private saveAuthMap(map: Record<string, AuthRecord>) {
    localStorage.setItem(this.AUTH_KEY, JSON.stringify(map));
  }

  /** Get (or initialize) a per-email auth record */
  private getOrInitAuth(email: string): AuthRecord {
    const map = this.loadAuthMap();
    if (!map[email]) {
      map[email] = { failedAttempts: 0, locked: false };
      this.saveAuthMap(map);
    }
    return map[email];
  }

  updateSessionName(name: string) {
    const session = this.sessionSig();
    if (!session) return;
    const next = { ...session, name };
    localStorage.setItem(this.SESSION_KEY, JSON.stringify(next));
    this.sessionSig.set(next);
  }

  /** Is the account currently locked? */
  isLocked(email: string): boolean {
    return this.getOrInitAuth(email).locked;
  }

  /** After success or reset, clear lock/attempts */
  private clearLock(email: string) {
    const map = this.loadAuthMap();
    if (map[email]) {
      map[email].failedAttempts = 0;
      map[email].locked = false;
      this.saveAuthMap(map);
    }
  }

  /** Register a failed attempt; lock at 3 attempts */
  private registerFailedAttempt(email: string) {
    const map = this.loadAuthMap();
    const rec = map[email] ?? { failedAttempts: 0, locked: false };
    rec.failedAttempts += 1;
    if (rec.failedAttempts >= 3) rec.locked = true;
    map[email] = rec;
    this.saveAuthMap(map);
  }

  // ----------------------------
  // Session management
  // ----------------------------

  /** Set session (localStorage + reactive signal) */
  private setSession(user: PassengerUser) {
    const session: SessionState = {
      email: user.email,
      userId: user.userId,
      name: user.name,
      loggedInAt: new Date().toISOString(),
    };
    localStorage.setItem(this.SESSION_KEY, JSON.stringify(session));
    this.sessionSig.set(session);
  }

  /** Clear the current session and navigate to login */
  logout() {
    localStorage.removeItem(this.SESSION_KEY);
    this.sessionSig.set(null);
    this.router.navigate(['/login']);
  }

  /** Convenience getters */
  getSession(): SessionState | null { return this.sessionSig(); }
  isLoggedIn(): boolean { return !!this.sessionSig(); }

  // ----------------------------
  // Login & Reset Password
  // ----------------------------

  /**
   * Attempt login using email + password.
   * Returns:
   *  - 'OK'      → success, session set
   *  - 'LOCKED'  → account locked after 3 failed attempts
   *  - 'INVALID' → email not found or password mismatch
   */
  async login(email: string, password: string): Promise<'OK' | 'LOCKED' | 'INVALID'> {
    email = (email ?? '').trim().toLowerCase();
    if (!email) return 'INVALID';

    // Check lock first
    if (this.isLocked(email)) return 'LOCKED';

    const users = this.userService.getUsers();
    const user = users.find(u => u.email === email);

    if (!user) {
      this.registerFailedAttempt(email);
      return this.isLocked(email) ? 'LOCKED' : 'INVALID';
    }

    // Hash the provided password and compare with stored hash
    const hash = await this.userService.hashPassword(password ?? '');
    if (hash !== user.passwordHash) {
      this.registerFailedAttempt(email);
      return this.isLocked(email) ? 'LOCKED' : 'INVALID';
    }

    // Success → clear lock and set session
    this.clearLock(email);
    this.setSession(user);
    return 'OK';
  }

  /**
   * Reset password (US002: Forgot Password).
   * - Updates the user's stored SHA-256 hash.
   * - Clears lockout for that email.
   * Returns:
   *  - 'OK'        → updated
   *  - 'NOT_FOUND' → no account for email
   */
  async resetPassword(email: string, newPassword: string): Promise<'OK' | 'NOT_FOUND'> {
    email = (email ?? '').trim().toLowerCase();

    // Read existing users (via UserService localStorage bucket)
    const usersRaw = localStorage.getItem(this.USERS_KEY);
    const users: PassengerUser[] = usersRaw ? JSON.parse(usersRaw) : [];

    const idx = users.findIndex(u => u.email === email);
    if (idx === -1) return 'NOT_FOUND';

    // Hash new password (same mechanism as UserService.registerUser)
    const newHash = await this.userService.hashPassword(newPassword);
    users[idx].passwordHash = newHash;

    // Persist updated users list
    localStorage.setItem(this.USERS_KEY, JSON.stringify(users));

    // Clear lock & attempts for the account
    const map = this.loadAuthMap();
    if (map[email]) {
      map[email].failedAttempts = 0;
      map[email].locked = false;
      this.saveAuthMap(map);
    }

    return 'OK';
  }
}
