
import { Injectable } from '@angular/core';
import { UserService } from './user.service';
import { SeatInventoryService } from './seat-inventory.service';

/** Status of a reservation */
export type ReservationStatus = 'pending' | 'confirmed' | 'completed' | 'canceled';

/** Payment state */
export type PaymentStatus = 'PAID' | 'PENDING';

/** Passenger record */
export interface PassengerInfo {
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  idType?: string;
  idNumber?: string;
  seatNumber?: string; // e.g., A1-01
}

/** Train details per reservation */
export interface TrainDetails {
  trainNo: string;
  trainName: string;
  origin: string;
  destination: string;
  originStation: string;
  destinationStation: string;
  departureTime: string;  // 'HH:mm'
  arrivalTime: string;    // 'HH:mm'
  class: 'GENERAL' | 'SLEEPER' | 'AC';
}

/** Reservation stored in localStorage */
export interface Reservation {
  reservationId: string;
  userId: string;
  email: string;

  travelDate: string;      // ISO yyyy-MM-dd
  createdAt: string;       // ISO timestamp
  canceledAt?: string;

  train: TrainDetails;
  passengers: PassengerInfo[];
  seatNumbers: string[];   // seat labels matching passengers (same order)

  amount: number;          // current payable (base or total after payment)
  paymentStatus: PaymentStatus;
  paymentTransactionId?: string;

  status: ReservationStatus;
  checkedIn?: boolean;     // block cancellation if true
}

@Injectable({ providedIn: 'root' })
export class ReservationService {
  private readonly LS_KEY = 'railInReservations';

  constructor(
    private userService: UserService,
    private seatInv: SeatInventoryService
  ) {}

  /* -----------------------------
     Storage helpers
  ----------------------------- */

  private getAll(): Reservation[] {
    const raw = localStorage.getItem(this.LS_KEY);
    if (!raw) return [];
    try { return JSON.parse(raw) as Reservation[]; } catch {
      // reset corrupted storage to avoid cascading errors
      localStorage.removeItem(this.LS_KEY);
      return [];
    }
  }

  private setAll(list: Reservation[]) {
    localStorage.setItem(this.LS_KEY, JSON.stringify(list));
  }

  /* -----------------------------
     Queries
  ----------------------------- */

  /** List reservations for the given user (most recent travelDate first) */
  getForUser(userId: string): Reservation[] {
    const all = this.getAll().filter(r => r.userId === userId);
    return all.sort((a, b) => new Date(b.travelDate).getTime() - new Date(a.travelDate).getTime());
  }

  /** Get a specific reservation by id for the given user */
  getById(userId: string, reservationId: string): Reservation | null {
    return this.getAll().find(r => r.userId === userId && r.reservationId === reservationId) ?? null;
  }

  /** Mark past (non-canceled) reservations as completed */
  markCompletedWhereApplicable() {
    const today = this.toISODate(new Date());
    const all = this.getAll();
    let changed = false;
    for (const r of all) {
      if (r.status !== 'canceled' && r.travelDate < today) {
        if (r.status !== 'completed') {
          r.status = 'completed';
          changed = true;
        }
      }
    }
    if (changed) this.setAll(all);
  }

  /* -----------------------------
     Time helpers
  ----------------------------- */

  /** Format a Date into ISO yyyy-MM-dd */
  toISODate(d: Date): string {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  /**
   * Hours from now until the travel date (00:00 of travel date for simplicity).
   * Negative means past the allowed window.
   */
  hoursToDeparture(travelDateISO: string): number {
    const now = new Date();
    const travelDate = new Date(`${travelDateISO}T00:00:00`);
    const diffMs = travelDate.getTime() - now.getTime();
    return Math.floor(diffMs / 36e5); // ms → hours
  }

  /* -----------------------------
     Refund policy
  ----------------------------- */

  /**
   * Refund percentage based on hours remaining:
   *  - >= 48 hours: 100%
   *  - 24–48 hours: 50%
   *  - < 24 hours: 0%
   */
  computeRefundPercentage(hoursToDeparture: number): number {
    if (hoursToDeparture >= 48) return 100;
    if (hoursToDeparture >= 24) return 50;
    return 0;
  }

  /* -----------------------------
     Cancellation flow
  ----------------------------- */

  /**
   * Cancel a reservation (with password confirmation).
   * Returns structured outcome to display on UI.
   */
  async cancelReservation(opts: {
    userId: string;
    email: string;
    reservationId: string;
    passwordPlain: string;
  }): Promise<{
    ok: boolean;
    message: string;
    refundAmount?: number;
    canceledAt?: string;
    status?: ReservationStatus;
  }> {
    const { userId, email, reservationId, passwordPlain } = opts;
    const all = this.getAll();
    const idx = all.findIndex(r => r.userId === userId && r.reservationId === reservationId);
    if (idx === -1) {
      return { ok: false, message: 'Reservation not found.' };
    }

    const res = all[idx];

    // Already canceled?
    if (res.status === 'canceled') {
      return {
        ok: false,
        message: `This Reservation was canceled on ${res.canceledAt ? res.canceledAt.substring(0, 10) : 'earlier'}.`
      };
    }

    // Checked in? Block cancellation.
    if (res.checkedIn) {
      return { ok: false, message: 'Cancellation not allowed: Reservation already checked in.' };
    }

    // Past departure? Block cancellation.
    const hours = this.hoursToDeparture(res.travelDate);
    if (hours < 0) {
      return { ok: false, message: 'This Reservation cannot be canceled as it is past the allowed cancellation window.' };
    }

    // Confirm password by hashing and comparing
    const users = this.userService.getUsers();
    const user = users.find(u => u.userId === userId && u.email === email);
    if (!user) {
      return { ok: false, message: 'User account not found.' };
    }
    const hash = await this.userService.hashPassword(passwordPlain);
    if (hash !== user.passwordHash) {
      return { ok: false, message: 'Invalid password. Please try again.' };
    }

    // Compute refund & update reservation
    const percent = this.computeRefundPercentage(hours);
    const refundAmount = Math.round((res.amount * percent) / 100);

    res.status = 'canceled';
    res.canceledAt = new Date().toISOString();
    all[idx] = res;
    this.setAll(all);

    // Release seats back to inventory
    this.seatInv.release(res.train.trainNo, res.travelDate, res.train.class, res.seatNumbers);

    const msg = percent > 0
      ? `Your Reservation has been canceled. A refund of ₹${refundAmount} will be processed within 3-5 business days.`
      : 'As per the ticket cancellation policy, this Reservation is non-refundable.';

    return { ok: true, message: msg, refundAmount, canceledAt: res.canceledAt, status: res.status };
  }

  /* -----------------------------
     Fees & Payment
  ----------------------------- */

  /** Fee breakdown (demo rates) */
  calculateFees(baseAmount: number, passengerCount: number) {
    const gst = Math.round(baseAmount * 0.18);      // 18% GST on base
    const convenience = passengerCount * 20;        // ₹20 per passenger
    const platform = 10;                             // flat ₹10 platform fee
    const total = baseAmount + gst + convenience + platform;
    return { baseAmount, gst, convenience, platform, total };
  }

  /**
   * Mark reservation as PAID (success), set transaction id & final amount.
   * If status was 'pending', switch to 'confirmed'.
   */
  markPaid(userId: string, reservationId: string, txnId: string, paidAmount: number): boolean {
    const all = this.getAll();
    const idx = all.findIndex(r => r.userId === userId && r.reservationId === reservationId);
    if (idx === -1) return false;
    const r = all[idx];
    r.paymentStatus = 'PAID';
    r.paymentTransactionId = txnId;
    r.amount = paidAmount;
    if (r.status === 'pending') r.status = 'confirmed';
    all[idx] = r;
    this.setAll(all);
    return true;
  }

  /* -----------------------------
     Create reservation (after seat allocation)
  ----------------------------- */

  /**
   * Create a pending reservation.
   * Prevent duplicate seat assignment for the same train/date/class.
   */
  createReservation(input: {
    userId: string;
    email: string;
    travelDate: string;
    train: TrainDetails;
    passengers: PassengerInfo[];
    seatNumbers: string[];
    baseAmount: number;
  }): Reservation {
    // Prevent duplicate seats for same train/date/class
    const all = this.getAll();
    const conflict = all.some(r =>
      r.train.trainNo === input.train.trainNo &&
      r.travelDate === input.travelDate &&
      r.train.class === input.train.class &&
      r.status !== 'canceled' &&
      r.seatNumbers.some(s => input.seatNumbers.includes(s))
    );
    if (conflict) {
      throw new Error('SEAT_DUPLICATE');
    }

    const reservation: Reservation = {
      reservationId: `RSV-${Date.now().toString(36).toUpperCase()}-${Math.floor(Math.random() * 1e6).toString(36).toUpperCase()}`,
      userId: input.userId,
      email: input.email,
      travelDate: input.travelDate,
      createdAt: new Date().toISOString(),
      train: input.train,
      passengers: input.passengers.map((p, i) => ({ ...p, seatNumber: input.seatNumbers[i] })),
      seatNumbers: input.seatNumbers.slice(),
      amount: input.baseAmount,      // base; total after payment will be set by markPaid()
      paymentStatus: 'PENDING',
      status: 'pending',
      checkedIn: false
    };

    all.push(reservation);
    this.setAll(all);
    return reservation;
  }

  /* -----------------------------
     Demo seeding (optional)
  ----------------------------- */

  /** Seed some sample reservations for a user (use once for testing) */
  seedDemoForUser(userId: string, email: string) {
    const all = this.getAll();
    const now = new Date();
    const todayISO = this.toISODate(now);
    const plus3 = this.toISODate(new Date(now.getFullYear(), now.getMonth(), now.getDate() + 3));
    const minus2 = this.toISODate(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 2));

    const newOnes: Reservation[] = [
      {
        reservationId: `RSV-${Date.now().toString(36).toUpperCase()}-A`,
        userId, email,
        travelDate: plus3,
        createdAt: new Date().toISOString(),
        train: {
          trainNo: '12001', trainName: 'Shatabdi Express',
          origin: 'Pune', destination: 'Mumbai',
          originStation: 'Pune Jn', destinationStation: 'CSMT',
          departureTime: '08:30', arrivalTime: '12:10',
          class: 'AC'
        },
        passengers: [
          { name: 'John Doe', age: 28, gender: 'Male', idType: 'Aadhaar', idNumber: 'XXXX-XXXX-1234', seatNumber: 'A1-01' },
          { name: 'Jane Doe', age: 26, gender: 'Female', idType: 'PAN', idNumber: 'ABCPD1234Z', seatNumber: 'A1-02' }
        ],
        seatNumbers: ['A1-01', 'A1-02'],
        amount: 1300,
        paymentStatus: 'PAID',
        paymentTransactionId: 'TXN-987654',
        status: 'confirmed',
        checkedIn: false
      },
      {
        reservationId: `RSV-${Date.now().toString(36).toUpperCase()}-B`,
        userId, email,
        travelDate: todayISO,
        createdAt: new Date().toISOString(),
        train: {
          trainNo: '17015', trainName: 'Deccan Queen',
          origin: 'Pune', destination: 'Mumbai',
          originStation: 'Pune Jn', destinationStation: 'Dadar',
          departureTime: '07:15', arrivalTime: '11:00',
          class: 'SLEEPER'
        },
        passengers: [
          { name: 'Alice', age: 34, gender: 'Female', idType: 'Aadhaar', idNumber: 'XXXX-XXXX-5678', seatNumber: 'S1-12' }
        ],
        seatNumbers: ['S1-12'],
        amount: 350,
        paymentStatus: 'PENDING',
        status: 'pending',
        checkedIn: false
      },
      {
        reservationId: `RSV-${Date.now().toString(36).toUpperCase()}-C`,
        userId, email,
        travelDate: minus2,
        createdAt: new Date().toISOString(),
        train: {
          trainNo: '11029', trainName: 'Koyna Express',
          origin: 'Pune', destination: 'Kolhapur',
          originStation: 'Pune Jn', destinationStation: 'C Shahumaharaj',
          departureTime: '09:45', arrivalTime: '17:20',
          class: 'GENERAL'
        },
        passengers: [
          { name: 'Bob', age: 42, gender: 'Male', idType: 'Aadhaar', idNumber: 'XXXX-XXXX-0001', seatNumber: 'G3-22' }
        ],
        seatNumbers: ['G3-22'],
        amount: 100,
        paymentStatus: 'PAID',
        paymentTransactionId: 'TXN-123456',
        status: 'completed',
        checkedIn: false
      }
    ];

    this.setAll([...all, ...newOnes]);
  }
}
