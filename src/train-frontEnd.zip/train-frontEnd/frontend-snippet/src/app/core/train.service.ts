
import { Injectable } from '@angular/core';

export type TrainClass = 'GENERAL' | 'SLEEPER' | 'AC';
export interface TrainResult {
  trainNo: string;
  trainName: string;
  origin: string;
  destination: string;
  originStation: string;
  destinationStation: string;
  departureTime: string;  // e.g., '08:30'
  arrivalTime: string;    // e.g., '16:45'
  date: string;           // ISO yyyy-MM-dd
  classes: {
    type: TrainClass;
    availableSeats: number;
    coachCount: number;
    price: number;
  }[];
}

@Injectable({ providedIn: 'root' })
export class TrainService {
  // Simple in-memory mock dataset
  private mockTrains: Omit<TrainResult, 'date'>[] = [
    {
      trainNo: '12001',
      trainName: 'Shatabdi Express',
      origin: 'Pune',
      destination: 'Mumbai',
      originStation: 'Pune Jn',
      destinationStation: 'CSMT',
      departureTime: '08:30',
      arrivalTime: '12:10',
      classes: [
        { type: 'GENERAL', availableSeats: 40, coachCount: 4, price: 150 },
        { type: 'SLEEPER', availableSeats: 24, coachCount: 2, price: 350 },
        { type: 'AC', availableSeats: 18, coachCount: 3, price: 650 }
      ]
    },
    {
      trainNo: '17015',
      trainName: 'Deccan Queen',
      origin: 'Pune',
      destination: 'Mumbai',
      originStation: 'Pune Jn',
      destinationStation: 'Dadar',
      departureTime: '07:15',
      arrivalTime: '11:00',
      classes: [
        { type: 'GENERAL', availableSeats: 55, coachCount: 5, price: 120 },
        { type: 'SLEEPER', availableSeats: 0, coachCount: 0, price: 300 }, // full sleeper
        { type: 'AC', availableSeats: 12, coachCount: 2, price: 600 }
      ]
    },
    {
      trainNo: '11029',
      trainName: 'Koyna Express',
      origin: 'Pune',
      destination: 'Kolhapur',
      originStation: 'Pune Jn',
      destinationStation: 'C Shahumaharaj',
      departureTime: '09:45',
      arrivalTime: '17:20',
      classes: [
        { type: 'GENERAL', availableSeats: 73, coachCount: 7, price: 100 },
        { type: 'SLEEPER', availableSeats: 30, coachCount: 3, price: 280 },
        { type: 'AC', availableSeats: 8, coachCount: 2, price: 560 }
      ]
    }
  ];

  search(origin: string, destination: string, date: string): TrainResult[] {
    const o = origin.trim().toLowerCase();
    const d = destination.trim().toLowerCase();
    return this.mockTrains
      .filter(t => t.origin.toLowerCase() === o && t.destination.toLowerCase() === d)
      .map(t => ({ ...t, date }));
  }
}
``
