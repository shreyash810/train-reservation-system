import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
    FormBuilder,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { CustomerLayoutComponent } from '../../../layout/main-layout/customer-layout/customer-layout.component';
import { BookingService } from '../../../core/service/booking.service';
import { SupportService, ISupportTicket } from '../../../core/service/support.service';

@Component({
    selector: 'app-support',
    standalone: true,
    imports: [CustomerLayoutComponent, CommonModule, ReactiveFormsModule],
    templateUrl: './support.component.html',
    styleUrl: './support.component.css',
})
export class SupportComponent {
    private fb = inject(FormBuilder);
    private bookingService = inject(BookingService);
    private supportService = inject(SupportService);

    companyEmail = 'shipin@gmail.com';
    supportPhone = '+91 98765 43210';
    workingDays = 'Mon – Sat';
    workingHours = '9:00 AM – 6:00 PM';

    activeModal: 'register' | 'track' | null = null;
    isSuccess = false;
    isError = false;
    generatedTicketId: string | null = null;
    trackedTicket: ISupportTicket | null = null;
    trackError = '';

    complaintForm = this.fb.group({
        bookingId: ['', Validators.required],
        title: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(100)]],
        description: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(1000)]],
    });

    trackingForm = this.fb.group({
        ticketId: ['', Validators.required],
    });

    openModal(type: 'register' | 'track') {
        this.activeModal = type;
        this.resetState();
    }

    closeModal() {
        this.activeModal = null;
    }

    onRegister() {
        if (this.complaintForm.invalid) return;
        const { bookingId, title, description } = this.complaintForm.value;

        if (!this.bookingService.getAllBookings().data?.some(b => b.bookingId === bookingId)) {
            this.isError = true;
            return;
        }

        this.generatedTicketId = this.supportService.createTicket(
            { title: title!, description: description! },
            bookingId!
        );
        this.isSuccess = true;
        this.isError = false;
    }

    onTrack() {
        if (this.trackingForm.invalid) return;
        this.trackedTicket = this.supportService.getTicket(this.trackingForm.value.ticketId!) || null;
        this.trackError = this.trackedTicket ? '' : 'Ticket ID not found';
    }

    private resetState() {
        this.isSuccess = false;
        this.isError = false;
        this.generatedTicketId = null;
        this.trackedTicket = null;
        this.trackError = '';
        this.complaintForm.reset();
        this.trackingForm.reset();
    }
}
