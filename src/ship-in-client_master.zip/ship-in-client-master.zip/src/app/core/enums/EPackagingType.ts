export enum EPackagingType {
    BASIC = 'BASIC',
    PREMIUM = 'PREMIUM',
}
