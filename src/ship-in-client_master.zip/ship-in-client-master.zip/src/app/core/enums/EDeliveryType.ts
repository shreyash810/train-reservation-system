export enum EDeliveryType {
    STANDARD = 'STANDARD',
    EXPRESS = 'EXPRESS',
    SAME_DAY = 'SAME_DAY',
}
