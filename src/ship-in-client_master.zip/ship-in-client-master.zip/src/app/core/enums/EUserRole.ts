export enum EUserRole {
    OFFICER = 'OFFICER',
    CUSTOMER = 'CUSTOMER',
}
