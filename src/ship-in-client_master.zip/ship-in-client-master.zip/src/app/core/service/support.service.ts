import { Injectable } from '@angular/core';
import { ISupportTicketRequest } from '../interfaces/request/supportTicketRequest';

export interface ISupportTicket extends ISupportTicketRequest {
    ticketId: string;
    bookingId: string; // Ensure bookingId is part of the ticket
    status: 'Open' | 'Closed';
    createdAt: Date;
}

@Injectable({
    providedIn: 'root',
})
export class SupportService {
    private tickets: ISupportTicket[] = [];

    constructor() { }

    createTicket(request: ISupportTicketRequest, bookingId: string): string {
        const ticketId = this.generateTicketId();
        const newTicket: ISupportTicket = {
            ...request,
            bookingId,
            ticketId,
            status: 'Open',
            createdAt: new Date(),
        };
        this.tickets.push(newTicket);
        return ticketId;
    }

    getTicket(ticketId: string): ISupportTicket | undefined {
        return this.tickets.find((t) => t.ticketId === ticketId);
    }

    private generateTicketId(): string {
        const timestamp = Date.now().toString().slice(-6);
        const random = Math.floor(Math.random() * 1000)
            .toString()
            .padStart(3, '0');
        return `TKT-${timestamp}-${random}`;
    }
}
