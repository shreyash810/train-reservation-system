export interface ISupportTicketRequest {
    title: string;
    description: string;
}
