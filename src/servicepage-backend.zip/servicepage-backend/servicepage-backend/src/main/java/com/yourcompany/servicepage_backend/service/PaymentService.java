package com.yourcompany.servicepage_backend.service;

import com.yourcompany.servicepage_backend.dto.PaymentResponseDTO;
import com.yourcompany.servicepage_backend.entity.Payment;
import com.yourcompany.servicepage_backend.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    public Map<String, Object> getPayments(String searchTerm, String status, String startDate, String endDate,
                                           int page, int size, String sortCol, boolean sortAsc) {

        // 1. Handle Sorting
        Sort sort = sortAsc ? Sort.by(sortCol).ascending() : Sort.by(sortCol).descending();
        Pageable pageable = PageRequest.of(page - 1, size, sort); // Spring pages start at 0

        // 2. Handle Inputs
        LocalDateTime start = (startDate != null && !startDate.isEmpty()) ? LocalDate.parse(startDate).atStartOfDay() : null;
        LocalDateTime end = (endDate != null && !endDate.isEmpty()) ? LocalDate.parse(endDate).atTime(23, 59, 59) : null;
        String statusFilter = (status != null && !status.equals("All")) ? status : null;
        String search = (searchTerm != null && !searchTerm.isEmpty()) ? searchTerm : null;

        // 3. Query DB
        Page<Payment> paymentPage = paymentRepository.findPaymentsWithFilters(search, statusFilter, start, end, pageable);

        // 4. Convert to DTO
        Page<PaymentResponseDTO> dtoPage = paymentPage.map(p -> new PaymentResponseDTO(
                p.getPaymentId(),
                p.getAmount(),
                p.getCreatedAt(),
                p.getStatus(),
                p.getTransactionId()
        ));

        // 5. Build Response
        Map<String, Object> response = new HashMap<>();
        response.put("data", dtoPage.getContent());
        response.put("total", dtoPage.getTotalElements());

        return response;
    }
}