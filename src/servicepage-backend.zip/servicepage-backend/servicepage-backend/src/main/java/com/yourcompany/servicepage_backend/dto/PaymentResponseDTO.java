package com.yourcompany.servicepage_backend.dto;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
public class PaymentResponseDTO {
    private String billId;      // Maps to paymentId
    private String tenantName;  // Placeholder (derived from bookingId)
    private String dateOfIssue; // Maps to createdAt
    private Double amount;
    private String status;
    private String transactionId;

    // Constructor to convert Entity to DTO
    public PaymentResponseDTO(UUID id, Double amt, LocalDateTime date, String stat, String transId) {
        this.billId = id.toString();
        this.tenantName = "Tenant associated with Booking"; // Logic to fetch tenant name can go here
        this.dateOfIssue = date.toString().split("T")[0]; // Format YYYY-MM-DD
        this.amount = amt;
        this.status = stat;
        this.transactionId = transId;
    }
}