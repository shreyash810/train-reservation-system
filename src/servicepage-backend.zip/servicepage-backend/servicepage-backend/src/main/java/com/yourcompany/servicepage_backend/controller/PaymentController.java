package com.yourcompany.servicepage_backend.controller;

import com.yourcompany.servicepage_backend.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "http://localhost:4200") // Allow Angular access
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @GetMapping
    public ResponseEntity<Map<String, Object>> getPayments(
            @RequestParam(required = false) String search,
            @RequestParam(required = false, defaultValue = "All") String status,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortCol,
            @RequestParam(defaultValue = "false") boolean sortAsc
    ) {
        // Map frontend sort columns to DB columns
        String dbSortCol = sortCol.equals("dateOfIssue") ? "createdAt" : sortCol;
        if(sortCol.equals("billId")) dbSortCol = "paymentId";

        return ResponseEntity.ok(paymentService.getPayments(search, status, startDate, endDate, page, size, dbSortCol, sortAsc));
    }
}