import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-complaint-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './complaint-form.component.html',
  styleUrls: ['./complaint-form.component.css']
})
export class ComplaintFormComponent {

  complaint = {
    category: '',
    reservationId: '',
    title: '',
    description: '',
    contactPreference: ''
  };

  submitted = false;
  complaintId = '';

  submitComplaint() {
    this.complaintId = 'CMP' + Math.floor(100000 + Math.random() * 900000);
    this.submitted = true;
  }

  resetForm(form: any) {
    form.reset();
    this.submitted = false;
  }
}
