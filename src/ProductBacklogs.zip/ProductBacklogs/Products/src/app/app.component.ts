
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminHomeComponent } from './admin-home/admin-home.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, AdminHomeComponent], // <-- import here
  templateUrl: './app.component.html'
})
export class AppComponent {}
