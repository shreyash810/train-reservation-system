import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompliantTrackingComponent } from './compliant-tracking.component';

describe('CompliantTrackingComponent', () => {
  let component: CompliantTrackingComponent;
  let fixture: ComponentFixture<CompliantTrackingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CompliantTrackingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompliantTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
