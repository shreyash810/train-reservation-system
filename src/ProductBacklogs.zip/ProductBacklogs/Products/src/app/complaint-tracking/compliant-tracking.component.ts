import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-complaint-tracking',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './complaint-tracking.component.html',
  styleUrls: ['./complaint-tracking.component.css']
})
export class ComplaintTracking {

  complaints = [
    {
      id: 'CMP1001',
      category: 'Payment Issue',
      title: 'Amount debited twice',
      description: 'My amount was debited twice during booking.',
      submittedDate: '10-Jan-2026',
      expectedDate: '15-Jan-2026',
      status: 'Resolved',
      response: 'Support team has checked the issue.',
      resolutionNotes: 'Refund initiated successfully.'
    },
    {
      id: 'CMP1002',
      category: 'Train Issue',
      title: 'Train delayed',
      description: 'Train was delayed by 2 hours.',
      submittedDate: '08-Jan-2026',
      expectedDate: '12-Jan-2026',
      status: 'In Progress',
      response: 'Support team is working on this issue.',
      resolutionNotes: ''
    }
  ];

  selectedComplaint: any = null;

  viewComplaint(c: any) {
    this.selectedComplaint = c;
  }

  confirmResolution() {
    this.selectedComplaint.status = 'Closed';
  }

  reopenComplaint() {
    this.selectedComplaint.status = 'In Progress';
  }
}