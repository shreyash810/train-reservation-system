import { Routes } from '@angular/router';
import { ComplaintTracking } from './complaint-tracking/compliant-tracking.component';

export const routes: Routes = [
  { path: '', redirectTo: 'track-complaint', pathMatch: 'full' },
  { path: 'track-complaint', component: ComplaintTracking },
  {}
];