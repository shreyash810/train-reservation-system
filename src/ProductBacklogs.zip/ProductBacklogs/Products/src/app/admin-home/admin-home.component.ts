
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

type Train = { id:number; name:string; origin:string; destination:string; date:string; type:string };
type Reservation = { id:number; passengerName:string; trainId:number; date:string };
type Passenger = { id:number; name:string; email:string; phone:string };

@Component({
  selector: 'app-admin-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent {
  // auth + profile
  isAdmin = true; adminName = 'Abhinav'; adminEmail = 'admin@example.com'; adminRole = 'System Admin'; editing = false;
  // nav
  tab:'dashboard'|'booking'|'reservations'|'passengers'|'reports'|'profile' = 'dashboard'; go(t:any){ this.tab=t; }
  logout(){ this.isAdmin=false; this.tab='dashboard'; } login(){ this.isAdmin=true; }

  // sample data
  trains:Train[] = [
    { id:1, name:'Deccan Express', origin:'Pune', destination:'Mumbai', date:'2026-01-08', type:'Express' },
    { id:2, name:'Indrayani', origin:'Mumbai', destination:'Pune', date:'2026-01-09', type:'Superfast' },
    { id:3, name:'Intercity', origin:'Pune', destination:'Solapur', date:'2026-01-07', type:'Passenger' }
  ];
  reservations:Reservation[] = [
    { id:1001, passengerName:'Ravi Kumar', trainId:1, date:'2026-01-07' },
    { id:1002, passengerName:'Sneha Patil', trainId:2, date:'2026-01-07' },
    { id:1003, passengerName:'Aisha Khan', trainId:3, date:'2026-01-06' },
    { id:1004, passengerName:'Mukesh', trainId:2, date:'2026-01-05' }
  ];
  passengers:Passenger[] = [
    { id:1, name:'Ravi Kumar', email:'ravi@example.com', phone:'9000000001' },
    { id:2, name:'Sneha Patil', email:'sneha@example.com', phone:'9000000002' },
    { id:3, name:'Aisha Khan', email:'aisha@example.com', phone:'9000000003' }
  ];

  // dashboard (daily/weekly/monthly + bar width)
  today(){ return new Date().toISOString().slice(0,10); }
  totalDaily(){ return this.reservations.filter(r=>r.date===this.today()).length; }
  totalWeekly(){ const n=new Date(), w=new Date(n); w.setDate(n.getDate()-7); return this.reservations.filter(r=>{const d=new Date(r.date);return d>=w&&d<=n;}).length; }
  totalMonthly(){ const n=new Date(), s=new Date(n.getFullYear(),n.getMonth(),1), e=new Date(n.getFullYear(),n.getMonth()+1,0); return this.reservations.filter(r=>{const d=new Date(r.date);return d>=s&&d<=e;}).length; }
  max(){ return Math.max(1,this.totalDaily(),this.totalWeekly(),this.totalMonthly()); }
  w(n:number){ return Math.round(n/this.max()*100)+'%'; }

  // booking management (search/list/add/update/remove)
  search={origin:'',destination:'',date:'',type:''};
  newTrain:Train={id:0,name:'',origin:'',destination:'',date:'',type:''};
  selected:Train|null=null;
  trainsF(){ const s=this.search; return this.trains.filter(t=>
    (!s.origin||t.origin.toLowerCase().includes(s.origin.toLowerCase())) &&
    (!s.destination||t.destination.toLowerCase().includes(s.destination.toLowerCase())) &&
    (!s.date||t.date===s.date) &&
    (!s.type||t.type.toLowerCase().includes(s.type.toLowerCase()))
  );}
  addTrain(){ const f=this.newTrain; if(!f.name||!f.origin||!f.destination||!f.date||!f.type){alert('Fill all train fields');return;}
    const id=(this.trains.at(-1)?.id||0)+1; this.trains.push({...f,id}); this.newTrain={id:0,name:'',origin:'',destination:'',date:'',type:''}; }
  editTrain(t:Train){ this.selected={...t}; }
  saveTrain(){ if(!this.selected)return; const i=this.trains.findIndex(x=>x.id===this.selected!.id); if(i>-1){ this.trains[i]={...this.selected!}; this.selected=null; } }
  removeTrain(t:Train){ this.trains=this.trains.filter(x=>x.id!==t.id); }

  // reservation management
  resFor(trainId:number){ return this.reservations.filter(r=>r.trainId===trainId); }

  // passenger management (search/add/remove)
  pSearch=''; newPassenger:Passenger={id:0,name:'',email:'',phone:''};
  passengersF(){ const q=this.pSearch.toLowerCase(); return this.passengers.filter(p=>!q||p.name.toLowerCase().includes(q)); }
  addPassenger(){ const f=this.newPassenger; if(!f.name||!f.email||!f.phone){alert('Fill all passenger fields');return;}
    const id=(this.passengers.at(-1)?.id||0)+1; this.passengers.push({...f,id}); this.newPassenger={id:0,name:'',email:'',phone:''}; }
  removePassenger(p:Passenger){ this.passengers=this.passengers.filter(x=>x.id!==p.id); }

  // reports
  countType(t:string){ return this.trains.filter(x=>x.type.toLowerCase()===t.toLowerCase()).length; }

  // profile
  edit(){ this.editing=true; } save(){ this.editing=false; alert('Profile saved (UI-only)'); } cancel(){ this.editing=false; }
}
