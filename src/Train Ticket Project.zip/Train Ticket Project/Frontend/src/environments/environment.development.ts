
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api',   // All backend API calls hit this URL
  brandColor: '#1e3a8a'
};
