
package com.ilp.trainticket.dto;

import java.time.LocalDate;

public class RegisterRequest {
    public String name;
    public String email;
    public String mobile;
    public String address;
    public LocalDate dob;
    public String password;
}
