package com.example.HMS.Hospital.Managment.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalManagmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
