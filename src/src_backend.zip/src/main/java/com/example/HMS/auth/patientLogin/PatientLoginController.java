package com.example.HMS.auth.patientLogin;

import java.util.Map;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/patient")
@CrossOrigin(origins = "http://localhost:4200")
public class PatientLoginController {

    private final PatientLoginService service;

    public PatientLoginController(PatientLoginService service) {
        this.service = service;
    }

    @PostMapping("/login")
    public String login(@RequestBody Map<String, String> data) {

        String username = data.get("username");
        String password = data.get("password");

        return service.login(username, password);
    }
}
