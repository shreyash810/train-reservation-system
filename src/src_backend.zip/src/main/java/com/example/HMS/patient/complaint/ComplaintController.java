package com.example.HMS.patient.complaint;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/patient/complaint")
@CrossOrigin(origins = "http://localhost:4200")
public class ComplaintController {

    private final ComplaintService service;

    public ComplaintController(ComplaintService service) {
        this.service = service;
    }

    @PostMapping("/register")
    public String register(@RequestBody ComplaintEntity complaint) {
        return service.registerComplaint(complaint);
    }

    @GetMapping("/track/{username}")
    public List<ComplaintEntity> track(@PathVariable String username) {
        return service.getComplaintsByUsername(username);
    }
}