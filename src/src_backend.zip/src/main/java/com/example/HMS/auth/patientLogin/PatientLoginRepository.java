package com.example.HMS.auth.patientLogin;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.HMS.auth.patientRegister.PatientEntity;

public interface PatientLoginRepository extends JpaRepository<PatientEntity, Long> {

    Optional<PatientEntity> findByUsernameAndPassword(String username, String password);
}

