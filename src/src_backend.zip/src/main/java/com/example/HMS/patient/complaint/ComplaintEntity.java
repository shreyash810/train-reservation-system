package com.example.HMS.patient.complaint;

import jakarta.persistence.*;

@Entity
@Table(name = "complaints")
public class ComplaintEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String subject;
    private String description;
    @Column(columnDefinition = "VARCHAR(255) DEFAULT 'open'")
    private String status;
    private String date;

    public ComplaintEntity() {
    }

    public ComplaintEntity(String username, String subject, String description, String status, String date) {
        this.username = username;
        this.subject = subject;
        this.description = description;
        this.status = status;
        this.date = date;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}