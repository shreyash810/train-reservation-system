package com.example.HMS.auth.adminLogin;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AdminLoginRepository extends JpaRepository<AdminEntity, Long> {

    @Query("SELECT a FROM AdminEntity a WHERE a.username = ?1 AND a.password = ?2")
    Optional<AdminEntity> findByUsernameAndPassword(String username, String password);
}
