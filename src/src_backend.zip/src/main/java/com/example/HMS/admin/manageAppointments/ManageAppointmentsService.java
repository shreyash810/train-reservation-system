package com.example.HMS.admin.manageAppointments;

import org.springframework.stereotype.Service;
import com.example.HMS.patient.scheduleAppointment.AppointmentEntity;
import com.example.HMS.patient.scheduleAppointment.AppointmentRepository;
import java.util.List;

@Service
public class ManageAppointmentsService {

    private final AppointmentRepository repo;

    public ManageAppointmentsService(AppointmentRepository repo) {
        this.repo = repo;
    }

    public List<AppointmentEntity> getAllAppointments() {
        return repo.findAll();
    }
}