package com.example.HMS.patient.scheduleAppointment;

import java.time.LocalDate;
import java.time.DayOfWeek;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.HMS.admin.manageDoctor.DoctorRepository;
import com.example.HMS.admin.manageDoctor.DoctorEntity;

@Service
public class AppointmentService {

    private final DoctorRepository doctorRepo;
    private final AppointmentRepository appointmentRepo;

    public AppointmentService(DoctorRepository doctorRepo, AppointmentRepository appointmentRepo) {
        this.doctorRepo = doctorRepo;
        this.appointmentRepo = appointmentRepo;
    }

    // Helper method to check if date is within doctor's availability
    private boolean isDateAvailableForDoctor(String availability, LocalDate date) {
        DayOfWeek day = date.getDayOfWeek();
        switch (availability) {
            case "Monday to Friday":
                return day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY;
            case "Monday to Saturday":
                return day != DayOfWeek.SUNDAY;
            case "Monday to Sunday":
                return true;
            case "Saturday to Sunday":
                return day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY;
            default:
                return false;
        }
    }

    // Search doctors by specialization
    public List<DoctorEntity> searchDoctors(String specialization, String date) {

        // Validation: date must not be past
        LocalDate inputDate = LocalDate.parse(date);
        if (inputDate.isBefore(LocalDate.now())) {
            return List.of(); // Return empty list for past dates
        }

        return doctorRepo.findAll()
                .stream()
                .filter(d -> d.getSpecialization().equalsIgnoreCase(specialization))
                .filter(d -> isDateAvailableForDoctor(d.getAvailability(), inputDate))
                .toList();
    }

    // Book appointment
    public String bookAppointment(AppointmentEntity appointment) {
        // Find doctor
        DoctorEntity doctor = doctorRepo.findById(appointment.getDoctorId()).orElse(null);
        if (doctor == null) {
            return "DOCTOR_NOT_FOUND";
        }

        // Check availability
        LocalDate appDate = LocalDate.parse(appointment.getAppointmentDate());
        if (!isDateAvailableForDoctor(doctor.getAvailability(), appDate)) {
            return "DOCTOR_NOT_AVAILABLE";
        }

        // Set default status to "open" if not provided
        if (appointment.getStatus() == null || appointment.getStatus().isEmpty()) {
            appointment.setStatus("open");
        }
        appointmentRepo.save(appointment);
        return "APPOINTMENT_BOOKED";
    }
}
