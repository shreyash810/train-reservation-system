package com.example.HMS.auth.patientRegister;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/patient")
@CrossOrigin(origins = "http://localhost:4200")
public class PatientRegisterController {

    private final PatientService service;

    public PatientRegisterController(PatientService service) {
        this.service = service;
    }

    @PostMapping("/register")
    public String register(@RequestBody PatientEntity patient) {
        return service.register(patient);
    }

    @GetMapping("/test")
       public String test() {
       return "API WORKING";
    }
}

