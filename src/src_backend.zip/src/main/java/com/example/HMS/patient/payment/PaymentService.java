package com.example.HMS.patient.payment;

import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    private final PaymentRepository repo;

    public PaymentService(PaymentRepository repo) {
        this.repo = repo;
    }

    public String processPayment(PaymentEntity payment) {
        // Assume payment is successful
        payment.setStatus("success");
        repo.save(payment);
        return "PAYMENT_SUCCESS";
    }
}