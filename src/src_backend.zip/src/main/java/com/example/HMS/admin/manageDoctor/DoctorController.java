package com.example.HMS.admin.manageDoctor;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/doctor")
@CrossOrigin("*")
public class DoctorController {

    private final DoctorService service;

    public DoctorController(DoctorService service) {
        this.service = service;
    }

    @PostMapping("/add")
    public String addDoctor(@RequestBody DoctorEntity doctor) {
        return service.addDoctor(doctor);
    }

    @PutMapping("/update")
    public String updateDoctor(@RequestBody DoctorEntity doctor) {
        return service.updateDoctor(doctor);
    }

    @GetMapping("/all")
    public List<DoctorEntity> getDoctors() {
        return service.getAllDoctors();
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable String id) {
        service.deleteDoctor(id);
    }
}

