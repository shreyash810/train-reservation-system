package com.example.HMS.patient.payment;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/patient/payment")
@CrossOrigin(origins = "http://localhost:4200")
public class PaymentController {

    private final PaymentService service;

    public PaymentController(PaymentService service) {
        this.service = service;
    }

    @PostMapping("/process")
    public String process(@RequestBody PaymentEntity payment) {
        return service.processPayment(payment);
    }
}