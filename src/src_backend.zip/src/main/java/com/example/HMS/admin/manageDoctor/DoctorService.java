package com.example.HMS.admin.manageDoctor;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {

    private final DoctorRepository repo;

    public DoctorService(DoctorRepository repo) {
        this.repo = repo;
    }

    public String addDoctor(DoctorEntity doctor) {

        if (!doctor.getName().matches("^[A-Za-z ]+$"))
            return "NAME_INVALID";

        if (doctor.getExperience() <= 0)
            return "EXPERIENCE_INVALID";

        if (!doctor.getDoctorId().startsWith("DR"))
            return "ID_INVALID";

        repo.save(doctor);
        return "ADDED";
    }

    public String updateDoctor(DoctorEntity doctor) {
        repo.save(doctor);
        return "UPDATED";
    }

    public List<DoctorEntity> getAllDoctors() {
        return repo.findAll();
    }

    public void deleteDoctor(String id) {
        repo.deleteById(id);
    }
}

