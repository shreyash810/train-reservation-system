package com.example.HMS.admin.manageAppointments;

import org.springframework.web.bind.annotation.*;
import com.example.HMS.patient.scheduleAppointment.AppointmentEntity;
import java.util.List;

@RestController
@RequestMapping("/api/admin/appointments")
@CrossOrigin(origins = "http://localhost:4200")
public class ManageAppointmentsController {

    private final ManageAppointmentsService service;

    public ManageAppointmentsController(ManageAppointmentsService service) {
        this.service = service;
    }

    @GetMapping("/all")
    public List<AppointmentEntity> getAllAppointments() {
        return service.getAllAppointments();
    }
}