package com.example.HMS.auth.patientLogin;

import org.springframework.stereotype.Service;

@Service
public class PatientLoginService {

    private final PatientLoginRepository repo;

    public PatientLoginService(PatientLoginRepository repo) {
        this.repo = repo;
    }

    public String login(String username, String password) {
        return repo.findByUsernameAndPassword(username, password).isPresent()
                ? "SUCCESS"
                : "INVALID";
    }
}
