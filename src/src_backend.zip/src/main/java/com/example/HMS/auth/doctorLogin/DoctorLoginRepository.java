package com.example.HMS.auth.doctorLogin;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.example.HMS.admin.manageDoctor.DoctorEntity;

public interface DoctorLoginRepository extends JpaRepository<DoctorEntity, String> {

    @Query("SELECT d FROM DoctorEntity d WHERE d.doctorId = ?1 AND d.password = ?2")
    Optional<DoctorEntity> findByDoctorIdAndPassword(String doctorId, String password);
}