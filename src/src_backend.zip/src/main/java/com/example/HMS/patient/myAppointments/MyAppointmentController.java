package com.example.HMS.patient.myAppointments;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.example.HMS.patient.scheduleAppointment.AppointmentEntity;

@RestController
@RequestMapping("/api/patient/appointments")
@CrossOrigin(origins = "http://localhost:4200")
public class MyAppointmentController {

    private final MyAppointmentService service;

    public MyAppointmentController(MyAppointmentService service) {
        this.service = service;
    }

    // ✅ Get my appointments
    @GetMapping("/my/{username}")
    public List<AppointmentEntity> getMyAppointments(@PathVariable String username) {
        return service.getMyAppointments(username);
    }

    // ✅ Reschedule appointment
    @PutMapping("/reschedule/{id}")
    public String reschedule(
            @PathVariable Long id,
            @RequestBody RescheduleRequest req) {

        return service.reschedule(id, req.getNewDate());
    }

    // ✅ Cancel appointment
    @DeleteMapping("/cancel/{id}")
    public String cancel(@PathVariable Long id) {
        return service.cancel(id);
    }
}
