package com.example.HMS.patient.scheduleAppointment;

import com.example.HMS.admin.manageDoctor.DoctorEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patient/appointment")
@CrossOrigin("*")
public class AppointmentController {

    private final AppointmentService service;

    public AppointmentController(AppointmentService service) {
        this.service = service;
    }

    // Search doctors
    @GetMapping("/search")
    public Object searchDoctors(
            @RequestParam String specialization,
            @RequestParam String date
    ) {
        List<DoctorEntity> result = service.searchDoctors(specialization, date);

        if (result == null)
            return "Appointment date cannot be in the past";

        if (result.isEmpty())
            return "No Doctor Found";

        return result;
    }

    // Book appointment
    @PostMapping("/book")
    public String book(@RequestBody AppointmentEntity appointment) {
        return service.bookAppointment(appointment);
    }
}

