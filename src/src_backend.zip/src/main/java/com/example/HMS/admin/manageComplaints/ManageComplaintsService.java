package com.example.HMS.admin.manageComplaints;

import org.springframework.stereotype.Service;
import com.example.HMS.patient.complaint.ComplaintEntity;
import com.example.HMS.patient.complaint.ComplaintRepository;
import java.util.List;

@Service
public class ManageComplaintsService {

    private final ComplaintRepository repo;

    public ManageComplaintsService(ComplaintRepository repo) {
        this.repo = repo;
    }

    public List<ComplaintEntity> getAllComplaints() {
        return repo.findAll();
    }

    public String updateStatus(Long id, String status) {
        ComplaintEntity complaint = repo.findById(id).orElse(null);
        if (complaint == null)
            return "NOT_FOUND";
        complaint.setStatus(status);
        repo.save(complaint);
        return "UPDATED";
    }
}