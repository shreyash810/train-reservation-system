package com.example.HMS.patient.profile;

import org.springframework.web.bind.annotation.*;
import com.example.HMS.auth.patientRegister.PatientEntity;

@RestController
@RequestMapping("/api/patient/profile")
@CrossOrigin(origins = "http://localhost:4200")
public class ProfileController {

    private final ProfileService service;

    public ProfileController(ProfileService service) {
        this.service = service;
    }

    @GetMapping("/{username}")
    public PatientEntity getProfile(@PathVariable String username) {
        return service.getProfile(username);
    }

    @DeleteMapping("/{username}")
    public String deleteProfile(@PathVariable String username) {
        return service.deleteProfile(username);
    }
}