package com.example.HMS.auth.doctorLogin;

import org.springframework.stereotype.Service;

@Service
public class DoctorLoginService {

    private final DoctorLoginRepository repo;

    public DoctorLoginService(DoctorLoginRepository repo) {
        this.repo = repo;
    }

    public String login(String doctorId, String password) {
        return repo.findByDoctorIdAndPassword(doctorId, password).isPresent()
                ? "SUCCESS"
                : "INVALID";
    }
}