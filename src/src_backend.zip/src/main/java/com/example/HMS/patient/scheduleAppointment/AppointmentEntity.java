package com.example.HMS.patient.scheduleAppointment;

import jakarta.persistence.*;

@Entity
@Table(name = "appointments")
public class AppointmentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    private String doctorId;
    private String patientName;
    private String appointmentDate;
    private String specialization;
    private String reason; // ✅ NEW FIELD
    @Column(columnDefinition = "VARCHAR(255) DEFAULT 'open'")
    private String status;

    public AppointmentEntity() {
    }

    public AppointmentEntity(String username, String doctorId, String patientName, String appointmentDate,
            String specialization, String reason, String status) {
        this.username = username;
        this.doctorId = doctorId;
        this.patientName = patientName;
        this.appointmentDate = appointmentDate;
        this.specialization = specialization;
        this.reason = reason;
        this.status = status;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // existing getters/setters remain same
}
