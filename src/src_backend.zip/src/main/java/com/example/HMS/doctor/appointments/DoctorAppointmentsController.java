package com.example.HMS.doctor.appointments;

import org.springframework.web.bind.annotation.*;
import com.example.HMS.patient.scheduleAppointment.AppointmentEntity;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/doctor/appointments")
@CrossOrigin(origins = "http://localhost:4200")
public class DoctorAppointmentsController {

    private final DoctorAppointmentsService service;

    public DoctorAppointmentsController(DoctorAppointmentsService service) {
        this.service = service;
    }

    @GetMapping("/my/{doctorId}")
    public List<AppointmentEntity> getMyAppointments(@PathVariable String doctorId) {
        return service.getMyAppointments(doctorId);
    }

    @PutMapping("/update/{id}")
    public String updateStatus(@PathVariable Long id, @RequestBody Map<String, String> data) {
        String status = data.get("status"); // accept or decline
        return service.updateStatus(id, status);
    }
}