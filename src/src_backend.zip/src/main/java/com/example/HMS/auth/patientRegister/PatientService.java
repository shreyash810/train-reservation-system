package com.example.HMS.auth.patientRegister;

import org.springframework.stereotype.Service;

@Service
public class PatientService {

    private final PatientRepository repo;

    public PatientService(PatientRepository repo) {
        this.repo = repo;
    }

    public String register(PatientEntity patient) {

        if (repo.existsByEmail(patient.getEmail()))
            return "EMAIL_EXISTS";

        if (repo.existsByMobile(patient.getMobile()))
            return "MOBILE_EXISTS";

        if (repo.existsByUsername(patient.getUsername()))
            return "USERNAME_EXISTS";

        repo.save(patient);
        return "SUCCESS";
    }
}

