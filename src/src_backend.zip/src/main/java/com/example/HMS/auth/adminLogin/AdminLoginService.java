package com.example.HMS.auth.adminLogin;

import org.springframework.stereotype.Service;

@Service
public class AdminLoginService {

    private final AdminLoginRepository repo;

    public AdminLoginService(AdminLoginRepository repo) {
        this.repo = repo;
    }

    public boolean login(String username, String password) {
        return "admin".equals(username) && "admin123".equals(password);
    }
}
