package com.example.HMS.patient.myAppointments;

public class RescheduleRequest {

    private String newDate;

    public String getNewDate() {
        return newDate;
    }

    public void setNewDate(String newDate) {
        this.newDate = newDate;
    }
}

