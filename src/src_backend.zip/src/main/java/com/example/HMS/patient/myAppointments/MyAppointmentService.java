package com.example.HMS.patient.myAppointments;

import org.springframework.stereotype.Service;
import com.example.HMS.patient.scheduleAppointment.AppointmentEntity;
import java.util.List;

@Service
public class MyAppointmentService {

    private final MyAppointmentRepository repo;

    public MyAppointmentService(MyAppointmentRepository repo) {
        this.repo = repo;
    }

    // ✅ Get my appointments
    public List<AppointmentEntity> getMyAppointments(String username) {
        return repo.findByUsername(username);
    }

    // ✅ Reschedule
    public String reschedule(Long id, String newDate) {
        AppointmentEntity appt = repo.findById(id).orElse(null);

        if (appt == null) {
            return "NOT_FOUND";
        }

        appt.setAppointmentDate(newDate);
        repo.save(appt);

        return "RESCHEDULED";
    }

    // ✅ Cancel
    public String cancel(Long id) {
        if (!repo.existsById(id)) {
            return "NOT_FOUND";
        }

        repo.deleteById(id);
        return "CANCELLED";
    }
}
