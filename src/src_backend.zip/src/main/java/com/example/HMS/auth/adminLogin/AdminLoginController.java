package com.example.HMS.auth.adminLogin;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:4200")
public class AdminLoginController {

    private final AdminLoginService service;

    public AdminLoginController(AdminLoginService service) {
        this.service = service;
    }

    @PostMapping("/login")
    public String login(@RequestBody AdminEntity admin) {
        boolean success = service.login(admin.getUsername(), admin.getPassword());

        if (success) {
            return "SUCCESS";
        } else {
            return "INVALID";
        }
    }
}
