package com.example.HMS.patient.complaint;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ComplaintService {

    private final ComplaintRepository repo;

    public ComplaintService(ComplaintRepository repo) {
        this.repo = repo;
    }

    public String registerComplaint(ComplaintEntity complaint) {
        if (complaint.getStatus() == null || complaint.getStatus().isEmpty()) {
            complaint.setStatus("open");
        }
        repo.save(complaint);
        return "COMPLAINT_REGISTERED";
    }

    public List<ComplaintEntity> getComplaintsByUsername(String username) {
        return repo.findByUsername(username);
    }
}