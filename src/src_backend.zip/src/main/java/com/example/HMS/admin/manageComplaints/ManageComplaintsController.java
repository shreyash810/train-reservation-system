package com.example.HMS.admin.manageComplaints;

import org.springframework.web.bind.annotation.*;
import com.example.HMS.patient.complaint.ComplaintEntity;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/complaints")
@CrossOrigin(origins = "http://localhost:4200")
public class ManageComplaintsController {

    private final ManageComplaintsService service;

    public ManageComplaintsController(ManageComplaintsService service) {
        this.service = service;
    }

    @GetMapping("/all")
    public List<ComplaintEntity> getAllComplaints() {
        return service.getAllComplaints();
    }

    @PutMapping("/update/{id}")
    public String updateStatus(@PathVariable Long id, @RequestBody Map<String, String> data) {
        String status = data.get("status");
        return service.updateStatus(id, status);
    }
}