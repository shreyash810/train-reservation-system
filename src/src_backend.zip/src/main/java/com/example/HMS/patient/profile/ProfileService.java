package com.example.HMS.patient.profile;

import org.springframework.stereotype.Service;
import com.example.HMS.auth.patientRegister.PatientEntity;
import com.example.HMS.auth.patientRegister.PatientRepository;

@Service
public class ProfileService {

    private final PatientRepository repo;

    public ProfileService(PatientRepository repo) {
        this.repo = repo;
    }

    public PatientEntity getProfile(String username) {
        return repo.findByUsername(username).orElse(null);
    }

    public String deleteProfile(String username) {
        PatientEntity patient = repo.findByUsername(username).orElse(null);
        if (patient == null)
            return "NOT_FOUND";
        repo.delete(patient);
        return "DELETED";
    }
}