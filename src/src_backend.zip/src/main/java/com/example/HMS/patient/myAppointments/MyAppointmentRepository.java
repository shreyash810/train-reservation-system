package com.example.HMS.patient.myAppointments;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.HMS.patient.scheduleAppointment.AppointmentEntity;
import java.util.List;

public interface MyAppointmentRepository extends JpaRepository<AppointmentEntity, Long> {

    List<AppointmentEntity> findByUsername(String username);
}
