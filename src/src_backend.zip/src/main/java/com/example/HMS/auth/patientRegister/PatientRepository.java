package com.example.HMS.auth.patientRegister;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PatientRepository extends JpaRepository<PatientEntity, Long> {

    boolean existsByEmail(String email);

    boolean existsByMobile(String mobile);

    boolean existsByUsername(String username);

    Optional<PatientEntity> findByUsername(String username);
}
