package com.example.HMS.auth.doctorLogin;

import java.util.Map;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/doctor")
@CrossOrigin(origins = "http://localhost:4200")
public class DoctorLoginController {

    private final DoctorLoginService service;

    public DoctorLoginController(DoctorLoginService service) {
        this.service = service;
    }

    @PostMapping("/login")
    public String login(@RequestBody Map<String, String> data) {

        String doctorId = data.get("doctorId");
        String password = data.get("password");

        return service.login(doctorId, password);
    }
}