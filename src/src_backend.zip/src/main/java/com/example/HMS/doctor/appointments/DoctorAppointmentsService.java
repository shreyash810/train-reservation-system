package com.example.HMS.doctor.appointments;

import org.springframework.stereotype.Service;
import com.example.HMS.patient.scheduleAppointment.AppointmentEntity;
import com.example.HMS.patient.scheduleAppointment.AppointmentRepository;
import java.util.List;

@Service
public class DoctorAppointmentsService {

    private final AppointmentRepository repo;

    public DoctorAppointmentsService(AppointmentRepository repo) {
        this.repo = repo;
    }

    public List<AppointmentEntity> getMyAppointments(String doctorId) {
        return repo.findByDoctorId(doctorId);
    }

    public String updateStatus(Long id, String status) {
        AppointmentEntity appt = repo.findById(id).orElse(null);
        if (appt == null)
            return "NOT_FOUND";
        appt.setStatus(status); // accept or decline
        repo.save(appt);
        return "UPDATED";
    }
}