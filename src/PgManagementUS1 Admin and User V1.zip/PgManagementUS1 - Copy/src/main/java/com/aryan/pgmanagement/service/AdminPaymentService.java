package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.AdminPaymentDTO;
import com.aryan.pgmanagement.model.Booking;
import com.aryan.pgmanagement.model.PgCustomer;
import com.aryan.pgmanagement.repo.BookingRepo;
import com.aryan.pgmanagement.repo.PaymentRepo;
import com.aryan.pgmanagement.repo.PgRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class AdminPaymentService {

    @Autowired
    private PaymentRepo paymentRepo;

    @Autowired
    private BookingRepo bookingRepo;

    @Autowired
    private PgRepo pgRepo;

    public List<AdminPaymentDTO> getAllPayments() {

        return paymentRepo.findAll()
                .stream()
                .map(payment -> {

                    // 1️⃣ Get Booking
                    Booking booking = bookingRepo.findById(payment.getBookingId())
                            .orElseThrow(() ->
                                    new ResponseStatusException(
                                            HttpStatus.NOT_FOUND,
                                            "Booking not found for payment " + payment.getPaymentId()
                                    )
                            );

                    // 2️⃣ Get User
                    PgCustomer customer = pgRepo.findById(booking.getUserId())
                            .orElseThrow(() ->
                                    new ResponseStatusException(
                                            HttpStatus.NOT_FOUND,
                                            "User not found for booking " + booking.getBookingId()
                                    )
                            );

                    // 3️⃣ Build DTO
                    return new AdminPaymentDTO(
                            payment.getPaymentId(),
                            payment.getTransactionId(),        // Bill ID
                            customer.getTenantName(),          // ✅ REAL TENANT NAME
                            payment.getAmount(),
                            payment.getStatus(),
                            payment.getPaymentMethod(),
                            payment.getCreatedAt()
                    );
                })
                .toList();
    }
}
