package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.AdminDashboardDTO;
import com.aryan.pgmanagement.repo.BookingRepo;
import com.aryan.pgmanagement.repo.PaymentRepo;
import com.aryan.pgmanagement.repo.PgRepo;
import com.aryan.pgmanagement.repo.RoomRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminDashboardService {

    @Autowired
    private PgRepo pgRepo;

    @Autowired
    private RoomRepo roomRepo;

    @Autowired
    private BookingRepo bookingRepo;

    @Autowired
    private PaymentRepo paymentRepo;

    public AdminDashboardDTO getDashboardSummary() {

        return new AdminDashboardDTO(
                pgRepo.count(),
                roomRepo.count(),
                bookingRepo.count(),
                paymentRepo.count()
        );
    }
}
