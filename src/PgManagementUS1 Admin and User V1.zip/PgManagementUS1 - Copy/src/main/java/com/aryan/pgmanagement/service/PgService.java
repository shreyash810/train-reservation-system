package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.*;
import com.aryan.pgmanagement.model.PgCustomer;
import com.aryan.pgmanagement.repo.PgRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class PgService {

    @Autowired
    private PgRepo repo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public TenantRegistrationResponse registerCustomer(TenantRegistrationRequest req) {

        String email = req.getMail().toLowerCase().trim();
        String username = req.getUsername().toLowerCase().trim();
        String mobileNumber = req.getMobileNumber().trim();

        if (repo.existsByEmail(email)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already registered");
        }

        if (repo.existsByUsername(username)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Username already registered");
        }

        if (repo.existsByMobileNumber(mobileNumber)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Mobile number already registered");
        }

        String hashedPassword = passwordEncoder.encode(req.getPassword());

        PgCustomer pgCustomer = new PgCustomer();

        pgCustomer.setTenantName(req.getTenantName());
        pgCustomer.setEmail(email);
        pgCustomer.setCountryCode(req.getCountryCode());
        pgCustomer.setMobileNumber(mobileNumber);
        pgCustomer.setAddress(req.getAddress());
        pgCustomer.setUsername(username);
        pgCustomer.setPassword(hashedPassword);
        pgCustomer.setLoginTries(0);
        pgCustomer.setAccountBlocked(false);

// ✅ NEW FIELDS
        pgCustomer.setRole("TENANT");
        pgCustomer.setForcePasswordChange(false);
        pgCustomer.setActive(true);

        repo.save(pgCustomer);


        repo.save(pgCustomer);

        return new TenantRegistrationResponse(
                "Registration Successful",
                pgCustomer.getUserId(),
                pgCustomer.getTenantName(),
                pgCustomer.getEmail()
        );
    }

    public List<PgCustomer> viewAllCustomers() {
        return repo.findAll();
    }

    public LoginResponse loginPage(LoginRequest req) {

        PgCustomer customer = repo.findByUsername(req.getUserName());

        if (customer == null) {
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Username not found"
            );
        }

        if (Boolean.TRUE.equals(customer.getAccountBlocked())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Account is blocked"
            );
        }

        if (!passwordEncoder.matches(req.getPassword(), customer.getPassword())) {

            customer.setLoginTries(customer.getLoginTries() + 1);

            if (customer.getLoginTries() >= 3) {
                customer.setAccountBlocked(true);
                repo.save(customer);

                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "Account is blocked"
                );
            }

            repo.save(customer);
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Invalid Password"
            );
        }
        customer.setLoginTries(0);
        repo.save(customer);

        return new LoginResponse(
                "Login Successful",
                customer.getUserId(),
                customer.getUsername()
        );
    }

    public ProfileResponse homepage(String username){
        PgCustomer customer = repo.findByUsername(username);

        if (customer == null) {
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Username not found");
        }

        if (Boolean.TRUE.equals(customer.getAccountBlocked())) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Account is blocked"
            );
        }

        return new ProfileResponse(customer.getUserId(), customer.getTenantName(), customer.getUsername(), customer.getEmail(), customer.getCountryCode(), customer.getMobileNumber(), customer.getAddress());
    }

}
