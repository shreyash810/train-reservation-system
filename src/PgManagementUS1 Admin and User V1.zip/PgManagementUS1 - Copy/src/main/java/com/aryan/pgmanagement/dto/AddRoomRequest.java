package com.aryan.pgmanagement.dto;

import lombok.Data;

import java.util.List;

@Data
public class AddRoomRequest {

    private String roomType;        // Shared / Single
    private double pricePerDay;     // positive
    private boolean availability;   // true / false
    private List<String> amenities; // optional
    private String description;     // max 500 chars
}
