package com.aryan.pgmanagement.dto;

import lombok.Data;

@Data
public class CreateUserRequest {
    private String username;
    private String email;
    private String role;        // ADMIN / TENANT / SUPPORT
    private String mobileNumber;
    private String countryCode;
    private String address;
}
