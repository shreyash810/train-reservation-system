package com.aryan.pgmanagement.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "complaints")
public class Complaint {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID complaintId;

    @Column(nullable = false)
    private UUID bookingId;

    @Column(nullable = false)
    private UUID userId;

    @Column(nullable = false, length = 50)
    private String category;
    // ROOM_ISSUE, SERVICE_ISSUE, BILLING_ISSUE, OTHER

    @Column(nullable = false, length = 100)
    private String title;

    @Column(nullable = false, length = 500)
    private String description;

    @Column(nullable = false, length = 10)
    private String contactPreference;
    // CALL, EMAIL

    @Column(nullable = false, length = 20)
    private String status;
    // OPEN, IN_PROGRESS, RESOLVED

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @Column(length = 500)
    private String supportResponse;

    @Column(length = 500)
    private String resolutionNotes;

    @Column(nullable = false)
    private LocalDate expectedResolutionDate;
}
