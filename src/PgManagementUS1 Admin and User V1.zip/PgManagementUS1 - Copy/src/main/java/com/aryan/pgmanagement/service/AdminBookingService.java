package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.AdminBookingCreateRequest;
import com.aryan.pgmanagement.dto.AdminBookingListDTO;
import com.aryan.pgmanagement.dto.AdminBookingUpdateRequest;
import com.aryan.pgmanagement.dto.BookingResponse;
import com.aryan.pgmanagement.model.Booking;
import com.aryan.pgmanagement.model.PgCustomer;
import com.aryan.pgmanagement.model.Room;
import com.aryan.pgmanagement.repo.BookingRepo;
import com.aryan.pgmanagement.repo.PgRepo;
import com.aryan.pgmanagement.repo.RoomRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

@Service
public class AdminBookingService {

    @Autowired
    private BookingRepo bookingRepo;
    @Autowired private PgRepo pgRepo;
    @Autowired private RoomRepo roomRepo;

    public List<AdminBookingListDTO> getAllBookings() {

        return bookingRepo.findAll().stream().map(b -> {
            PgCustomer user = pgRepo.findById(b.getUserId()).orElse(null);
            Room room = roomRepo.findById(b.getRoomId()).orElse(null);

            return new AdminBookingListDTO(
                    b.getBookingId(),
                    b.getRoomId(),
                    user != null ? user.getTenantName() : "N/A",
                    room != null ? room.getRoomNumber() : "N/A",
                    b.getFromDate(),
                    b.getToDate(),
                    b.getStatus(),
                    b.getTotalCost()
            );
        }).toList();
    }

    public void updateBooking(UUID bookingId, AdminBookingUpdateRequest req) {

        Booking booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Booking not found"));

        if (List.of("CHECKED_IN", "COMPLETED").contains(booking.getStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Checked-in or completed bookings cannot be modified");
        }

        boolean conflict = bookingRepo
                .existsByRoomIdAndStatusInAndFromDateLessThanEqualAndToDateGreaterThanEqual(
                        req.getRoomId(),
                        List.of("CONFIRMED"),
                        req.getToDate(),
                        req.getFromDate()
                );

        if (conflict) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Room not available for selected dates");
        }

        booking.setRoomId(req.getRoomId());
        booking.setFromDate(req.getFromDate());
        booking.setToDate(req.getToDate());

        bookingRepo.save(booking);
    }

    public void cancelBooking(UUID bookingId) {

        Booking booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Booking not found"));

        if (List.of("CHECKED_IN", "COMPLETED").contains(booking.getStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Checked-in or completed bookings cannot be canceled");
        }

        booking.setStatus("CANCELLED");
        bookingRepo.save(booking);
    }

    public BookingResponse createBooking(AdminBookingCreateRequest req) {

        // 1️⃣ Validate user
        PgCustomer user = pgRepo.findById(req.getUserId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User not found"));

        // 2️⃣ Validate room
        Room room = roomRepo.findById(req.getRoomId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Room not found"));

        // 3️⃣ Date validation
        if (req.getFromDate().isAfter(req.getToDate())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Invalid booking date range");
        }

        // 4️⃣ Availability check
        boolean conflict = bookingRepo
                .existsByRoomIdAndFromDateLessThanEqualAndToDateGreaterThanEqual(
                        room.getRoomId(),
                        req.getToDate(),
                        req.getFromDate()
                );

        if (conflict) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "Room not available for selected dates");
        }

        // 5️⃣ Create booking ✅ FIXED
        Booking booking = new Booking();
        booking.setUserId(user.getUserId());
        booking.setRoomId(room.getRoomId());
        booking.setFromDate(req.getFromDate());
        booking.setToDate(req.getToDate());
        booking.setPaymentMethod(req.getPaymentMethod());
        booking.setStatus("CONFIRMED");
        booking.setTotalCost(room.getPricePerDay());
        booking.setCreatedAt(LocalDateTime.now());

        bookingRepo.save(booking);

        return new BookingResponse(
                booking.getBookingId(),
                "Booking created successfully by admin",
                booking.getTotalCost(),
                booking.getStatus()
        );
    }
}

