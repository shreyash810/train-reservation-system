package com.aryan.pgmanagement.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "invoices")
public class Invoice {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "invoice_id", nullable = false, updatable = false)
    private UUID invoiceId;

    @Column(name = "booking_id", nullable = false, unique = true)
    private UUID bookingId;

    @Column(name = "transaction_id", nullable = false)
    private String transactionId;

    @Column(name = "payment_method", nullable = false)
    private String paymentMethod;

    @Column(name = "base_price", nullable = false)
    private double basePrice;

    @Column(name = "gst", nullable = false)
    private double gst;

    @Column(name = "service_charge", nullable = false)
    private double serviceCharge;

    @Column(name = "total_amount", nullable = false)
    private double totalAmount;

    @Column(name = "generated_at", nullable = false)
    private LocalDateTime generatedAt;
}
