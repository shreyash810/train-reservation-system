package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AddRoomResponse {

    private String message;
    private String roomNumber;
    private String roomType;
    private double pricePerDay;
}

