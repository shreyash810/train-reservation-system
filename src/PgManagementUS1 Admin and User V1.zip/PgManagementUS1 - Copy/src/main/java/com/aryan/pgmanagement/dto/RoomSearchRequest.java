package com.aryan.pgmanagement.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;

@Data
public class RoomSearchRequest {

    @NotNull(message = "Available-from date is required")
    private LocalDate availableFrom;

    @NotNull(message = "Available-to date is required")
    private LocalDate availableTo;

    @NotBlank(message = "Please select a type.")
    private String roomType;
}
