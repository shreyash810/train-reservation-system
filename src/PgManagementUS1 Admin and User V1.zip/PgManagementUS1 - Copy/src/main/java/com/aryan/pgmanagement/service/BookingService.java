package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.*;
import com.aryan.pgmanagement.model.Booking;
import com.aryan.pgmanagement.model.PgCustomer;
import com.aryan.pgmanagement.model.Room;
import com.aryan.pgmanagement.repo.BookingRepo;
import com.aryan.pgmanagement.repo.PgRepo;
import com.aryan.pgmanagement.repo.RoomRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

@Service
public class BookingService {

    @Autowired
    private RoomRepo roomRepo;

    @Autowired
    private PgRepo pgRepo;

    @Autowired
    private BookingRepo bookingRepo;

    public BookingConfirmationResponse initiateBooking(BookingInitiateRequest req) {

        Room room = roomRepo.findById(req.getRoomId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Room not found"));

        PgCustomer user = pgRepo.findById(req.getUserId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User not found"));

        if (req.getFromDate().isBefore(LocalDate.now())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Booking date cannot be in the past");
        }

        if (req.getFromDate().isAfter(req.getToDate())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Invalid booking date range");
        }

        List<Booking> conflicts =
                bookingRepo.findByRoomIdAndFromDateLessThanEqualAndToDateGreaterThanEqual(
                        room.getRoomId(),
                        req.getToDate(),
                        req.getFromDate()
                );

        if (!conflicts.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Room is not available for selected dates");
        }

        long days = ChronoUnit.DAYS.between(req.getFromDate(), req.getToDate()) + 1;
        double totalCost = days * room.getPricePerDay();

        BookingConfirmationResponse resp = new BookingConfirmationResponse();
        resp.setRoomId(room.getRoomId());
        resp.setRoomType(room.getRoomType());
        resp.setPricePerDay(room.getPricePerDay());
        resp.setFromDate(req.getFromDate());
        resp.setToDate(req.getToDate());
        resp.setTotalDays(days);
        resp.setTotalCost(totalCost);
        resp.setTenantName(user.getTenantName());
        resp.setEmail(user.getEmail());
        resp.setMobileNumber(user.getMobileNumber());

        return resp;
    }

    public BookingResponse confirmBooking(BookingCreateRequest req) {

        Room room = roomRepo.findById(req.getRoomId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Room not found"));

        PgCustomer user = pgRepo.findById(req.getUserId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User not found"));

        Booking booking = new Booking();
        booking.setRoomId(room.getRoomId());
        booking.setUserId(user.getUserId());
        booking.setFromDate(LocalDate.now());
        booking.setToDate(LocalDate.now().plusDays(1));
        booking.setPaymentMethod(req.getPaymentMethod());
        booking.setStatus("CONFIRMED");
        booking.setTotalCost(room.getPricePerDay());
        booking.setCreatedAt(LocalDateTime.now());

        bookingRepo.save(booking);

        BookingResponse resp = new BookingResponse();
        resp.setBookingId(booking.getBookingId());
        resp.setMessage("Booking confirmed successfully");
        resp.setTotalCost(booking.getTotalCost());
        resp.setStatus(booking.getStatus());

        return resp;
    }
}
