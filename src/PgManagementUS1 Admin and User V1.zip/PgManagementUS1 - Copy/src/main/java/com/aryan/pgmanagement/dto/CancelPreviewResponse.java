package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;
import java.util.UUID;

@Data
@AllArgsConstructor
public class CancelPreviewResponse {

    private UUID bookingId;
    private String roomType;
    private LocalDate fromDate;
    private LocalDate toDate;
    private double totalAmount;

    private long noticePeriodDaysRemaining;
    private String message;
}
