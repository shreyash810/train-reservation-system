package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.*;
import com.aryan.pgmanagement.model.PgCustomer;
import com.aryan.pgmanagement.repo.PgRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.UUID;

@Service
public class AdminUserService {

    @Autowired
    private PgRepo pgRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // CREATE USER
    public CreateUserResponse createUser(CreateUserRequest req) {

        if (pgRepo.existsByUsername(req.getUsername())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Username already exists");
        }

        String tempPassword = UUID.randomUUID().toString().substring(0, 8);
        String encodedPassword = passwordEncoder.encode(tempPassword);

        PgCustomer user = new PgCustomer();

        user.setTenantName("SYSTEM_USER");
        user.setUsername(req.getUsername());
        user.setEmail(req.getEmail());
        user.setCountryCode(req.getCountryCode());
        user.setMobileNumber(String.valueOf('9' + Math.floor(100000000 + Math.random() * 900000000)));
        user.setAddress(req.getAddress());
        user.setPassword(encodedPassword);

        user.setRole(req.getRole());          // ✅ REQUIRED
        user.setActive(true);                 // ✅ REQUIRED
        user.setLoginTries(0);                // ✅ REQUIRED
        user.setAccountBlocked(false);        // ✅ REQUIRED
        user.setForcePasswordChange(true);    // ✅ REQUIRED
        // IMPORTANT for US18

        pgRepo.save(user);


        user.setRole(req.getRole());
        user.setForcePasswordChange(true);

        pgRepo.save(user);

        return new CreateUserResponse(
                user.getUserId(),
                user.getUsername(),
                user.getRole(),
                tempPassword,
                "User created successfully. Ask user to change password on first login."
        );
    }

    // VIEW USERS
    public List<UserListDTO> getAllUsers() {
        return pgRepo.findAll()
                .stream()
                .map(u -> new UserListDTO(
                        u.getUserId(),
                        u.getUsername(),
                        u.getEmail(),
                        u.getRole(),
                        u.getActive() ? "Inactive" : "Active"
                ))
                .toList();
    }

    // UPDATE USER
    public void updateUser(UpdateUserRequest req) {

        PgCustomer user = pgRepo.findById(req.getUserId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User not found"));

        if (req.getUsername() != null && !req.getUsername().isBlank())
            user.setUsername(req.getUsername());

        if (req.getEmail() != null && !req.getEmail().isBlank())
            user.setEmail(req.getEmail());

        if (req.getRole() != null && !req.getRole().isBlank())
            user.setRole(req.getRole());

        pgRepo.save(user);
    }



    // RESET PASSWORD
    public String resetPassword(ResetPasswordRequest req) {

        PgCustomer user = pgRepo.findById(req.getUserId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        String newPassword = UUID.randomUUID().toString().substring(0, 8);
        user.setPassword(passwordEncoder.encode(newPassword));
        user.setForcePasswordChange(true);

        pgRepo.save(user);

        return newPassword;
    }

    public boolean changeUserStatus(AdminUserStatusRequest req) {

        PgCustomer user = pgRepo.findById(req.getUserId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User not found"));

        user.setActive(!user.getActive());   // ✅ TOGGLE
        pgRepo.save(user);

        return user.getActive();
    }
}
