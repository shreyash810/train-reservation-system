package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.BookingHistoryItemDTO;
import com.aryan.pgmanagement.dto.BookingHistoryResponse;
import com.aryan.pgmanagement.model.Booking;
import com.aryan.pgmanagement.model.Payment;
import com.aryan.pgmanagement.model.Room;
import com.aryan.pgmanagement.repo.BookingRepo;
import com.aryan.pgmanagement.repo.PaymentRepo;
import com.aryan.pgmanagement.repo.RoomRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class BookingHistoryService {

    @Autowired
    private BookingRepo bookingRepo;
    @Autowired private RoomRepo roomRepo;
    @Autowired private PaymentRepo paymentRepo;

    public BookingHistoryResponse getBookingHistory(UUID userId) {

        List<Booking> bookings = bookingRepo.findByUserId(userId);

        if (bookings.isEmpty()) {
            return new BookingHistoryResponse(List.of(), List.of());
        }

        LocalDate today = LocalDate.now();

        List<BookingHistoryItemDTO> upcoming = new ArrayList<>();
        List<BookingHistoryItemDTO> past = new ArrayList<>();

        for (Booking booking : bookings) {

            Room room = roomRepo.findById(booking.getRoomId())
                    .orElseThrow();

            Optional<Payment> paymentOpt =
                    paymentRepo.findByBookingId(booking.getBookingId());

            boolean paid = paymentOpt.isPresent()
                    && "SUCCESS".equals(paymentOpt.get().getStatus());

            BookingHistoryItemDTO dto = new BookingHistoryItemDTO(
                    booking.getBookingId(),
                    room.getRoomType(),
                    room.getAddress(),   // room location
                    booking.getFromDate(),
                    booking.getToDate(),
                    booking.getStatus(),
                    booking.getTotalCost(),
                    paid ? "PAID" : "PENDING",
                    paid
            );

            if (!booking.getToDate().isBefore(today)) {
                upcoming.add(dto);
            } else {
                past.add(dto);
            }
        }

        return new BookingHistoryResponse(upcoming, past);
    }
}
