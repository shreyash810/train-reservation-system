package com.aryan.pgmanagement.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TenantRegistrationRequest {

    @NotBlank
    @Size(min = 3)
    @Pattern(regexp = "^[a-zA-Z ]+$")
    private String tenantName;

    @NotBlank
    @Email
    private String mail;

    @NotBlank(message = "Enter country code")
    @Pattern(regexp = "^\\+[0-9]{1,4}$", message = "Invalid country code")
    private String countryCode;

    @NotBlank
    @Pattern(regexp = "^[0-9]{8,10}$")
    private String mobileNumber;

    @NotBlank
    @Size(min = 10)
    private String address;

    @NotBlank
    @Size(min = 5)
    @Pattern(regexp = "^[^\\s]+$")
    private String username;

    @NotBlank
    @Pattern(
            regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^\\w\\s]).{8,}$"
    )
    private String password;

    @NotBlank
    private String confirmPassword;

    @AssertTrue(message = "Password do not match")
    public boolean isPasswordMatch() {
        return password != null && password.equals(confirmPassword);
    }
}
