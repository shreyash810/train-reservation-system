package com.aryan.pgmanagement.controller;

import com.aryan.pgmanagement.dto.CancelConfirmRequest;
import com.aryan.pgmanagement.dto.CancelInitiateRequest;
import com.aryan.pgmanagement.dto.CancelPreviewResponse;
import com.aryan.pgmanagement.dto.CancelResponse;
import com.aryan.pgmanagement.service.CancelBookingService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/booking/cancel")
@CrossOrigin(origins = "http://localhost:4200")
public class CancelBookingController {

    @Autowired
    private CancelBookingService cancelService;

    @PostMapping("/initiate")
    public ResponseEntity<CancelPreviewResponse> initiateCancel(
            @Valid @RequestBody CancelInitiateRequest req) {

        return ResponseEntity.ok(
                cancelService.initiateCancel(req)
        );
    }

    @PostMapping("/confirm")
    public ResponseEntity<CancelResponse> confirmCancel(
            @Valid @RequestBody CancelConfirmRequest req) {

        return ResponseEntity.ok(
                cancelService.confirmCancel(req)
        );
    }
}
