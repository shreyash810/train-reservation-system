package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.InvoiceResponse;
import com.aryan.pgmanagement.model.*;
import com.aryan.pgmanagement.repo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class InvoiceService {

    @Autowired
    private InvoiceRepo invoiceRepo;

    @Autowired
    private BookingRepo bookingRepo;

    @Autowired
    private PaymentRepo paymentRepo;

    public InvoiceResponse generateInvoice(UUID bookingId) {

        Booking booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Booking not found"));

        if (!"CONFIRMED".equals(booking.getStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Invoice can only be generated for completed bookings");
        }

        Payment payment = paymentRepo.findByBookingId(bookingId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Payment not completed"));

        if (invoiceRepo.findByBookingId(bookingId).isPresent()) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Invoice already generated");
        }

        double basePrice = payment.getAmount();
        double gst = basePrice * 0.18;
        double serviceCharge = basePrice * 0.05;
        double total = basePrice + gst + serviceCharge;

        Invoice invoice = new Invoice(
                null,
                bookingId,
                payment.getTransactionId(),
                payment.getPaymentMethod(),
                basePrice,
                gst,
                serviceCharge,
                total,
                LocalDateTime.now()
        );

        invoiceRepo.save(invoice);

        return new InvoiceResponse(
                invoice.getInvoiceId(),
                bookingId,
                invoice.getTransactionId(),
                invoice.getTotalAmount(),
                invoice.getGeneratedAt()
        );
    }
}
