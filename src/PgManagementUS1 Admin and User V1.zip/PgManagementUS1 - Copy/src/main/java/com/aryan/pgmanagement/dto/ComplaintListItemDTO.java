package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;
import java.util.UUID;

@Data
@AllArgsConstructor
public class ComplaintListItemDTO {

    private UUID complaintId;
    private String category;
    private String title;
    private LocalDate submissionDate;
    private String status;
    private LocalDate expectedResolutionDate;
}
