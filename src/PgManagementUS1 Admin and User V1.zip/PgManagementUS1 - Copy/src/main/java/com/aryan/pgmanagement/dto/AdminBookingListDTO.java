package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;
import java.util.UUID;

@Data
@AllArgsConstructor
public class AdminBookingListDTO {
    private UUID bookingId;
    private UUID roomId;           // ✅ ADD THIS
    private String tenantName;
    private String roomNumber;
    private LocalDate fromDate;
    private LocalDate toDate;
    private String status;
    private double totalAmount;
}

