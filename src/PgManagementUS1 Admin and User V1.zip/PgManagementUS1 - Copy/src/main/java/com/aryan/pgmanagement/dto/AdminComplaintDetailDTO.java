package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@AllArgsConstructor
public class AdminComplaintDetailDTO {

    private UUID complaintId;
    private UUID bookingId;

    private String tenantName;
    private String category;
    private String title;
    private String description;

    private String status;
    private String priority;

    private String supportResponse;   // tenant communication
    private String resolutionNotes;   // internal notes

    private LocalDateTime submittedAt;
    private LocalDate expectedResolutionDate;
}
