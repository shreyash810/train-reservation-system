package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AdminDashboardDTO {

    private long totalUsers;
    private long totalRooms;
    private long totalBookings;
    private long totalPayments;
}
