package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@AllArgsConstructor
public class AdminPaymentDTO {

    private UUID paymentId;
    private String billId;        // transactionId
    private String tenantName;    // RESOLVED NAME
    private double amount;
    private String status;
    private String paymentMethod;
    private LocalDateTime createdAt;
}
