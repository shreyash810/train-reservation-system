package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;
import java.util.UUID;

@Data
@AllArgsConstructor
public class AdminComplaintDashboardDTO {

    private UUID complaintId;
    private String tenantName;
    private LocalDate submittedDate;
    private String category;
    private String status;
    private String priority; // LOW / MEDIUM / HIGH
}
