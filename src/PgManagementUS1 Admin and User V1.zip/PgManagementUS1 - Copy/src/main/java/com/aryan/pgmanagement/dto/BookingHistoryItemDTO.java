package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;
import java.util.UUID;

@Data
@AllArgsConstructor
public class BookingHistoryItemDTO {

    private UUID bookingId;

    private String roomType;
    private String roomAddress;

    private LocalDate fromDate;
    private LocalDate toDate;

    private String bookingStatus;   // CONFIRMED, CHECKED_IN, CHECKED_OUT, CANCELED
    private double totalAmount;

    private String paymentStatus;   // PAID, PENDING

    private boolean invoiceAvailable;
}
