package com.aryan.pgmanagement.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingInitiateRequest {

    @NotNull
    private UUID roomId;

    @NotNull
    private UUID userId;

    @NotNull
    private LocalDate fromDate;

    @NotNull
    private LocalDate toDate;
}
