package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.*;
import com.aryan.pgmanagement.model.Complaint;
import com.aryan.pgmanagement.repo.BookingRepo;
import com.aryan.pgmanagement.repo.ComplaintRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class ComplaintService {

    @Autowired
    private ComplaintRepo complaintRepo;

    @Autowired
    private BookingRepo bookingRepo;

    public ComplaintResponse registerComplaint(ComplaintRequest req) {

        if (!bookingRepo.existsById(req.getBookingId())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Invalid booking ID"
            );
        }

        if (req.getTitle().length() < 10 || req.getDescription().length() < 20) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Please provide more details to help us resolve your issue."
            );
        }

        Complaint complaint = new Complaint();
        complaint.setBookingId(req.getBookingId());
        complaint.setUserId(req.getUserId());
        complaint.setCategory(req.getCategory());
        complaint.setTitle(req.getTitle());
        complaint.setDescription(req.getDescription());
        complaint.setContactPreference(req.getContactPreference());
        complaint.setStatus("OPEN");
        complaint.setCreatedAt(LocalDateTime.now());

// ✅ ADD THIS LINE
        complaint.setExpectedResolutionDate(
                LocalDate.now().plusDays(5) // example SLA
        );

        complaintRepo.save(complaint);


        // (Mock) SMS/Email acknowledgment can be integrated here

        return new ComplaintResponse(
                complaint.getComplaintId(),
                "Your complaint has been successfully submitted. Our support team will get back to you soon.",
                complaint.getStatus()
        );
    }

    public List<ComplaintViewResponse> viewComplaints(UUID userId) {

        return complaintRepo.findByUserId(userId)
                .stream()
                .map(c -> new ComplaintViewResponse(
                        c.getComplaintId(),
                        c.getBookingId(),
                        c.getCategory(),
                        c.getTitle(),
                        c.getStatus(),
                        c.getCreatedAt()
                ))
                .toList();
    }

    public List<ComplaintListItemDTO> getComplaintList(UUID userId) {

        List<Complaint> complaints = complaintRepo.findByUserId(userId);

        if (complaints.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "You have not registered any complaints."
            );
        }

        return complaints.stream()
                .map(c -> new ComplaintListItemDTO(
                        c.getComplaintId(),
                        c.getCategory(),
                        c.getTitle(),
                        c.getCreatedAt().toLocalDate(),
                        c.getStatus(),
                        c.getExpectedResolutionDate()
                ))
                .toList();
    }

    public ComplaintDetailResponse getComplaintDetail(
            UUID complaintId, UUID userId) {

        Complaint complaint = complaintRepo
                .findByComplaintIdAndUserId(complaintId, userId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "The complaint you are looking for does not exist or has been deleted."
                ));

        return new ComplaintDetailResponse(
                complaint.getComplaintId(),
                complaint.getBookingId(),
                complaint.getCategory(),
                complaint.getTitle(),
                complaint.getDescription(),
                complaint.getStatus(),
                complaint.getSupportResponse(),
                complaint.getResolutionNotes(),
                complaint.getCreatedAt()
        );
    }

    public void confirmResolution(UUID complaintId, UUID userId) {

        Complaint complaint = complaintRepo
                .findByComplaintIdAndUserId(complaintId, userId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Complaint not found"
                ));

        if (!"RESOLVED".equals(complaint.getStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Only resolved complaints can be closed"
            );
        }

        complaint.setStatus("CLOSED");
        complaintRepo.save(complaint);
    }

    public void reopenComplaint(UUID complaintId, UUID userId) {

        Complaint complaint = complaintRepo
                .findByComplaintIdAndUserId(complaintId, userId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Complaint not found"
                ));

        if ("CLOSED".equals(complaint.getStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Closed complaints cannot be reopened"
            );
        }

        complaint.setStatus("OPEN");
        complaintRepo.save(complaint);
    }

}
