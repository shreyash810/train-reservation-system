package com.aryan.pgmanagement.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.UUID;

@Data
public class UserStatusRequest {

    @NotNull
    private UUID userId;

    @NotNull
    private Boolean active; // false = deactivate, true = reactivate
}
