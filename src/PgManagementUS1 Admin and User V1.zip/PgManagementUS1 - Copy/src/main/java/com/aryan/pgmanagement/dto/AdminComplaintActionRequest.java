package com.aryan.pgmanagement.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.UUID;

@Data
public class AdminComplaintActionRequest {

    @NotNull
    private UUID complaintId;

    @NotBlank
    private String status;
    // IN_PROGRESS / RESOLVED / ESCALATED / CLOSED

    private String supportResponse;
    private String resolutionNotes;
}
