package com.aryan.pgmanagement.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "payments")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID paymentId;

    @Column(nullable = false)
    private UUID bookingId;

    @Column(nullable = false)
    private double amount;

    @Column(nullable = false)
    private String paymentMethod;
    // CARD, UPI, NET_BANKING, WALLET

    @Column(nullable = false)
    private String transactionId;

    @Column(nullable = false)
    private String status;
    // SUCCESS, FAILED

    @Column(nullable = false)
    private LocalDateTime createdAt;
}
