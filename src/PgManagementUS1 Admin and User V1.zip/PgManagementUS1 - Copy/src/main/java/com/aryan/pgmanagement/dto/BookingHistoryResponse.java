package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class BookingHistoryResponse {

    private List<BookingHistoryItemDTO> upcomingBookings;
    private List<BookingHistoryItemDTO> pastBookings;
}
