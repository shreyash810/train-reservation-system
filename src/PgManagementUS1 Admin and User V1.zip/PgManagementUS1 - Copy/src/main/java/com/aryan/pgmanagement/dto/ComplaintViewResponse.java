package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@AllArgsConstructor
public class ComplaintViewResponse {

    private UUID complaintId;
    private UUID bookingId;
    private String category;
    private String title;
    private String status;
    private LocalDateTime createdAt;
}
