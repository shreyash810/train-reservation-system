package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.UUID;

@Data
@AllArgsConstructor
public class ComplaintResponse {

    private UUID complaintId;
    private String message;
    private String status;
}
