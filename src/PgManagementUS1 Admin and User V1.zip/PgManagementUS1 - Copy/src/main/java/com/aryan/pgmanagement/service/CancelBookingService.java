package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.CancelConfirmRequest;
import com.aryan.pgmanagement.dto.CancelInitiateRequest;
import com.aryan.pgmanagement.dto.CancelPreviewResponse;
import com.aryan.pgmanagement.dto.CancelResponse;
import com.aryan.pgmanagement.model.Booking;
import com.aryan.pgmanagement.model.Room;
import com.aryan.pgmanagement.repo.BookingRepo;
import com.aryan.pgmanagement.repo.RoomRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

@Service
public class CancelBookingService {

    @Autowired
    private BookingRepo bookingRepo;

    @Autowired
    private RoomRepo roomRepo;

    public CancelPreviewResponse initiateCancel(CancelInitiateRequest req) {

        Booking booking = bookingRepo
                .findByBookingIdAndUserId(req.getBookingId(), req.getUserId())
                .stream()
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Booking not found for user"
                ));

        if (!"CONFIRMED".equals(booking.getStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Only confirmed bookings can be cancelled"
            );
        }

        LocalDate today = LocalDate.now();

        if (today.isAfter(booking.getFromDate())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Cancellation not allowed after booking start date"
            );
        }

        long noticeDays =
                ChronoUnit.DAYS.between(today, booking.getFromDate());

        Room room = roomRepo.findById(booking.getRoomId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Room not found"
                ));

        return new CancelPreviewResponse(
                booking.getBookingId(),
                room.getRoomType(),
                booking.getFromDate(),
                booking.getToDate(),
                booking.getTotalCost(),
                noticeDays,
                "Do you wish to cancel this booking?"
        );
    }

    public CancelResponse confirmCancel(CancelConfirmRequest req) {

        if (!Boolean.TRUE.equals(req.getConfirm())) {
            return new CancelResponse(
                    req.getBookingId(),
                    "CONFIRMED",
                    "Cancellation aborted by user"
            );
        }

        Booking booking = bookingRepo
                .findByBookingIdAndUserId(req.getBookingId(), req.getUserId())
                .stream()
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Booking not found"
                ));

        if (!"CONFIRMED".equals(booking.getStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Booking cannot be cancelled"
            );
        }

        booking.setStatus("CANCELLED");
        bookingRepo.save(booking);

        return new CancelResponse(
                booking.getBookingId(),
                "CANCELLED",
                "Booking cancelled successfully"
        );
    }
}
