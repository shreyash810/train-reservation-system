package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.AdminComplaintActionRequest;
import com.aryan.pgmanagement.dto.AdminComplaintDashboardDTO;
import com.aryan.pgmanagement.dto.AdminComplaintDetailDTO;
import com.aryan.pgmanagement.model.Complaint;
import com.aryan.pgmanagement.model.PgCustomer;
import com.aryan.pgmanagement.repo.ComplaintRepo;
import com.aryan.pgmanagement.repo.PgRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
public class AdminComplaintService {

    @Autowired
    private ComplaintRepo complaintRepo;

    @Autowired
    private PgRepo pgRepo;

    // 1️⃣ DASHBOARD
    public List<AdminComplaintDashboardDTO> getDashboardComplaints() {

        return complaintRepo.findAll()
                .stream()
                .map(c -> {
                    String tenantName = pgRepo.findById(c.getUserId())
                            .map(PgCustomer::getTenantName)
                            .orElse("Unknown");

                    return new AdminComplaintDashboardDTO(
                            c.getComplaintId(),
                            tenantName,
                            c.getCreatedAt().toLocalDate(),
                            c.getCategory(),
                            c.getStatus(),
                            calculatePriority(c)
                    );
                })
                .toList();
    }

    // 2️⃣ DETAILED VIEW
    public AdminComplaintDetailDTO getComplaintDetail(UUID complaintId) {

        Complaint c = complaintRepo.findById(complaintId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Complaint not found"
                ));

        String tenantName = pgRepo.findById(c.getUserId())
                .map(PgCustomer::getTenantName)
                .orElse("Unknown");

        return new AdminComplaintDetailDTO(
                c.getComplaintId(),
                c.getBookingId(),
                tenantName,
                c.getCategory(),
                c.getTitle(),
                c.getDescription(),
                c.getStatus(),
                calculatePriority(c),
                c.getSupportResponse(),
                c.getResolutionNotes(),
                c.getCreatedAt(),
                c.getExpectedResolutionDate()
        );
    }

    // 3️⃣ ACTION LOGGING + STATUS UPDATE
    public void updateComplaint(AdminComplaintActionRequest req) {

        Complaint c = complaintRepo.findById(req.getComplaintId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Complaint not found"
                ));

        if (req.getSupportResponse() != null) {
            c.setSupportResponse(req.getSupportResponse());
        }

        if (req.getResolutionNotes() != null) {
            c.setResolutionNotes(req.getResolutionNotes());
        }

        c.setStatus(req.getStatus());
        complaintRepo.save(c);
    }

    // 🔧 PRIORITY CALCULATION
    private String calculatePriority(Complaint c) {
        if ("ESCALATED".equals(c.getStatus())) return "HIGH";
        if (c.getExpectedResolutionDate().isBefore(LocalDate.now())) return "HIGH";
        if ("IN_PROGRESS".equals(c.getStatus())) return "MEDIUM";
        return "LOW";
    }
}
