package com.aryan.pgmanagement.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class ResetPasswordRequest {
    private UUID userId;
}
