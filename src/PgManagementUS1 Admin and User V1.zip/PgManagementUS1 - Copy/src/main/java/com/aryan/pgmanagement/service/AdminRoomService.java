package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.RoomUpdateRequest;
import com.aryan.pgmanagement.model.Room;
import com.aryan.pgmanagement.repo.BookingRepo;
import com.aryan.pgmanagement.repo.RoomRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.UUID;

@Service
public class AdminRoomService {

    @Autowired
    private RoomRepo roomRepo;

    @Autowired
    private BookingRepo bookingRepo;

    public List<Room> getAllRooms() {
        return roomRepo.findAll();
    }

    public Room updateRoom(UUID roomId, RoomUpdateRequest req) {

        Room room = roomRepo.findById(roomId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Room not found"));

        // Occupied rooms cannot be updated
        if (!room.isAvailability()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Occupied rooms cannot be updated");
        }

        // Block update if active/upcoming bookings exist
        boolean hasBookings =
                bookingRepo.existsByRoomIdAndStatusIn(
                        room.getRoomId(),
                        List.of("CONFIRMED", "CHECKED_IN")
                );

        if (hasBookings) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Room has active or upcoming bookings");
        }

        room.setRoomType(req.getRoomType());
        room.setPricePerDay(req.getPricePerDay());
        room.setAvailability(req.getAvailability());
        room.setAmenities(req.getAmenities());

        return roomRepo.save(room);
    }

}
