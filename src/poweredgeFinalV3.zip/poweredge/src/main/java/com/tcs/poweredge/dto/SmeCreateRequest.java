package com.tcs.poweredge.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SmeCreateRequest {

    @NotBlank
    @Size(max = 100)
    private String fname;

    @NotBlank
    @Size(max = 100)
    private String lname;

    @NotBlank
    @Size(max = 15)
    private String mobileNumber;

    @Email
    private String userEmail;

    @NotBlank
    private String password;

    @NotBlank
    private String username;
}

