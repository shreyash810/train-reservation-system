package com.tcs.poweredge.dto;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;


@Data
public class ChangeDescriptionRequest {
    @NotBlank
    private String description;
}
