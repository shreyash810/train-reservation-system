package com.tcs.poweredge.service;


import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;

import java.io.ByteArrayOutputStream;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.TemplateEngine;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import com.tcs.poweredge.dto.BillDTO;
import com.tcs.poweredge.dto.BillListForCustomer;
import com.tcs.poweredge.dto.BillListRequest;
import com.tcs.poweredge.dto.CreateBillRequest;
import com.tcs.poweredge.mapper.BillMapper;
import com.tcs.poweredge.model.Bill;
import com.tcs.poweredge.model.Customer;
import com.tcs.poweredge.model.User;
import com.tcs.poweredge.model.enums.PaymentStatus;
import com.tcs.poweredge.repository.BillRepository;
import com.tcs.poweredge.repository.CustomerRepository;
import com.tcs.poweredge.repository.UserRepository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

@Service
@RequiredArgsConstructor
public class BillService {

    private final BillRepository billRepository;
    private final CustomerRepository customerRepository;
    private final UserRepository userRepository;
    private final TemplateEngine templateEngine;
    

    public Page<BillDTO> listBillsForAdmin(BillListRequest req, Pageable pageable) {
        Page<Bill> page = billRepository.findForAdminWithOptionalFilters(
                req.getBillId(),
                req.getCustomerId(),
                req.getBillingPeriod(),
                req.getPaymentStatus(),
                req.getConnectionType(),
                req.getConnectionStatus(),
                pageable
        );
        return page.map(BillMapper::toDTO);
    }

    public Page<BillDTO> listBillsForCustomer(BillListForCustomer req,Long userId, Pageable pageable) throws Exception {
        User user = userRepository.findById(userId).orElseThrow(()->new Exception("unknown exception"));
        Long customerId = user.getCustomer().getCustomerId();
        Page<Bill> page = billRepository.findForAdminWithOptionalFilters(
                req.getBillId(),
                customerId,
                req.getBillingPeriod(),
                req.getPaymentStatus(),
                req.getConnectionType(),
                req.getConnectionStatus(),
                pageable
        );
        return page.map(BillMapper::toDTO);
    }

    @Transactional
    public BillDTO createBillForCustomer(Long customerId, CreateBillRequest req) throws Exception {
        // 1) Ensure customer exists
        Customer customer = customerRepository.findById(customerId).orElseThrow();
           
        // 2) Prevent duplicate bill for the same period
        boolean exists = billRepository.existsByCustomer_CustomerIdAndBillingPeriod(customerId, req.getBillingPeriod());
        if (exists) {
            throw new Exception(
                "Bill already exists for customerId=" + customerId + " and period=" + req.getBillingPeriod()
            );
        }

        // 3) Compute dueAmount = billAmount + lateFee
        BigDecimal dueAmount = req.getBillAmount().add(req.getLateFee() == null ? BigDecimal.ZERO : req.getLateFee());

        // 4) Build entity
        Bill bill = Bill.builder()
                .customer(customer)
                .connectionType(req.getConnectionType())
                .connectionStatus(req.getConnectionStatus())
                .billingPeriod(req.getBillingPeriod())
                .billDate(req.getBillDate())
                .dueDate(req.getDueDate())
                .billAmount(req.getBillAmount())
                .lateFee(req.getLateFee() == null ? BigDecimal.ZERO : req.getLateFee())
                .dueAmount(dueAmount)
                .paymentStatus(PaymentStatus.UNPAID)
                .paymentDate(null)
                .build();

        // 5) Save & map
        Bill saved = billRepository.save(bill);
        return BillMapper.toDTO(saved);
    }


public byte[] generateInvoicePdf(Long billId) {
        Bill bill = billRepository.findById(billId)
                .orElseThrow(() -> new IllegalArgumentException("Bill not found: " + billId));

        // Build Thymeleaf context
        Context ctx = new Context();
        ctx.setVariable("bill", bill);

        // Render HTML from template "invoice.html"
        String html = templateEngine.process("invoice", ctx);

        // Convert to PDF
        return htmlToPdf(html);
    }

    /**
     * HTML -> PDF using OpenHTMLToPDF (PDFBox).
     */
    private byte[] htmlToPdf(String html) {
        try (ByteArrayOutputStream os = new ByteArrayOutputStream()) {
            PdfRendererBuilder builder = new PdfRendererBuilder();
            builder.useFastMode();
            builder.withHtmlContent(html, null); // baseURI null since we don't reference external assets
            builder.toStream(os);
            builder.run();
            return os.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate invoice PDF", e);
        }
    }
}
