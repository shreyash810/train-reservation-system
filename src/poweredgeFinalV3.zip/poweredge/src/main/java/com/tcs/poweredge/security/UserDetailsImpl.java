
package com.tcs.poweredge.security;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.tcs.poweredge.model.User;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;
import java.util.Objects;

/**
 * Bridges your domain User model to Spring Security's UserDetails.
 */
public class UserDetailsImpl implements UserDetails {

    private final Long id;
    private final String username;
    private final String email;


    @JsonIgnore
    private final String password;

    private final List<GrantedAuthority> authorities;

    public UserDetailsImpl(
            Long id,
            String username,
            String email,
            String password,
            List<GrantedAuthority> authorities
    ) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.password = password;
        this.authorities = authorities;
    }

    /**
     * Factory method to build UserDetailsImpl from your domain model.
     */
    public static UserDetailsImpl fromDomainUser(User user) {
        // Defensive: handle null role; you can customize a default role if needed
        SimpleGrantedAuthority authority = new SimpleGrantedAuthority(
                user.getRole() != null ? "ROLE_"+user.getRole().name() : "ROLE_USER"
        );
        List<GrantedAuthority> auths = List.of(authority);

        return new UserDetailsImpl(
                user.getId(),
                user.getUsername(),
                user.getEmail(),
                user.getPassword(),
                auths
        );
    }

    public Long getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    @JsonIgnore
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        // Spring uses this as the principal username during auth
        return username;
    }

    // ---- Required by UserDetails, use domain fields if available ----

    @Override
    public boolean isAccountNonExpired() {
        // Map to user flag if present: e.g., return !user.isAccountExpired();
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        // Map to user flag if present: e.g., return !user.isLocked();
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        // Map to user flag if present
        return true;
    }

    @Override
    public boolean isEnabled() {
        // Map to user flag if present: e.g., return user.isEnabled();
        return true;
    }

    // Good practice for Authentication comparison
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UserDetailsImpl)) return false;
        UserDetailsImpl that = (UserDetailsImpl) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    // Optional: avoid leaking password in logs
    @Override
    public String toString() {
        return "UserDetailsImpl{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", authorities=" + authorities +
                '}';
    }
}