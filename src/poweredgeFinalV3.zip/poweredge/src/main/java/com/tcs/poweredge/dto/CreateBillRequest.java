package com.tcs.poweredge.dto;



import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.tcs.poweredge.model.enums.ConnectionStatus;
import com.tcs.poweredge.model.enums.ConnectionType;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreateBillRequest {

    @NotBlank
    @Size(min = 7, max = 7)
    @Pattern(regexp = "^[0-9]{4}-[0-9]{2}$", message = "billingPeriod must be in 'YYYY-MM' format")
    private String billingPeriod; // "YYYY-MM"

    @NotNull
    private LocalDate billDate;

    @NotNull
    private LocalDate dueDate;

    @NotNull
    @Digits(integer = 8, fraction = 2)
    @Positive
    private BigDecimal billAmount;

    @Digits(integer = 8, fraction = 2)
    @PositiveOrZero
    @Builder.Default
    private BigDecimal lateFee = BigDecimal.ZERO;

    @NotNull
    private ConnectionType connectionType;

    @NotNull
    private ConnectionStatus connectionStatus;
}
