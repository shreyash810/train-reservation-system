package com.tcs.poweredge.model.enums;

public enum CustomerTypeEnum {
    RESIDENTIAL,
    COMMERCIAL
}
