package com.tcs.poweredge.dto;


import com.tcs.poweredge.model.enums.ComplaintType;
import com.tcs.poweredge.model.enums.PreferredContactMethod;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class CreateComplaintRequest {

    @NotNull
    private ComplaintType complaintType;

    @NotBlank
    @Size(min = 10, max = 5000)
    private String description;

    @Email
    @Size(max = 255)
    private String contactEmail; // optional override

    @Size(max = 15)
    private String contactPhone; // optional override

    private Long assignedToUserId; // optional

    private PreferredContactMethod preferredContactMethod; // optional

    public CreateComplaintRequest() {}

    // public CreateComplaintRequest(ComplaintType complaintType, String description, String contactEmail,
    //                               String contactPhone, Long assignedToUserId,
    //                               PreferredContactMethod preferredContactMethod) {
    //     this.complaintType = complaintType;
    //     this.description = description;
    //     this.contactEmail = contactEmail;
    //     this.contactPhone = contactPhone;
    //     this.assignedToUserId = assignedToUserId;
    //     this.preferredContactMethod = preferredContactMethod;
    // }

    // public ComplaintType getComplaintType() { return complaintType; }
    // public void setComplaintType(ComplaintType complaintType) { this.complaintType = complaintType; }

    // public String getDescription() { return description; }
    // public void setDescription(String description) { this.description = description; }

    // public String getContactEmail() { return contactEmail; }
    // public void setContactEmail(String contactEmail) { this.contactEmail = contactEmail; }

    // public String getContactPhone() { return contactPhone; }
    // public void setContactPhone(String contactPhone) { this.contactPhone = contactPhone; }

    // public Long getAssignedToUserId() { return assignedToUserId; }
    // public void setAssignedToUserId(Long assignedToUserId) { this.assignedToUserId = assignedToUserId; }

    // public PreferredContactMethod getPreferredContactMethod() { return preferredContactMethod; }
    // public void setPreferredContactMethod(PreferredContactMethod preferredContactMethod) {
    //     this.preferredContactMethod = preferredContactMethod;
    // }
}

