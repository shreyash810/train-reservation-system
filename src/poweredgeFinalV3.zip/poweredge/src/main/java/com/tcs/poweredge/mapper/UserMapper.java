package com.tcs.poweredge.mapper;

import org.springframework.stereotype.Component;

import com.tcs.poweredge.dto.RegisterRequest;
import com.tcs.poweredge.dto.UserResponse;
import com.tcs.poweredge.model.Customer;
import com.tcs.poweredge.model.User; 

@Component
public class UserMapper {
    
    public User toEntity(RegisterRequest request){
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(request.getPassword());
        user.setEmail(request.getEmail());
        return user;
    }

    public UserResponse toDto(User user, Customer customer){
        UserResponse response = UserResponse.builder()
                                        .userId(user.getId())
                                        .customerID(customer.getCustomerId())
                                        .username(user.getUsername())
                                        .email(user.getEmail())
                                        .fname(customer.getFname())
                                        .lname(customer.getLname())
                                        .address(customer.getAddress())
                                        .consumerNumber(customer.getCousumerNumber())
                                        .mobileNumber(customer.getMobileNumber())
                                        .electricalSection(customer.getElectricalSection())
                                        .customerType(customer.getCustomerType())
                                        .createdAt(user.getCreatedAt())
                                        .updatedAt(user.getUpdatedAt())
                                        .refinedCustomerId(customer.getRefinedCustomerId())
                                        .build();
        return response;
    }
}
