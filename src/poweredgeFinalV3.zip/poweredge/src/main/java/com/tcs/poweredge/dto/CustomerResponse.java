package com.tcs.poweredge.dto;

import com.tcs.poweredge.model.enums.CustomerTypeEnum;
import com.tcs.poweredge.model.enums.ElectricalSectionEnum;

public record CustomerResponse(
        Long id,
        String consumerNumber,
        String fname,
        String lname,
        String address,
        String mobileNumber,
        ElectricalSectionEnum electricalSection,
        CustomerTypeEnum customerType,
        String refinedCustomerId,
        String email // from linked User if present
) {}

