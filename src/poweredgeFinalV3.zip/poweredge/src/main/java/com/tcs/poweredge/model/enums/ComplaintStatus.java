package com.tcs.poweredge.model.enums;


public enum ComplaintStatus {
    OPEN, IN_PROGRESS, RESOLVED, CLOSED
}

