
package com.tcs.poweredge.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.poweredge.dto.CustomerListingResponse;
import com.tcs.poweredge.model.Customer;
import com.tcs.poweredge.model.enums.CustomerTypeEnum;
import com.tcs.poweredge.model.enums.ElectricalSectionEnum;
import com.tcs.poweredge.repository.CustomerRepository;

@Service
@Transactional(readOnly = true)
public class CustomerListingService {

    private final CustomerRepository customerRepository;

    public CustomerListingService(final CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    /**
     * Get all customers with pagination and map to DTO.
     */
    public Page<CustomerListingResponse> getCustomers(Pageable pageable) {
        return customerRepository.findAll(pageable)
                .map(this::toCustomerListingResponse);
    }

    /**
     * Get customers filtered by Electrical Section with pagination and map to DTO.
     */
    public Page<CustomerListingResponse> getCustomersByElectricalSection(
            ElectricalSectionEnum electricalSection, Pageable pageable) {
        return customerRepository.findByElectricalSection(electricalSection, pageable)
                .map(this::toCustomerListingResponse);
    }

    /**
     * Get customers filtered by Customer Type with pagination and map to DTO.
     */
    public Page<CustomerListingResponse> getCustomersByCustomerType(
            CustomerTypeEnum customerType, Pageable pageable) {
        return customerRepository.findByCustomerType(customerType, pageable)
                .map(this::toCustomerListingResponse);
    }

    /**
     * Get customers filtered by both Electrical Section and Customer Type with pagination and map to DTO.
     */
    public Page<CustomerListingResponse> getCustomersByElectricalSectionAndCustomerType(
            ElectricalSectionEnum electricalSection,
            CustomerTypeEnum customerType,
            Pageable pageable
    ) {
        return customerRepository.findByElectricalSectionAndCustomerType(electricalSection, customerType, pageable)
                .map(this::toCustomerListingResponse);
    }

    // --- Mapping ---

    private CustomerListingResponse toCustomerListingResponse(Customer customer) {
        return CustomerListingResponse.builder()
                .customerId(customer.getCustomerId())
                .refinedCustomerId(customer.getRefinedCustomerId()) // from @Transient method
                .cousumerNumber(customer.getCousumerNumber())       // preserving your field name
                .fname(customer.getFname())
                .lname(customer.getLname())
                .address(customer.getAddress())
                .mobileNumber(customer.getMobileNumber())
                .electricalSection(customer.getElectricalSection())
                .customerType(customer.getCustomerType())
                .build();
    }
}
