package com.tcs.poweredge.controller;
 
import org.springframework.data.domain.Page;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.data.domain.Pageable;
import com.tcs.poweredge.dto.CustomerListingResponse;
import com.tcs.poweredge.dto.SmeCreateRequest;
import com.tcs.poweredge.dto.SmeResponse;
import com.tcs.poweredge.model.Sme;
import com.tcs.poweredge.model.User;
import com.tcs.poweredge.model.enums.CustomerTypeEnum;
import com.tcs.poweredge.model.enums.ElectricalSectionEnum;
import com.tcs.poweredge.model.enums.UserRoleEnum;
import com.tcs.poweredge.repository.SmeRepository;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.poweredge.repository.UserRepository;
import com.tcs.poweredge.service.CustomerListingService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class SmeController {

    
    private final SmeRepository smeRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final CustomerListingService customerListingService;


    @PostMapping("/admin/addsme")
    @PreAuthorize("hasRole('ADMIN')")
    @Transactional
    public ResponseEntity<SmeResponse> createSmeWithUser(@Valid @RequestBody SmeCreateRequest request) {
        userRepository.findByEmail(request.getUserEmail())
                .ifPresent(u -> { throw new IllegalArgumentException("Email already in use: " + request.getUserEmail()); });

        userRepository.findByUsername(request.getUsername())
                .ifPresent(u -> { throw new IllegalArgumentException("Username already in use: " + request.getUsername()); });

        smeRepository.findByMobileNumber(request.getMobileNumber())
                .ifPresent(s -> { throw new IllegalArgumentException("Mobile number already in use: " + request.getMobileNumber()); });

        // Build SME (non-owning side)
        Sme sme = Sme.builder()
                .fname(request.getFname())
                .lname(request.getLname())
                .mobileNumber(request.getMobileNumber())
                .build();

        // Build User (owning side for @OneToOne with @JoinColumn on User)
        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getUserEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(UserRoleEnum.SME); // choose appropriate default role

        // Link both sides
        Sme savedSme = smeRepository.save(sme);
        user.setSme(savedSme); 

        User savedUser = userRepository.save(user);

        // Build response
        SmeResponse resp = new SmeResponse(
                savedSme.getSmeId(),
                savedSme.getFname(),
                savedSme.getLname(),
                savedSme.getMobileNumber(),
                savedUser.getId(),
                savedUser.getEmail()
        );

        return ResponseEntity.ok(resp);
    }

        @GetMapping("/sme/listcustomers")
        @PreAuthorize("hasRole('SME')")
        public Page<CustomerListingResponse> getCustomersForSme(
            @RequestParam(name = "electricalSection", required = false) ElectricalSectionEnum electricalSection,
            @RequestParam(name = "customerType", required = false) CustomerTypeEnum customerType,
            @PageableDefault(size = 20) Pageable pageable
        ) {
                if (electricalSection != null && customerType != null) {
                return customerListingService.getCustomersByElectricalSectionAndCustomerType(
                        electricalSection, customerType, pageable);
                } else if (electricalSection != null) {
                        return customerListingService.getCustomersByElectricalSection(electricalSection, pageable);
                } else if (customerType != null) {
                        return customerListingService.getCustomersByCustomerType(customerType, pageable);
                } else {
                        return customerListingService.getCustomers(pageable);
                }
        }
}
