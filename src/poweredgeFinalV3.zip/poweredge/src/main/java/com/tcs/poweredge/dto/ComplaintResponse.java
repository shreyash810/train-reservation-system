package com.tcs.poweredge.dto;


// package: com.example.app.complaint.dto

import java.time.LocalDateTime;

import com.tcs.poweredge.model.enums.ComplaintCategory;
import com.tcs.poweredge.model.enums.ComplaintStatus;
import com.tcs.poweredge.model.enums.ComplaintType;
import com.tcs.poweredge.model.enums.PreferredContactMethod;

public class ComplaintResponse {

    private Long complaintId;
    private ComplaintType complaintType;
    private ComplaintCategory category;
    private String description;
    private PreferredContactMethod preferredContactMethod;
    private String contactEmail;
    private String contactPhone;
    private ComplaintStatus status;
    private LocalDateTime dateSubmitted;
    private LocalDateTime lastUpdatedDate;
    private Long customerId;
    private String refinedCustomerId;
    private Long assignedToUserId;

    public ComplaintResponse() {}

    public ComplaintResponse(Long complaintId, ComplaintType complaintType, ComplaintCategory category,
                             String description, PreferredContactMethod preferredContactMethod,
                             String contactEmail, String contactPhone, ComplaintStatus status,
                             LocalDateTime dateSubmitted, LocalDateTime lastUpdatedDate,
                             Long customerId, String refinedCustomerId, Long assignedToUserId) {
        this.complaintId = complaintId;
        this.complaintType = complaintType;
        this.category = category;
        this.description = description;
        this.preferredContactMethod = preferredContactMethod;
        this.contactEmail = contactEmail;
        this.contactPhone = contactPhone;
        this.status = status;
        this.dateSubmitted = dateSubmitted;
        this.lastUpdatedDate = lastUpdatedDate;
        this.customerId = customerId;
        this.refinedCustomerId = refinedCustomerId;
        this.assignedToUserId = assignedToUserId;
    }

    public Long getComplaintId() { return complaintId; }
    public void setComplaintId(Long complaintId) { this.complaintId = complaintId; }

    public ComplaintType getComplaintType() { return complaintType; }
    public void setComplaintType(ComplaintType complaintType) { this.complaintType = complaintType; }

    public ComplaintCategory getCategory() { return category; }
    public void setCategory(ComplaintCategory category) { this.category = category; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public PreferredContactMethod getPreferredContactMethod() { return preferredContactMethod; }
    public void setPreferredContactMethod(PreferredContactMethod preferredContactMethod) {
        this.preferredContactMethod = preferredContactMethod;
    }

    public String getContactEmail() { return contactEmail; }
    public void setContactEmail(String contactEmail) { this.contactEmail = contactEmail; }

    public String getContactPhone() { return contactPhone; }
    public void setContactPhone(String contactPhone) { this.contactPhone = contactPhone; }

    public ComplaintStatus getStatus() { return status; }
    public void setStatus(ComplaintStatus status) { this.status = status; }

    public LocalDateTime getDateSubmitted() { return dateSubmitted; }
    public void setDateSubmitted(LocalDateTime dateSubmitted) { this.dateSubmitted = dateSubmitted; }

    public LocalDateTime getLastUpdatedDate() { return lastUpdatedDate; }
    public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) { this.lastUpdatedDate = lastUpdatedDate; }

    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public String getRefinedCustomerId() { return refinedCustomerId; }
    public void setRefinedCustomerId(String refinedCustomerId) { this.refinedCustomerId = refinedCustomerId; }

    public Long getAssignedToUserId() { return assignedToUserId; }
    public void setAssignedToUserId(Long assignedToUserId) { this.assignedToUserId = assignedToUserId; }
}
