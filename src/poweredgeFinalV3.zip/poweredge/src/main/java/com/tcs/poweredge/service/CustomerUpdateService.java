package com.tcs.poweredge.service;

import org.springframework.stereotype.Service;

import com.tcs.poweredge.dto.CustomerResponse;
import com.tcs.poweredge.dto.CustomerUpdateRequest;
import com.tcs.poweredge.model.Customer;
import com.tcs.poweredge.model.User;
import com.tcs.poweredge.repository.CustomerRepository;
import com.tcs.poweredge.repository.UserRepository;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

import org.springframework.util.StringUtils;


@Service
@RequiredArgsConstructor
public class CustomerUpdateService {

    
    private final CustomerRepository customerRepository;
    private final UserRepository userRepository;

    
    @Transactional
    public CustomerResponse patchUpdate(Long id, CustomerUpdateRequest req) throws Exception {
        Customer c = customerRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found: " + id));

        // Updatable fields on Customer
        if (StringUtils.hasText(req.fname())) c.setFname(req.fname());
        if (StringUtils.hasText(req.lname())) c.setLname(req.lname());
        if (StringUtils.hasText(req.address())) c.setAddress(req.address());

        if (req.electricalSection() != null) c.setElectricalSection(req.electricalSection());
        if (req.customerType() != null) c.setCustomerType(req.customerType());

        if (StringUtils.hasText(req.mobileNumber())
                && !req.mobileNumber().equals(c.getMobileNumber())) {
            boolean exists = customerRepository
                    .existsByMobileNumber(req.mobileNumber());
            if (exists) {
                throw new Exception("mobileNumber already in use");
            }
            c.setMobileNumber(req.mobileNumber());
        }

        // Updatable field on linked User (email)
        if (StringUtils.hasText(req.email())) {
            User u = c.getUser();
            if (u == null) {
                throw new IllegalArgumentException("Cannot update email: customer has no linked user");
            }
            if (!req.email().equals(u.getEmail())) {
                boolean emailTaken = userRepository.existsByEmail(req.email());
                if (emailTaken) {
                    throw new Exception("email already in use");
                }
                u.setEmail(req.email());
            }
        }

        Customer saved = customerRepository.save(c);

        String email = (saved.getUser() != null) ? saved.getUser().getEmail() : null;

        return new CustomerResponse(
                saved.getCustomerId(),
                saved.getCousumerNumber(),                          
                saved.getFname(),
                saved.getLname(),
                saved.getAddress(),
                saved.getMobileNumber(),
                saved.getElectricalSection(),
                saved.getCustomerType(),
                saved.getRefinedCustomerId(),
                email
        );
    }

}
