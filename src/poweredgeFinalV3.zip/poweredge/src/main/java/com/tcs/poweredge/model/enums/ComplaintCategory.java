package com.tcs.poweredge.model.enums;


public enum ComplaintCategory {
    BILLING,
    SERVICE_OUTAGE,
    TECHNICAL,
    CUSTOMER_SERVICE;

    public static ComplaintCategory fromType(ComplaintType type) {
        return switch (type) {
            case BILLING_ISSUE -> BILLING;
            case POWER_OUTAGE -> SERVICE_OUTAGE;
            case METER_FAULT -> TECHNICAL;
            case CONNECTION_REQUEST -> CUSTOMER_SERVICE;
        };
    }
}
