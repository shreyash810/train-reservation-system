package com.tcs.poweredge.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.tcs.poweredge.model.enums.ConnectionStatus;
import com.tcs.poweredge.model.enums.ConnectionType;
import com.tcs.poweredge.model.enums.PaymentStatus;

@Entity
@Table(
    name = "bill",
    indexes = {
        @Index(name = "idx_bill_customer_id", columnList = "customer_id"),
        @Index(name = "idx_bill_billing_period", columnList = "billing_period")
    }
)
@Data 
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Bill {

    // PK: bill_id
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bill_id")
    private Long billId;

    // FK: customer_id → CUSTOMER.customer_id
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    // ENUM('DOMESTIC','COMMERCIAL')
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "connection_type", length = 20, nullable = false)
    private ConnectionType connectionType;

    // ENUM('CONNECTED','DISCONNECTED')
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "connection_status", length = 20, nullable = false)
    private ConnectionStatus connectionStatus;

    // e.g., "2024-06"
    @NotBlank
    @Size(min = 7, max = 7) // "YYYY-MM"
    @Pattern(regexp = "^[0-9]{4}-[0-9]{2}$", message = "billing_period must be in 'YYYY-MM' format")
    @Column(name = "billing_period", length = 7, nullable = false)
    private String billingPeriod;

    @NotNull
    @Column(name = "bill_date", nullable = false)
    private LocalDate billDate;

    @NotNull
    @Column(name = "due_date", nullable = false)
    private LocalDate dueDate;

    // DECIMAL(10,2)
    @NotNull
    @Digits(integer = 8, fraction = 2)
    @Column(name = "bill_amount", precision = 10, scale = 2, nullable = false)
    private BigDecimal billAmount;

    // DECIMAL(10,2) DEFAULT 0
    @NotNull
    @Digits(integer = 8, fraction = 2)
    @Column(name = "late_fee", precision = 10, scale = 2, nullable = false)
    private BigDecimal lateFee = BigDecimal.ZERO;

    // DECIMAL(10,2)
    @NotNull
    @Digits(integer = 8, fraction = 2)
    @Column(name = "due_amount", precision = 10, scale = 2, nullable = false)
    private BigDecimal dueAmount;

    // ENUM('PAID','UNPAID','PARTIAL')
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "payment_status", length = 20, nullable = false)
    private PaymentStatus paymentStatus;

    // nullable
    @Column(name = "payment_date")
    private LocalDate paymentDate;

    
// In Bill
    @OneToMany(mappedBy = "bill", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Payment> payments = new ArrayList<>();

   
    // ---- Lifecycle hooks ----
    @PrePersist
    protected void onCreate() {
        if (lateFee == null) lateFee = BigDecimal.ZERO;
        // If payment_status is PAID and payment_date is missing, you might auto-set it:
        // if (paymentStatus == PaymentStatus.PAID && paymentDate == null) paymentDate = LocalDate.now();
    }

    @PreUpdate
    protected void onUpdate() {
        // keep invariants if needed
    }

}

