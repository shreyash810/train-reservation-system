package com.tcs.poweredge.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.tcs.poweredge.model.enums.ModeOfPayment;
import com.tcs.poweredge.model.enums.TransactionStatus;

@Entity
@Table(
    name = "payment",
    indexes = {
        @Index(name = "idx_payment_customer_id", columnList = "customer_id"),
        @Index(name = "idx_payment_bill_id", columnList = "bill_id"),
        @Index(name = "idx_payment_transaction_date", columnList = "transaction_date")
    }
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Payment {

    // PK: payment_id
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payment_id")
    private Long paymentId;

    // Unique transaction id: VARCHAR(64)
    @NotBlank
    @Size(max = 64)
    @Column(name = "transaction_id", length = 64, nullable = false, unique = true)
    private String transactionId;

    // Transaction date-time
    @NotNull
    @Column(name = "transaction_date", nullable = false)
    private LocalDateTime transactionDate;

    // DECIMAL(10,2)
    @NotNull
    @Digits(integer = 8, fraction = 2)
    @Column(name = "transaction_amount", precision = 10, scale = 2, nullable = false)
    private BigDecimal transactionAmount;

    // ENUM('SUCCESS','FAILED','PENDING')
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_status", length = 20, nullable = false)
    private TransactionStatus transactionStatus;

    // ENUM('UPI','CARD','NETBANKING','WALLET','CASH')
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "mode_of_payment", length = 20, nullable = false)
    private ModeOfPayment modeOfPayment;

    // FK: bill_id -> BILL.bill_id
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "bill_id", nullable = false)
    private Bill bill;

    // FK: customer_id -> CUSTOMER.customer_id
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    // Created at
    @NotNull
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    // ---- Lifecycle hooks ----
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) createdAt = LocalDateTime.now();
        if (transactionDate == null) transactionDate = LocalDateTime.now();
    }

}

