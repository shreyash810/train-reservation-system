package com.tcs.poweredge.controller;


import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.tcs.poweredge.dto.AddNoteRequest;
import com.tcs.poweredge.dto.AdminComplaintDetailDTO;
import com.tcs.poweredge.dto.ChangeDescriptionRequest;
import com.tcs.poweredge.dto.ChangeStatusRequest;
import com.tcs.poweredge.dto.ComplaintResponse;
import com.tcs.poweredge.dto.CreateComplaintRequest;
import com.tcs.poweredge.model.enums.ComplaintCategory;
import com.tcs.poweredge.model.enums.ComplaintStatus;
import com.tcs.poweredge.model.enums.ComplaintType;
import com.tcs.poweredge.security.UserDetailsImpl;
import com.tcs.poweredge.service.ComplaintListingService;
import com.tcs.poweredge.service.ComplaintService;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/complaints")
public class ComplaintController {

    private final ComplaintService complaintService;
    private final ComplaintListingService listingService;

    
    @GetMapping("/{complaintId}")
    public ResponseEntity<AdminComplaintDetailDTO> getById(@PathVariable Long complaintId) {

       AdminComplaintDetailDTO dto = null;

       try {
        dto = listingService.findByComplaintId(complaintId);
       } catch (Exception e) {
        e.printStackTrace();
       }
            return ResponseEntity.ok(dto);

    }
 

    // Create complaint
    @PostMapping
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<ComplaintResponse> createComplaint(@Valid @RequestBody CreateComplaintRequest request,
                                                             Authentication authentication) {
        UserDetailsImpl customer = (UserDetailsImpl) authentication.getPrincipal();
        ComplaintResponse response = complaintService.createComplaintForCurrentCustomer(customer.getUsername(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    
    @GetMapping()
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<Page<ComplaintResponse>> listMyComplaints(
            Authentication authentication,
            @PageableDefault(size = 10, sort = "lastUpdatedDate") Pageable pageable,
            @RequestParam(name = "complaintId", required = false) Long complaintId,
            @RequestParam(name = "status", required = false) ComplaintStatus status,
            @RequestParam(name = "type", required = false) ComplaintType type
    ) {
        UserDetailsImpl customer = (UserDetailsImpl) authentication.getPrincipal();
        Page<ComplaintResponse> page = complaintService.listComplaintsForCurrentCustomer(
                customer.getUsername(), pageable, complaintId, status, type
        );

        return ResponseEntity.ok(page);
    }

    
    @GetMapping("/sme")
    @PreAuthorize("hasRole('SME')")
    public Page<AdminComplaintDetailDTO> listForSme(
            Authentication authentication,
            @PageableDefault(size = 10, sort = "lastUpdatedDate") Pageable pageable,
            @RequestParam(name = "complaintId", required = false) Long complaintId,
            @RequestParam(name = "assignedToUserId", required = false) Long assignedToUserId,
            @RequestParam(name = "status", required = false) ComplaintStatus status,
            @RequestParam(name = "type", required = false) ComplaintType type,
            @RequestParam(name = "category", required = false) ComplaintCategory category,
            @RequestParam(name = "submittedFrom", required = false) LocalDateTime submittedFrom,
            @RequestParam(name = "submittedTo", required = false) LocalDateTime submittedTo,
            @RequestParam(name = "q", required = false) String q
    ) {
        return listingService.listForSme(
                authentication,
                pageable,
                complaintId,
                assignedToUserId,
                status,
                type,
                category,
                submittedFrom,
                submittedTo,
                q
        );
    }

    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public Page<AdminComplaintDetailDTO> listForAdmin(
            Authentication authentication,
            @PageableDefault(size = 20, sort = "dateSubmitted") Pageable pageable,
            @RequestParam(name = "complaintId", required = false) Long complaintId,
            @RequestParam(name = "assignedToUserId", required = false) Long assignedToUserId,
            @RequestParam(name = "status", required = false) ComplaintStatus status,
            @RequestParam(name = "type", required = false) ComplaintType type,
            @RequestParam(name = "category", required = false) ComplaintCategory category,
            @RequestParam(name = "submittedFrom", required = false) OffsetDateTime  submittedFrom,
            @RequestParam(name = "submittedTo", required = false) OffsetDateTime  submittedTo,
            @RequestParam(name = "q", required = false) String q
    ) {
        
    ZoneId appZone = ZoneId.of("Asia/Kolkata"); // or ZoneId.systemDefault()

    LocalDateTime fromLdt = (submittedFrom != null)
            ? submittedFrom.atZoneSameInstant(appZone).toLocalDateTime()
            : null;

    LocalDateTime toLdt = (submittedTo != null)
            ? submittedTo.atZoneSameInstant(appZone).toLocalDateTime()
            : null;

        return listingService.listForAdmin(
                authentication,
                pageable,
                complaintId,
                assignedToUserId,
                status,
                type,
                category,
                fromLdt,
                toLdt,
                q
        );
    }

    
/* ---- Add notes: Admin & SME ---- */
    @PostMapping("/{complaintId}/notes")
    @PreAuthorize("hasAnyRole('ADMIN','SME')")
    public ResponseEntity<AdminComplaintDetailDTO> addNotes(
            Authentication authentication,
            @PathVariable Long complaintId,
            @Valid @RequestBody AddNoteRequest request
    ) {
        Long actorUserId = resolveCurrentUserId(authentication);
        AdminComplaintDetailDTO dto = listingService.addNote(complaintId, actorUserId, request.getNote());
        return ResponseEntity.ok(dto);
    }

    /* ---- Change status: Admin & SME ---- */
    @PatchMapping("/{complaintId}/status")
    @PreAuthorize("hasAnyRole('ADMIN','SME')")
    public ResponseEntity<AdminComplaintDetailDTO> changeStatus(
            Authentication authentication,
            @PathVariable Long complaintId,
            @Valid @RequestBody ChangeStatusRequest request
    ) {
        Long actorUserId = resolveCurrentUserId(authentication);
        AdminComplaintDetailDTO dto = listingService.changeStatus(complaintId, actorUserId, request.getStatus(), request.getNote());
        return ResponseEntity.ok(dto);
    }

    /* ---- Change description: Customer ---- */
    @PatchMapping("/{complaintId}/description")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<AdminComplaintDetailDTO> changeDescription(
            Authentication authentication,
            @PathVariable Long complaintId,
            @Valid @RequestBody ChangeDescriptionRequest request
    ) {
        Long customerUserId = resolveCurrentUserId(authentication);
        AdminComplaintDetailDTO dto = listingService.updateDescription(complaintId, customerUserId, request.getDescription());
        return ResponseEntity.ok(dto);
    }

    /* ---- Accept complaint: SME (assigns to current SME) ---- */
    @PostMapping("/{complaintId}/accept")
    @PreAuthorize("hasRole('SME')")
    public ResponseEntity<AdminComplaintDetailDTO> accept(
            Authentication authentication,
            @PathVariable Long complaintId
    ) {
        Long smeUserId = resolveCurrentUserId(authentication);
        AdminComplaintDetailDTO dto = listingService.acceptComplaint(complaintId, smeUserId);
        return ResponseEntity.ok(dto);
    }

    /* ---- Assign complaint to SME: Admin (userId in params) ---- */
    @PostMapping("/{complaintId}/assign")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AdminComplaintDetailDTO> assignToSme(
            Authentication authentication,
            @PathVariable Long complaintId,
            @RequestParam("userId") Long smeUserId
    ) {
        Long adminUserId = resolveCurrentUserId(authentication);
        AdminComplaintDetailDTO dto = listingService.assignComplaint(complaintId, adminUserId, smeUserId);
        return ResponseEntity.ok(dto);
    }

    /* ===== Helper to resolve current user id by auth principal (email) ===== */
    private Long resolveCurrentUserId(Authentication authentication) {
        UserDetailsImpl customer = (UserDetailsImpl) authentication.getPrincipal();
        
        return customer.getId();
    }


}

