package com.tcs.poweredge.dto;


import com.tcs.poweredge.model.enums.CustomerTypeEnum;
import com.tcs.poweredge.model.enums.ElectricalSectionEnum;

import jakarta.validation.constraints.*;

public record CustomerUpdateRequest(
        @Size(max = 100) String fname,
        @Size(max = 100) String lname,
        @Size(max = 255) String address,

        // Adjust to your mobile policy. Here: 10–15 digits.
        @Pattern(regexp = "^[0-9]{10,15}$", message = "mobileNumber must be 10-15 digits")
        String mobileNumber,

        ElectricalSectionEnum electricalSection,
        CustomerTypeEnum customerType,

        @Email(message = "email must be valid")
        String email
) {}

