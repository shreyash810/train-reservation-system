package com.tcs.poweredge.controller;


import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.tcs.poweredge.dto.AuthResponse;
import com.tcs.poweredge.dto.LoginRequest;
import com.tcs.poweredge.dto.RegisterRequest;
import com.tcs.poweredge.dto.UserResponse;
import com.tcs.poweredge.service.AuthService;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;




@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
public class AuthController {
    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<UserResponse> register(@Validated @RequestBody RegisterRequest request) {
        UserResponse response = authService.register(request);
        return ResponseEntity.ok(response);
    }

  
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
        
    }

    @GetMapping("/username-exist")
    public ResponseEntity<Boolean> isUserExist(@RequestParam String username){
        return ResponseEntity.ok(authService.isUserExist(username) );
    }

    @GetMapping("/email-exist")
    public ResponseEntity<Boolean> isEmailExist(@RequestParam String email){
        return ResponseEntity.ok(authService.isEmail(email) );
    }

    @GetMapping("/customerNumber-exist")
    public ResponseEntity<Boolean> isConsumerNumber(@RequestParam String number){
        return ResponseEntity.ok(authService.isNum(number) );
    }

    @GetMapping("/mob-exist")
    public ResponseEntity<Boolean> isMobNumber(@RequestParam String number){
        return ResponseEntity.ok(authService.isNum(number) );
    }
}

