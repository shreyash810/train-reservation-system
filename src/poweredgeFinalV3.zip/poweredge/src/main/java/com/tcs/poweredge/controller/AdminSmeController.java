
package com.tcs.poweredge.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

import com.tcs.poweredge.dto.SmeListingResponse;
import com.tcs.poweredge.service.SmeListingService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/smes")
public class AdminSmeController {

    private final SmeListingService smeListingService;

    /**
     * Admin can list SMEs with optional filter by smeId and pagination.
     *
     * Examples:
     *  GET /api/admin/smes
     *  GET /api/admin/smes?smeId=5
     *  GET /api/admin/smes?page=0&size=20&sort=fname,asc
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Page<SmeListingResponse> listSmes(
            @RequestParam(name = "smeId", required = false) Long smeId,
            @PageableDefault(size = 20) Pageable pageable
    ) {
        return smeListingService.getSmes(smeId, pageable);
    }
}
