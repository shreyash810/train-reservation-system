package com.tcs.poweredge.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.tcs.poweredge.model.enums.ModeOfPayment;
import com.tcs.poweredge.model.enums.TransactionStatus;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentCreateRequest {

    // Bill reference comes from the client
    @NotNull(message = "billId is required")
    private Long billId;

    // Unique transaction id: VARCHAR(64)
    @NotBlank(message = "transactionId is required")
    @Size(max = 64, message = "transactionId must be <= 64 characters")
    private String transactionId;

    // Optional — if not provided, entity @PrePersist sets it
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss[.SSS][XXX]")
    private LocalDateTime transactionDate;

    // DECIMAL(10,2) -> allow up to 8 integer digits and 2 fraction digits
    @NotNull(message = "transactionAmount is required")
    @Digits(integer = 8, fraction = 2, message = "Amount must have up to 8 integer digits and 2 decimals")
    @DecimalMin(value = "0.00", inclusive = false, message = "Amount must be greater than 0")
    private BigDecimal transactionAmount;

    // ENUM('SUCCESS','FAILED','PENDING')
    @NotNull(message = "transactionStatus is required")
    private TransactionStatus transactionStatus;

    // ENUM('UPI','CARD','NETBANKING','WALLET','CASH')
    @NotNull(message = "modeOfPayment is required")
    private ModeOfPayment modeOfPayment;

    // NOTE: customerId is NOT in the DTO; it will be derived from the JWT.
}

