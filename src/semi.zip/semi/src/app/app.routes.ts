import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Homepage } from './shared/homepage/homepage';
import { PatientRegister } from './auth/patient-register/patient-register';
import { PatientLogin } from './auth/patient-login/patient-login';
import { PatientHome } from './patient/patient-home/patient-home';
import { ScheduleAppointment } from './patient/schedule-appointment/schedule-appointment';
import { MyAppointments } from './patient/my-appointments/my-appointments';
import { Payment } from './patient/payment/payment';
import { Complaint } from './patient/complaint/complaint';
import { TrackComplaint } from './patient/track-complaint/track-complaint';
import { AdminLogin } from './auth/admin-login/admin-login';
import { AdminDashboard } from './admin/admin-dashboard/admin-dashboard';
import { ManageDoctors } from './admin/manage-doctors/manage-doctors';
import { ManageAppointments } from './admin/manage-appointments/manage-appointments';
import { SearchAppointments } from './admin/search-appointments/search-appointments';
import { ManageComplaints } from './admin/manage-complaints/manage-complaints';
import { PageNotFound } from './shared/page-not-found/page-not-found';
import { authGuard } from './guards/auth-guard';
import { roleGuard } from './guards/role-guard';

export const routes: Routes = [
  { path: '', component: Homepage },
  { path: 'auth/patient-register', component: PatientRegister },
  { path: 'auth/patient-login', component: PatientLogin },
  {
    path: 'patient/home',
    component: PatientHome,
    canActivate: [authGuard, roleGuard('PATIENT')],
  },
  {
    path: 'patient/schedule-appointment',
    component: ScheduleAppointment,
    canActivate: [authGuard, roleGuard('PATIENT')],
  },
  {
    path: 'patient/my-appointments',
    component: MyAppointments,
    canActivate: [authGuard, roleGuard('PATIENT')],
  },
  {
    path: 'patient/payment',
    component: Payment,
    canActivate: [authGuard, roleGuard('PATIENT')],
  },
  {
    path: 'patient/complaint',
    component: Complaint,
    canActivate: [authGuard, roleGuard('PATIENT')],
  },
  {
    path: 'patient/track-complaint',
    component: TrackComplaint,
    canActivate: [authGuard, roleGuard('PATIENT')],
  },
  { path: 'auth/admin-login', component: AdminLogin },
  {
    path: 'admin/dashboard',
    component: AdminDashboard,
    canActivate: [authGuard, roleGuard('ADMIN')],
  },
  {
    path: 'admin/manage-doctors',
    component: ManageDoctors,
    canActivate: [authGuard, roleGuard('ADMIN')],
  },
  {
    path: 'admin/manage-appointments',
    component: ManageAppointments,
    canActivate: [authGuard, roleGuard('ADMIN')],
  },
  {
    path: 'admin/search-appointments',
    component: SearchAppointments,
    canActivate: [authGuard, roleGuard('ADMIN')],
  },
  {
    path: 'admin/manage-complaints',
    component: ManageComplaints,
    canActivate: [authGuard, roleGuard('ADMIN')],
  },
  { path: '**', component: PageNotFound },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
