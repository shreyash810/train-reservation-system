import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.css']
})
export class AdminDashboard {

  constructor(private router: Router) {}

  goToManageDoctors() {
    this.router.navigate(['/admin/manage-doctors']);
  }

  goToManageAppointments() {
    this.router.navigate(['/admin/manage-appointments']);
  }

  goToSearchAppointments() {
    this.router.navigate(['/admin/search-appointments']);
  }

  goToManageComplaints() {
    this.router.navigate(['/admin/manage-complaints']);
  }

  logout() {
    // later → clear JWT
    localStorage.clear();
    this.router.navigate(['/']);
  }
}