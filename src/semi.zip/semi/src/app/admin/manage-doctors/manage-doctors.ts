import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-manage-doctors',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './manage-doctors.html',
  styleUrls: ['./manage-doctors.css']
})
export class ManageDoctors {

  doctors = [
    { id: 1, name: 'Dr. Sharma', specialization: 'Cardiology', availability: 'Mon–Fri' },
    { id: 2, name: 'Dr. Mehta', specialization: 'Orthopedics', availability: 'Tue–Sat' }
  ];

  doctorForm: FormGroup;
  isEditMode = false;
  selectedDoctorId: number | null = null;

  constructor(private fb: FormBuilder) {
    this.doctorForm = this.fb.group({
      name: ['', Validators.required],
      specialization: ['', Validators.required],
      availability: ['', Validators.required]
    });
  }

  editDoctor(doctor: any) {
    this.isEditMode = true;
    this.selectedDoctorId = doctor.id;
    this.doctorForm.patchValue(doctor);
  }

  saveDoctor() {
    if (this.doctorForm.invalid) return;

    if (this.isEditMode && this.selectedDoctorId !== null) {
      const index = this.doctors.findIndex(d => d.id === this.selectedDoctorId);
      this.doctors[index] = { id: this.selectedDoctorId, ...this.doctorForm.value };
    } else {
      const newDoctor = {
        id: this.doctors.length + 1,
        ...this.doctorForm.value
      };
      this.doctors.push(newDoctor);
    }

    this.resetForm();
  }

  resetForm() {
    this.doctorForm.reset();
    this.isEditMode = false;
    this.selectedDoctorId = null;
  }
}