import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-manage-appointments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './manage-appointments.html',
  styleUrls: ['./manage-appointments.css']
})
export class ManageAppointments {

  // Temporary static data (later from backend)
  appointments = [
    {
      id: 101,
      patient: 'Rahul Sharma',
      doctor: 'Dr. Sharma',
      date: '2026-01-12',
      time: '10:30',
      status: 'Pending'
    },
    {
      id: 102,
      patient: 'Anita Verma',
      doctor: 'Dr. Mehta',
      date: '2026-01-13',
      time: '12:00',
      status: 'Pending'
    }
  ];

  updateStatus(appointment: any, newStatus: string) {
    appointment.status = newStatus;

    /*
      Later backend:
      PUT /api/admin/appointments/{id}/status
    */
  }
}