import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-manage-complaints',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './manage-complaints.html',
  styleUrls: ['./manage-complaints.css']
})
export class ManageComplaints {

  complaints = [
    {
      id: 'CMP101',
      patient: 'Rahul Sharma',
      subject: 'Delay in appointment',
      description: 'Doctor arrived late for scheduled appointment.',
      status: 'Open'
    },
    {
      id: 'CMP102',
      patient: 'Anita Verma',
      subject: 'Billing issue',
      description: 'Incorrect amount charged.',
      status: 'In Progress'
    }
  ];

  updateStatus(complaint: any, newStatus: string) {
    complaint.status = newStatus;

    /*
      Backend later:
      PUT /api/admin/complaints/{id}/status
    */
  }
}