import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-search-appointments',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './search-appointments.html',
  styleUrls: ['./search-appointments.css']
})
export class SearchAppointments {

  searchText = '';
  searchDate = '';

  appointments = [
    {
      patient: 'Rahul Sharma',
      doctor: 'Dr. Sharma',
      date: '2026-01-12',
      time: '10:30'
    },
    {
      patient: 'Anita Verma',
      doctor: 'Dr. Mehta',
      date: '2026-01-13',
      time: '12:00'
    }
  ];

  get filteredAppointments() {
    return this.appointments.filter(appt =>
      (!this.searchText ||
        appt.patient.toLowerCase().includes(this.searchText.toLowerCase()) ||
        appt.doctor.toLowerCase().includes(this.searchText.toLowerCase())) &&
      (!this.searchDate || appt.date === this.searchDate)
    );
  }
}