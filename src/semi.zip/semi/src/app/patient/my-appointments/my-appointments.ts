import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-my-appointments',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './my-appointments.html',
  styleUrls: ['./my-appointments.css']
})
export class MyAppointments {

  // Temporary static data (later from backend)
  appointments = [
    {
      id: 101,
      doctor: 'Dr. Sharma',
      date: '2026-01-10',
      time: '10:30',
      status: 'Scheduled'
    },
    {
      id: 102,
      doctor: 'Dr. Mehta',
      date: '2026-01-15',
      time: '12:00',
      status: 'Scheduled'
    }
  ];

  selectedAppointment: any = null;

  constructor(private router: Router) {}

  cancelAppointment(id: number) {
    if (confirm('Are you sure you want to cancel this appointment?')) {
      this.appointments = this.appointments.filter(a => a.id !== id);
      alert('Appointment cancelled successfully');
    }
  }

  rescheduleAppointment(appointment: any) {
    this.selectedAppointment = { ...appointment };
  }

  saveReschedule() {
    const index = this.appointments.findIndex(
      a => a.id === this.selectedAppointment.id
    );

    if (index !== -1) {
      this.appointments[index] = this.selectedAppointment;
      alert('Appointment rescheduled successfully');
      this.selectedAppointment = null;
    }
  }

  backToDashboard() {
    this.router.navigate(['/patient/home']);
  }
}