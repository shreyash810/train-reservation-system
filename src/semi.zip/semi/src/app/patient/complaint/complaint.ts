import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-complaint',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './complaint.html',
  styleUrls: ['./complaint.css']
})
export class Complaint {

  complaintForm: FormGroup;

  constructor(private fb: FormBuilder, private router: Router) {
    this.complaintForm = this.fb.group({
      subject: ['', Validators.required],
      description: ['', [Validators.required, Validators.minLength(10)]]
    });
  }

  submitComplaint() {
    if (this.complaintForm.invalid) return;

    console.log('Complaint:', this.complaintForm.value);

    /*
      Later backend:
      POST /api/patient/complaints
    */

    alert('Complaint submitted successfully');
    this.router.navigate(['/patient/home']);
  }

  resetForm() {
    this.complaintForm.reset();
  }
}