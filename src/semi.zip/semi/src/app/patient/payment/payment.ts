import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './payment.html',
  styleUrls: ['./payment.css']
})
export class Payment {

  paymentForm: FormGroup;

  consultationFee = 500; // static for now

  constructor(private fb: FormBuilder, private router: Router) {
    this.paymentForm = this.fb.group({
      cardName: ['', Validators.required],
      cardNumber: ['', [Validators.required, Validators.pattern('^[0-9]{16}$')]],
      expiry: ['', Validators.required],
      cvv: ['', [Validators.required, Validators.pattern('^[0-9]{3}$')]]
    });
  }

  payNow() {
    if (this.paymentForm.invalid) return;

    console.log('Payment Details:', this.paymentForm.value);

    /*
      Later (Backend):
      POST /api/patient/payment
      → Payment Gateway Integration
    */

    alert('Payment Successful');
    this.router.navigate(['/patient/home']);
  }

  resetForm() {
    this.paymentForm.reset();
  }
}