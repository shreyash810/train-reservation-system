import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-track-complaint',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './track-complaint.html',
  styleUrls: ['./track-complaint.css']
})
export class TrackComplaint {

  complaint = {
    id: 'CMP1023',
    subject: 'Delay in appointment',
    description: 'Doctor arrived late for scheduled appointment.',
    status: 'In Progress',
    timeline: [
      { step: 'Complaint Raised' },
      { step: 'Assigned to Admin' },
      { step: 'In Progress' }
    ]
  };

}