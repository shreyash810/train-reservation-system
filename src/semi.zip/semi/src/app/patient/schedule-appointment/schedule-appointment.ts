import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-schedule-appointment',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './schedule-appointment.html',
  styleUrls: ['./schedule-appointment.css']
})
export class ScheduleAppointment {

  appointmentForm: FormGroup;

  // Temporary static data (later comes from backend)
  doctors = [
    { id: 1, name: 'Dr. Sharma', specialization: 'Cardiology' },
    { id: 2, name: 'Dr. Mehta', specialization: 'Orthopedics' },
    { id: 3, name: 'Dr. Khan', specialization: 'Dermatology' }
  ];

  constructor(private fb: FormBuilder, private router: Router) {
    this.appointmentForm = this.fb.group({
      doctorId: ['', Validators.required],
      appointmentDate: ['', Validators.required],
      appointmentTime: ['', Validators.required],
      reason: ['', [Validators.required, Validators.minLength(5)]]
    });
  }

  scheduleAppointment() {
    if (this.appointmentForm.invalid) return;

    console.log('Appointment Data:', this.appointmentForm.value);

    /*
      Later (Backend):
      POST /api/patient/appointments
    */

    alert('Appointment Scheduled Successfully');
    this.router.navigate(['/patient/home']);
  }

  resetForm() {
    this.appointmentForm.reset();
  }
}