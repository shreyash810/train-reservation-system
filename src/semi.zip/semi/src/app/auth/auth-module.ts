import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthRoutingModule } from './auth-routing-module';
import { ReactiveFormsModule } from '@angular/forms';

import { PatientRegister } from './patient-register/patient-register';
import { PatientLogin } from './patient-login/patient-login';
import { AdminLogin } from './admin-login/admin-login';

@NgModule({
  declarations: [
    
  ],
  imports: [
    CommonModule,
    AuthRoutingModule,
    ReactiveFormsModule
  ]
})
export class AuthModule { }
