import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.serivce';
@Component({
  selector: 'app-patient-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './patient-login.html',
  styleUrls: ['./patient-login.css']
})
export class PatientLogin {

  loginForm: FormGroup;
  loginError = '';

  constructor(private fb: FormBuilder, private router: Router,private auth:AuthService) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  login() {
    if (this.loginForm.invalid) return;

    const loginData = this.loginForm.value;
    console.log('Login Request:', loginData);

    /*
      Later (Backend):
      - Call Spring Boot API
      - Receive JWT token
      - Store token in localStorage
    */

    // Temporary success navigation
    this.auth.login('PATIENT');
    this.router.navigate(['/patient/home']);
  }

  resetForm() {
    this.loginForm.reset();
    this.loginError = '';
  }
}