import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.serivce';
@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule   // ✅ THIS FIXES THE ERROR
  ],
  templateUrl: './admin-login.html',
  styleUrls: ['./admin-login.css']
})
export class AdminLogin implements OnInit {

  adminLoginForm!: FormGroup;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private auth:AuthService
  ) {}

  ngOnInit(): void {
    this.adminLoginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  login(): void {
    if (this.adminLoginForm.invalid) return;

    console.log('Admin Login Data:', this.adminLoginForm.value);

    // later → backend admin authentication
    this.auth.login('ADMIN');
    this.router.navigate(['/admin/dashboard']);
  }

  reset(): void {
    this.adminLoginForm.reset();
  }
}