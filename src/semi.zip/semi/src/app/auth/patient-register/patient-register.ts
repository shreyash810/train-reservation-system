import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
@Component({
  selector: 'app-patient-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './patient-register.html',
  styleUrls: ['./patient-register.css']
})
export class PatientRegister {

  registerForm: FormGroup;

  countryCodes = ['+91', '+1', '+44', '+61'];

  constructor(private fb: FormBuilder, private router:Router) {
    this.registerForm = this.fb.group(
      {
        name: ['', [Validators.required, Validators.minLength(3)]],
        email: ['', [Validators.required, Validators.email]],
        countryCode: ['+91', Validators.required],
        mobile: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
        address: ['', Validators.required],
        username: ['', Validators.required],
        password: ['', [Validators.required, Validators.minLength(8)]],
        confirmPassword: ['', Validators.required]
      },
      { validators: this.passwordMatch }
    );
  }

  passwordMatch(form: FormGroup) {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { mismatch: true };
  }

  register() {
    if (this.registerForm.invalid) return;

    console.log('Patient Registration Data:', this.registerForm.value);
    this.router.navigate(['/']);
    // Later → send data to Spring Boot backend
  }

  resetForm() {
    this.registerForm.reset({ countryCode: '+91' });
  }
}