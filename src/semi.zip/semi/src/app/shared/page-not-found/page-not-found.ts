import { Component, ChangeDetectionStrategy } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-page-not-found',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './page-not-found.html',
  styleUrls: ['./page-not-found.css'],
})
export class PageNotFound {
  constructor(private router: Router, private location: Location) {}

  goBack() {
    this.location.back();
  }

  goHome() {
    // Aapke app flow ke hisaab se change kar sakte ho:
    // this.router.navigate(['/']);
    this.router.navigate(['/']); // safe default
  }
}