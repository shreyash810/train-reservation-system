import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.html',
  styleUrls: ['./homepage.css']
})
export class Homepage {

  constructor(private router: Router) {}

  goToRegister() {
    this.router.navigate(['/auth/patient-register']);
  }

  goToLogin() {
    this.router.navigate(['/auth/patient-login']);
  }
}