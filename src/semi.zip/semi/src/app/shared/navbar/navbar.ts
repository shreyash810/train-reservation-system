import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.serivce';
import { Router } from '@angular/router';
@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.html',
  styleUrls: ['./navbar.css']
})
export class Navbar {
  // later: role-based visibility
  constructor(public auth:AuthService,private router:Router){}
  logout() {
    // Later: clear JWT token
    localStorage.clear();
    this.router.navigate(['/']);
  }
}