
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environment';


// export type TransactionStatus = 'SUCCESS' | 'FAILED' | 'PENDING';
export type ModeOfPayment = 'UPI' | 'CARD';


// Reuse shared Page<T> if you already have it centrally
export interface Page<T> {
  content: T[];
  totalPages: number;
  totalElements: number;
  size: number;
  number: number;
  first: boolean;
  last: boolean;
  empty: boolean;
}

// --- Enums (replace with imports if these exist in your shared models) ---
export type PaymentStatus = 'PAID' | 'UNPAID' ;
export type ConnectionType = 'DOMESTIC'|'COMMERCIAL';
export type ConnectionStatus = 'CONNECTED'| 'DISCONNECTED';

// --- DTOs ---
export interface BillDTO {
  billId: number;
  customerId: number;

  billingPeriod: string; // 'YYYY-MM'
  billDate: string;      // ISO date string from backend
  dueDate: string;       // ISO date string from backend

  billAmount: string;    // BigDecimal -> keep as string to avoid float precision issues
  lateFee: string;       // BigDecimal
  dueAmount: string;     // BigDecimal

  paymentStatus: PaymentStatus;
  paymentDate?: string;  // ISO date string if present

  connectionType: ConnectionType;
  connectionStatus: ConnectionStatus;
}

// Matches backend BillListRequest (all optional)
export interface BillListFilters {
  customerId?: number;
  billId?: number;
  billingPeriod?: string;           // 'YYYY-MM'
  paymentStatus?: PaymentStatus;
  connectionType?: ConnectionType;
  connectionStatus?: ConnectionStatus;
}

@Injectable({
  providedIn: 'root'
})
export class BillListService {

  private readonly baseUrl = environment.apiBaseUrl;
  private readonly apiUrl = `${this.baseUrl}api/bills/admin/bills`;

  constructor(private http: HttpClient) {}

  /**
   * List bills with pagination and filters.
   * Matches: GET /api/bills/admin/bills
   *
   * Backend expects query params similar to BillListRequest + paging:
   * - page, size, sort
   * - customerId, billId, billingPeriod('YYYY-MM'), paymentStatus, connectionType, connectionStatus
   */
  listBills(
    page: number = 0,
    size: number = 10,
    filters?: BillListFilters,
    sort: string = 'dueDate,desc' // change if backend uses different sort key
  ): Observable<Page<BillDTO>> {
    let params = new HttpParams()
      .set('page', String(page))
      .set('size', String(size))
      .set('sort', sort);

    if (filters?.customerId !== undefined) {
      params = params.set('customerId', String(filters.customerId));
    }
    if (filters?.billId !== undefined) {
      params = params.set('billId', String(filters.billId));
    }
    if (filters?.billingPeriod) {
      params = params.set('billingPeriod', filters.billingPeriod);
    }
    if (filters?.paymentStatus) {
      params = params.set('paymentStatus', filters.paymentStatus);
    }
    if (filters?.connectionType) {
      params = params.set('connectionType', filters.connectionType);
    }
    if (filters?.connectionStatus) {
      params = params.set('connectionStatus', filters.connectionStatus);
    }

    return this.http.get<Page<BillDTO>>(this.apiUrl, { params });
  }
}
