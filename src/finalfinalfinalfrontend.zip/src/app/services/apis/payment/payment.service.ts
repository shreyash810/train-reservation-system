
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PaymentCreateRequest } from '../bills/bills-list.service';
import { ModeOfPayment } from '../adminBillslisting/bills.service';

@Injectable({ providedIn: 'root' })
export class PaymentService {
  private readonly baseUrl = 'api/bills/payment';

  constructor(private http: HttpClient) {}

  createPayment(billId: number, amount: number, mode: ModeOfPayment): Observable<PaymentResponse> {
    const payload: PaymentCreateRequest = {
      billId,
      transactionId: this.generateTransactionId(),
      transactionDate: this.formatLocalDateTime(new Date()),
      transactionAmount: Number(amount),
      transactionStatus: 'SUCCESS',
      modeOfPayment: mode
    };
    return this.http.post<PaymentResponse>(this.baseUrl, payload);
  }

  private generateTransactionId(len: number = 24): string {
    if (window.crypto?.getRandomValues) {
      const bytes = new Uint8Array(len);
      window.crypto.getRandomValues(bytes);
      return Array.from(bytes, b => ('0' + (b & 0xff).toString(16)).slice(-2)).join('').slice(0, len);
    }
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let s = '';
    for (let i = 0; i < len; i++) s += chars.charAt(Math.floor(Math.random() * chars.length));
    return s;
  }

  /**
   * Backend pattern: yyyy-MM-dd'T'HH:mm:ss[.SSS][XXX]
   * We’ll send local time with ms: e.g. 2026-01-22T11:05:47.312
   */
  private formatLocalDateTime(d: Date): string {
    const pad = (n: number) => n.toString().padStart(2, '0');
    const y = d.getFullYear();
    const m = pad(d.getMonth() + 1);
    const day = pad(d.getDate());
    const h = pad(d.getHours());
    const min = pad(d.getMinutes());
    const s = pad(d.getSeconds());
    const ms = d.getMilliseconds().toString().padStart(3, '0');
    return `${y}-${m}-${day}T${h}:${min}:${s}.${ms}`;
  }
}
