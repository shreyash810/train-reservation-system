import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import {
  BillsService,
  BillViewModel,
  PaymentResponse,
} from '../../services/apis/bills/bills-list.service';

@Component({
  selector: 'app-pay-bill',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './pay-bill.component.html',
  styleUrls: ['./pay-bill.component.css'],
})
export class PayBillComponent implements OnInit {

  paymentForm!: FormGroup;

  totalAmount = 0;
  today = new Date();

  showConfirm = false;
  paymentSuccess = false;
  paymentError: string | null = null;

  receipt?: PaymentResponse;

  private bill!: BillViewModel;

  constructor(
    private fb: FormBuilder,
    private billsService: BillsService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const selectedBill = this.billsService.getSelectedBill();

    if (!selectedBill) {
      this.router.navigate(['/customer/bills']);
      return;
    }

    this.bill = selectedBill;
    this.totalAmount = selectedBill.dueAmount;

    this.paymentForm = this.fb.group({
      cardNumber: ['', [Validators.required, Validators.pattern(/^\d{16}$/)]],
      expiryDate: ['', Validators.required],
      cvv: ['', [Validators.required, Validators.pattern(/^\d{3,4}$/)]],
      cardHolder: ['', Validators.required],
    });
  }

  // Called by "Pay Now"
  submit(): void {
    this.paymentError = null;

    if (this.paymentForm.invalid) {
      this.paymentForm.markAllAsTouched();
      return;
    }

    this.showConfirm = true;
  }

  // Called by "Confirm"
  confirmPayment(): void {
    this.showConfirm = false;

    this.billsService
      .createPayment(this.bill.billNumber, this.totalAmount)
      .subscribe({
        next: (res: PaymentResponse) => {
          this.receipt = res;
          this.paymentSuccess = true;
          this.billsService.clearSelectedBill();
        },
        error: (err) => {
          console.error(err);
          this.paymentError = 'Payment failed. Please try again.';
        },
      });
  }
}
