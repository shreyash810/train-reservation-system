
import { Component, DestroyRef, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { debounceTime, distinctUntilChanged, map, startWith, switchMap, tap } from 'rxjs/operators';
import { combineLatest, BehaviorSubject, of } from 'rxjs';// <-- update path
import { NgOptimizedImage } from '@angular/common'; // optional if using images/icons
import { BillDTO, BillListFilters, BillListService, Page } from '../../services/apis/adminBillslisting/bills.service';

@Component({
  selector: 'app-bill-list',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule, NgOptimizedImage],
  templateUrl: './admin-view-bill.component.html',
  styleUrls: ['./admin-view-bill.component.css']
})
export class BillListComponent implements OnInit {

  private fb = inject(FormBuilder);
  private billsService = inject(BillListService);
  private destroyRef = inject(DestroyRef);

  // --- UI State ---
  readonly page$ = new BehaviorSubject<number>(0);
  readonly size$ = new BehaviorSubject<number>(10); // keeping the same default size
  readonly sort$ = new BehaviorSubject<string>('dueDate,desc');

  // Loading / error states
  loading = signal<boolean>(false);
  errorMsg = signal<string | null>(null);

  // --- Enums for selects (match backend values exactly) ---
  paymentStatusOptions: Array<BillDTO['paymentStatus'] | ''> =
    ['', 'PAID', 'UNPAID'];
  connectionTypeOptions: Array<BillDTO['connectionType'] | ''> =
    ['', 'DOMESTIC', 'COMMERCIAL'];
  connectionStatusOptions: Array<BillDTO['connectionStatus'] | ''> =
    ['', 'CONNECTED', 'DISCONNECTED'];

  // --- Reactive Filters Form ---
  filtersForm = this.fb.nonNullable.group({
    customerId: this.fb.control<number | null>(null),
    billId: this.fb.control<number | null>(null),
    billingPeriod: this.fb.control<string>(''), // use <input type="month"> which returns 'YYYY-MM'
    paymentStatus: this.fb.control<BillDTO['paymentStatus'] | ''>(''),
    connectionType: this.fb.control<BillDTO['connectionType'] | ''>(''),
    connectionStatus: this.fb.control<BillDTO['connectionStatus'] | ''>(''),
  });

  // --- Data stream for the table ---
  readonly data$ = combineLatest([
    this.filtersForm.valueChanges.pipe(
      startWith(this.filtersForm.getRawValue()),
      debounceTime(250),
      distinctUntilChanged((a, b) => JSON.stringify(a) === JSON.stringify(b)),
      tap(() => this.page$.next(0)) // reset to first page on filters change
    ),
    this.page$,
    this.size$,
    this.sort$,
  ]).pipe(
    tap(() => {
      this.loading.set(true);
      this.errorMsg.set(null);
    }),
    switchMap(([formValue, page, size, sort]) => {
      const filters: BillListFilters = {
        customerId: formValue.customerId ?? undefined,
        billId: formValue.billId ?? undefined,
        billingPeriod: formValue.billingPeriod || undefined,
        paymentStatus: (formValue.paymentStatus || undefined) as any,
        connectionType: (formValue.connectionType || undefined) as any,
        connectionStatus: (formValue.connectionStatus || undefined) as any,
      };
      return this.billsService.listBills(page, size, filters, sort);
    }),
    tap({
      next: () => this.loading.set(false),
      error: (err) => {
        console.error(err);
        this.loading.set(false);
        this.errorMsg.set('Failed to load bills. Please try again.');
      }
    })
  );

  // Expose helpers derived from data
  content$ = this.data$.pipe(map((p: Page<BillDTO>) => p.content));
  pageInfo$ = this.data$.pipe(map((p: Page<BillDTO>) => ({
    page: p.number,
    size: p.size,
    totalElements: p.totalElements,
    totalPages: p.totalPages,
    first: p.first,
    last: p.last
  })));

  ngOnInit(): void {
    // Ensure initial emission (already via startWith)
  }

  // --- Pagination handlers ---
  goToPage(page: number) {
    if (page < 0) return;
    this.page$.next(page);
  }

  nextPage(current: number, last: boolean) {
    if (!last) this.page$.next(current + 1);
  }

  prevPage(current: number, first: boolean) {
    if (!first) this.page$.next(current - 1);
  }

  setPageSize(size: number) {
    this.size$.next(size);
    this.page$.next(0); // reset to first page when size changes
  }

  // --- Sort handling (server-side) ---
  setSort(sort: string) {
    this.sort$.next(sort);
    this.page$.next(0);
  }

  // --- UI helpers ---
  trackByBillId = (_: number, item: BillDTO) => item.billId;

  // Format money safely from string
  asNumber(input: string | null | undefined): number {
    if (input == null) return 0;
    const n = Number(input);
    return isNaN(n) ? 0 : n;
  }
}
