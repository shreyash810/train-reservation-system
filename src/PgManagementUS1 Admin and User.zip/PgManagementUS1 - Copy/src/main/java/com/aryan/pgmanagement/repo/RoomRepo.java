package com.aryan.pgmanagement.repo;

import com.aryan.pgmanagement.model.Room;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface RoomRepo extends JpaRepository<Room, UUID> {

    List<Room> findByRoomTypeAndAvailabilityTrue(String roomType);

    List<Room> findAll();

    Optional<Room> findByRoomNumber(String roomNumber);

    boolean existsByRoomNumber(String number);
}
