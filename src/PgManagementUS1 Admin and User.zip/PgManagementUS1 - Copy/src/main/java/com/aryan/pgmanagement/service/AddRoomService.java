package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.AddRoomRequest;
import com.aryan.pgmanagement.dto.AddRoomResponse;
import com.aryan.pgmanagement.model.Room;
import com.aryan.pgmanagement.repo.RoomRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Random;
import java.util.UUID;

@Service
public class AddRoomService {

    @Autowired
    private RoomRepo roomRepo;

    public AddRoomResponse addRoom(AddRoomRequest req) {

        if (req.getPricePerDay() <= 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Price must be a positive value"
            );
        }

        if (req.getDescription() != null &&
                req.getDescription().length() > 500) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Description cannot exceed 500 characters"
            );
        }

        String roomNumber = generateUniqueRoomNumber();

        Room room = new Room();
        room.setRoomNumber(
                UUID.randomUUID().toString().replace("-", "").substring(0, 6).toUpperCase()
        );
        room.setRoomType(req.getRoomType());
        room.setPricePerDay(req.getPricePerDay());
        room.setAvailability(req.isAvailability());
        room.setAmenities(req.getAmenities());
        room.setRoomSize(1);

        roomRepo.save(room);

        return new AddRoomResponse(
                "Room added successfully",
                roomNumber,
                room.getRoomType(),
                room.getPricePerDay()
        );
    }

    private String generateUniqueRoomNumber() {
        String number;
        do {
            number = "RM" + (100000 + new Random().nextInt(900000));
        } while (roomRepo.existsByRoomNumber(number));
        return number;
    }
}

