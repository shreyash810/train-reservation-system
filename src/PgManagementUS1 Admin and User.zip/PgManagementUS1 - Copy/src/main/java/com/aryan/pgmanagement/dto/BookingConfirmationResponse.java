package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingConfirmationResponse {

    private UUID roomId;
    private String roomType;
    private double pricePerDay;
    private LocalDate fromDate;
    private LocalDate toDate;
    private long totalDays;
    private double totalCost;

    private String tenantName;
    private String email;
    private String mobileNumber;
}
