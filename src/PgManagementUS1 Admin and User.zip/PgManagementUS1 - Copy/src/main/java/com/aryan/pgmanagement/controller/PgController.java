package com.aryan.pgmanagement.controller;

import com.aryan.pgmanagement.dto.*;
import com.aryan.pgmanagement.model.PgCustomer;
import com.aryan.pgmanagement.model.Room;
import com.aryan.pgmanagement.service.*;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class PgController {
    @Autowired
    private PgService service;

    @Autowired
    private RoomSearchService roomService;

    @Autowired
    private BookingService bookingService;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private InvoiceService invoiceService;

    @Autowired
    private BookingHistoryService bookingHistoryService;

    @Autowired
    private CancelBookingService cancelService;

    @Autowired
    private ComplaintService complaintService;

    @Autowired
    private AdminUserService adminService;

    @Autowired
    private AdminRoomService adminRomService;

    @Autowired
    private AddRoomService addRoomService;

    @Autowired
    private AdminBookingService adminBookingService;

    @GetMapping({"/", "/home"})
    public String home(){
        return "Welcome to PG Management System";
    }

    @GetMapping("/viewCustomers")
    public List<PgCustomer> viewAllCustomers(){
        return service.viewAllCustomers();
    }


    @PostMapping("/addCustomer")
    public ResponseEntity<TenantRegistrationResponse> addCustomer(@Valid @RequestBody TenantRegistrationRequest req){
        TenantRegistrationResponse resp = service.registerCustomer(req);
        return ResponseEntity.status(200).body(resp);
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest req){
        LoginResponse resp = service.loginPage(req);
        return ResponseEntity.status(200).body(resp);
    }

    @GetMapping("/profile")
    public ResponseEntity<ProfileResponse> homepage(@RequestParam String username){
        ProfileResponse resp = service.homepage(username);
        return ResponseEntity.status(200).body(resp);
    }

    @PostMapping("/searchRooms")
    public ResponseEntity<List<RoomSearchResponse>> searchRooms(
            @Valid @RequestBody RoomSearchRequest req
    ) {
        List<RoomSearchResponse> resp = roomService.searchRooms(req);
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/pay")
    public ResponseEntity<PaymentResponse> pay(
            @Valid @RequestBody PaymentRequest req) {

        return ResponseEntity.ok(
                paymentService.processPayment(req)
        );
    }

    @PostMapping("/generate")
    public ResponseEntity<InvoiceResponse> generateInvoice(
            @Valid @RequestBody InvoiceRequest request) {

        return ResponseEntity.ok(
                invoiceService.generateInvoice(request.getBookingId())
        );
    }

    @GetMapping("/history")
    public ResponseEntity<BookingHistoryResponse> getHistory(
            @RequestParam UUID userId) {

        BookingHistoryResponse response =
                bookingHistoryService.getBookingHistory(userId);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/complaint/register")
    public ResponseEntity<ComplaintResponse> registerComplaint(
            @Valid @RequestBody ComplaintRequest req) {

        return ResponseEntity.ok(
                complaintService.registerComplaint(req)
        );
    }

    @GetMapping("/complaints")
    public ResponseEntity<List<ComplaintListItemDTO>> viewComplaints(
            @RequestParam UUID userId) {

        return ResponseEntity.ok(
                complaintService.getComplaintList(userId)
        );
    }


    @GetMapping("/complaints/list")
    public ResponseEntity<List<ComplaintListItemDTO>> getComplaintList(
            @RequestParam UUID userId) {

        return ResponseEntity.ok(
                complaintService.getComplaintList(userId)
        );
    }

    @GetMapping("/complaints/detail")
    public ResponseEntity<ComplaintDetailResponse> getComplaintDetail(
            @RequestParam UUID complaintId,
            @RequestParam UUID userId) {

        return ResponseEntity.ok(
                complaintService.getComplaintDetail(complaintId, userId)
        );
    }

    @PostMapping("/complaints/confirm")
    public ResponseEntity<String> confirmResolution(
            @Valid @RequestBody ComplaintActionRequest req) {

        complaintService.confirmResolution(
                req.getComplaintId(), req.getUserId());

        return ResponseEntity.ok("Complaint closed successfully");
    }

    @PostMapping("/complaints/reopen")
    public ResponseEntity<String> reopenComplaint(
            @Valid @RequestBody ComplaintActionRequest req) {

        complaintService.reopenComplaint(
                req.getComplaintId(), req.getUserId());

        return ResponseEntity.ok("Complaint reopened successfully");
    }

    @PostMapping("/create")
    public ResponseEntity<CreateUserResponse> createUser(
            @RequestBody CreateUserRequest req) {

        return ResponseEntity.ok(adminService.createUser(req));
    }

    @GetMapping("/list")
    public ResponseEntity<List<UserListDTO>> listUsers() {
        return ResponseEntity.ok(adminService.getAllUsers());
    }

    @PutMapping("/update")
    public ResponseEntity<String> updateUser(
            @RequestBody UpdateUserRequest req) {

        adminService.updateUser(req);
        return ResponseEntity.ok("User updated successfully");
    }

    @PostMapping("/reset-password")
    public ResponseEntity<String> resetPassword(
            @RequestBody ResetPasswordRequest req) {

        String pwd = adminService.resetPassword(req);
        return ResponseEntity.ok("New Password: " + pwd);
    }

    @PostMapping("/admin/user/status")
    public ResponseEntity<String> updateUserStatus(
            @Valid @RequestBody AdminUserStatusRequest req) {

        boolean active = adminService.changeUserStatus(req);

        return ResponseEntity.ok(
                active ? "User activated successfully"
                        : "User deactivated successfully"
        );
    }

    @GetMapping("/admin/rooms")
    public ResponseEntity<List<Room>> getAllRooms() {
        return ResponseEntity.ok(adminRomService.getAllRooms());
    }

    @PutMapping("admin/rooms/update/{roomId}")
    public ResponseEntity<String> updateRoom(
            @PathVariable UUID roomId,
            @Valid @RequestBody RoomUpdateRequest req) {

        adminRomService.updateRoom(roomId, req);

        return ResponseEntity.ok("Room details updated successfully");
    }

    @PostMapping("/admin/rooms/add")
    public ResponseEntity<AddRoomResponse> addRoom(
            @RequestBody AddRoomRequest req) {

        return ResponseEntity.ok(
                addRoomService.addRoom(req)
        );
    }

    @GetMapping("/admin/bookings")
    public ResponseEntity<List<AdminBookingListDTO>> viewAllBookings() {
        return ResponseEntity.ok(adminBookingService.getAllBookings());
    }

    @PostMapping("/admin/bookings/create")
    public ResponseEntity<BookingResponse> createBookingByAdmin(
            @Valid @RequestBody AdminBookingCreateRequest req) {

        return ResponseEntity.ok(
                adminBookingService.createBooking(req)
        );
    }

    // 2️⃣ Update Booking (Admin)
    @PutMapping("/admin/bookings/update/{bookingId}")
    public ResponseEntity<String> updateBookingByAdmin(
            @PathVariable UUID bookingId,
            @Valid @RequestBody AdminBookingUpdateRequest req) {

        adminBookingService.updateBooking(bookingId, req);

        return ResponseEntity.ok("Booking updated successfully");
    }


    // 3️⃣ Cancel Booking (Admin)
    @PostMapping("/admin/bookings/cancel/{bookingId}")
    public ResponseEntity<String> cancelBookingByAdmin(
            @PathVariable UUID bookingId) {

        adminBookingService.cancelBooking(bookingId);

        return ResponseEntity.ok("Booking cancelled successfully");
    }

}
