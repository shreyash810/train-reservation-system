package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@AllArgsConstructor
public class ComplaintDetailResponse {

    private UUID complaintId;
    private UUID bookingId;
    private String category;
    private String title;
    private String description;
    private String status;
    private String supportResponse;
    private String resolutionNotes;
    private LocalDateTime submittedAt;
}
