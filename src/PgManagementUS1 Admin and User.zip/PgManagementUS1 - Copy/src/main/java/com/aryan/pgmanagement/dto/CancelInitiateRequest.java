package com.aryan.pgmanagement.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.UUID;

@Data
public class CancelInitiateRequest {

    @NotNull
    private UUID bookingId;

    @NotNull
    private UUID userId;
}
