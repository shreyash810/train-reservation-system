package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.UUID;

@Data
@AllArgsConstructor
public class CreateUserResponse {
    private UUID userId;
    private String username;
    private String role;
    private String tempPassword;
    private String message;
}
