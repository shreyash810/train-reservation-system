package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.PaymentRequest;
import com.aryan.pgmanagement.dto.PaymentResponse;
import com.aryan.pgmanagement.model.Booking;
import com.aryan.pgmanagement.model.Payment;
import com.aryan.pgmanagement.model.PgCustomer;
import com.aryan.pgmanagement.model.Room;
import com.aryan.pgmanagement.repo.BookingRepo;
import com.aryan.pgmanagement.repo.PaymentRepo;
import com.aryan.pgmanagement.repo.PgRepo;
import com.aryan.pgmanagement.repo.RoomRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepo paymentRepo;

    @Autowired
    private BookingRepo bookingRepo;

    @Autowired
    private RoomRepo roomRepo;

    @Autowired
    private PgRepo pgRepo;

    public PaymentResponse processPayment(PaymentRequest req) {

        Booking booking = bookingRepo.findById(req.getBookingId())
                .orElseThrow(() ->
                        new ResponseStatusException(HttpStatus.NOT_FOUND, "Booking not found")
                );

        if (paymentRepo.existsByBookingId(booking.getBookingId())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Payment already completed for this booking"
            );
        }

        Room room = roomRepo.findById(booking.getRoomId())
                .orElseThrow(() ->
                        new ResponseStatusException(HttpStatus.NOT_FOUND, "Room not found")
                );

        PgCustomer customer = pgRepo.findById(booking.getUserId())
                .orElseThrow(() ->
                        new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found")
                );

        // Simulated payment failure rule
        if (req.getCardNumber().startsWith("0000")) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Transaction failed. Please check your details and try again."
            );
        }

        String transactionId = "TXN-" + UUID.randomUUID();

        Payment payment = new Payment();
        payment.setBookingId(req.getBookingId());
        payment.setAmount(req.getAmount());
        payment.setPaymentMethod(req.getPaymentMethod()); // 🔥 MISSING LINE
        payment.setTransactionId("TXN-" + UUID.randomUUID());
        payment.setStatus("SUCCESS");
        payment.setCreatedAt(LocalDateTime.now());


        paymentRepo.save(payment);

        booking.setStatus("CONFIRMED");
        bookingRepo.save(booking);

        return new PaymentResponse(
                "Payment successful! Your booking is confirmed.",
                booking.getBookingId(),
                transactionId,
                customer.getTenantName(),
                room.getRoomType(),
                room.getRoomNumber(),
                booking.getTotalCost()
        );
    }
}
