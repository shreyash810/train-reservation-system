package com.aryan.pgmanagement.dto;

import lombok.Data;

import java.time.LocalDate;
import java.util.UUID;

@Data
public class AdminBookingUpdateRequest {
    private UUID roomId;
    private LocalDate fromDate;
    private LocalDate toDate;
}

