package com.aryan.pgmanagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "rooms")
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "room_id", nullable = false, updatable = false)
    private UUID roomId;

    @Column(name = "room_number", nullable = false, unique = true, length = 6)
    private String roomNumber;

    @Column(name = "address", length = 255)
    private String address;


    @Column(name = "room_type", nullable = false)
    private String roomType;

    @Column(name = "price_per_day", nullable = false)
    private double pricePerDay;

    @Column(name = "availability", nullable = false)
    private boolean availability;

    @Column(name = "room_size", nullable = false)
    private int roomSize;

    @ElementCollection
    @CollectionTable(
            name = "room_amenities",
            joinColumns = @JoinColumn(name = "room_id")
    )
    @Column(name = "amenity")
    private List<String> amenities;

    @Column(name = "image_url")
    private String imageUrl;
}
