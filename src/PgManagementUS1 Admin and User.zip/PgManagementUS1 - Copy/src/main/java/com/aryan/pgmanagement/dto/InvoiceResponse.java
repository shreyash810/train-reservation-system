package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@AllArgsConstructor
public class InvoiceResponse {

    private UUID invoiceId;
    private UUID bookingId;
    private String transactionId;
    private double totalAmount;
    private LocalDateTime generatedAt;
}
