package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.UUID;

@Data
@AllArgsConstructor
public class UserListDTO {
    private UUID userId;
    private String username;
    private String email;
    private String role;
    private String status; // Active / Inactive
}
