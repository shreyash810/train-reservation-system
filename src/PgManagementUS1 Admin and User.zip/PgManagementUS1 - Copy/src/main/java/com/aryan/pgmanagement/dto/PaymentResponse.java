package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentResponse {

    private String message;

    // Required by US6
    private UUID bookingId;
    private String transactionId;

    private String tenantName;

    private String roomType;
    private String roomNumber;

    private double paymentAmount;
}
