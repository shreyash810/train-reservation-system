package com.aryan.pgmanagement.repo;

import com.aryan.pgmanagement.model.Complaint;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ComplaintRepo extends JpaRepository<Complaint, UUID> {

    List<Complaint> findByUserId(UUID userId);

    Optional<Complaint> findByComplaintIdAndUserId(
            UUID complaintId, UUID userId
    );
}
