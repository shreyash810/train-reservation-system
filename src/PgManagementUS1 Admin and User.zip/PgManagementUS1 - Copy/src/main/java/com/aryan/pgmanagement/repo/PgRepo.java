package com.aryan.pgmanagement.repo;

import com.aryan.pgmanagement.model.PgCustomer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface PgRepo extends JpaRepository<PgCustomer, UUID> {

    public boolean existsByEmail(String email);
    public boolean existsByUsername(String username);
    public boolean existsByMobileNumber(String mobileNumber);
    public PgCustomer findByUsername(String username);
}
