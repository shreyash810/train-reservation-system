package com.aryan.pgmanagement.controller;

import com.aryan.pgmanagement.dto.*;
import com.aryan.pgmanagement.service.BookingService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/booking")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @PostMapping("/initiate")
    public ResponseEntity<BookingConfirmationResponse> initiateBooking(
            @Valid @RequestBody BookingInitiateRequest req) {
        return ResponseEntity.ok(
                bookingService.initiateBooking(req)
        );
    }

    @PostMapping("/confirm")
    public ResponseEntity<BookingResponse> confirmBooking(
            @Valid @RequestBody BookingCreateRequest req) {
        return ResponseEntity.ok(
                bookingService.confirmBooking(req)
        );
    }
}
