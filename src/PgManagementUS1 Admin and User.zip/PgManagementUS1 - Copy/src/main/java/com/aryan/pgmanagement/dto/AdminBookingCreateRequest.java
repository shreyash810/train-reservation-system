package com.aryan.pgmanagement.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;
import java.util.UUID;

@Data
public class AdminBookingCreateRequest {

    @NotNull
    private UUID userId;

    @NotNull
    private UUID roomId;

    @NotNull
    private LocalDate fromDate;

    @NotNull
    private LocalDate toDate;

    @NotBlank
    private String paymentMethod;
}
