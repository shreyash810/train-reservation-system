package com.aryan.pgmanagement.repo;

import com.aryan.pgmanagement.model.Booking;
import jakarta.validation.constraints.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Repository
public interface BookingRepo extends JpaRepository<Booking, UUID> {

    List<Booking> findByRoomIdAndStatusAndFromDateLessThanEqualAndToDateGreaterThanEqual(
            UUID roomId,
            String status,
            LocalDate toDate,
            LocalDate fromDate
    );

    List<Booking> findByRoomIdAndStatusIn(
            UUID roomId,
            List<String> status
    );

    List<Booking> findByRoomIdAndFromDateLessThanEqualAndToDateGreaterThanEqual(
            UUID roomId,
            LocalDate toDate,
            LocalDate fromDate
    );

    List<Booking> findByUserId(UUID userId);

    List<Booking> findByBookingIdAndUserId(UUID bookingId, UUID userId);

    boolean existsByRoomIdAndStatusIn(
            UUID roomId,
            List<String> status
    );

    boolean existsByRoomIdAndStatusInAndFromDateLessThanEqualAndToDateGreaterThanEqual(UUID roomId, List<String> confirmed, LocalDate toDate, LocalDate fromDate);

    boolean existsByRoomIdAndFromDateLessThanEqualAndToDateGreaterThanEqual(UUID roomId, @NotNull LocalDate toDate, @NotNull LocalDate fromDate);
}
