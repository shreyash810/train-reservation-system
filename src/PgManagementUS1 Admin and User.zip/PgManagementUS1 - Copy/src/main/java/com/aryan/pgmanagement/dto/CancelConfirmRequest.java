package com.aryan.pgmanagement.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.UUID;

@Data
public class CancelConfirmRequest {

    @NotNull
    private UUID bookingId;

    @NotNull
    private UUID userId;

    @NotNull
    private Boolean confirm; // YES / NO
}
