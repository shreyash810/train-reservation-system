package com.aryan.pgmanagement.service;

import com.aryan.pgmanagement.dto.RoomSearchRequest;
import com.aryan.pgmanagement.dto.RoomSearchResponse;
import com.aryan.pgmanagement.model.Booking;
import com.aryan.pgmanagement.model.Room;
import com.aryan.pgmanagement.repo.BookingRepo;
import com.aryan.pgmanagement.repo.RoomRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class RoomSearchService {

    @Autowired
    private RoomRepo roomRepo;

    @Autowired
    private BookingRepo bookingRepo;

    public List<RoomSearchResponse> searchRooms(RoomSearchRequest req) {

        if (req.getAvailableFrom() == null || req.getAvailableTo() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Available-from and Available-to dates are required"
            );
        }

        if (req.getAvailableFrom().isBefore(LocalDate.now())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Available-from Date cannot be in the past."
            );
        }

        if (req.getAvailableTo().isBefore(req.getAvailableFrom())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Available-to date must be after available-from date."
            );
        }

        if (req.getRoomType() == null || req.getRoomType().trim().isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Please select a type."
            );
        }

        List<Room> rooms = roomRepo.findByRoomTypeAndAvailabilityTrue(
                req.getRoomType()
        );

        List<RoomSearchResponse> responseList = new ArrayList<>();

        for (Room room : rooms) {

            List<Booking> bookings =
                    bookingRepo.findByRoomIdAndStatusAndFromDateLessThanEqualAndToDateGreaterThanEqual(
                            room.getRoomId(),
                            "CONFIRMED",
                            req.getAvailableTo(),
                            req.getAvailableFrom()
                    );

            if (bookings.isEmpty()) {

                RoomSearchResponse response = new RoomSearchResponse(
                        room.getRoomId(),
                        room.getRoomType(),
                        (int)room.getPricePerDay(),
                        room.getAmenities(),
                        room.getRoomSize(),
                        true,
                        room.getImageUrl()
                );

                responseList.add(response);
            }
        }

        return responseList;
    }
}
