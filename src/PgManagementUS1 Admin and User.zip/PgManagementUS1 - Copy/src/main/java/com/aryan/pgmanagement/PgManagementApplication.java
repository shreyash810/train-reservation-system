package com.aryan.pgmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(PgManagementApplication.class, args);
    }

}
