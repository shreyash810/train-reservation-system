package com.aryan.pgmanagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(
        name = "pgtable",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = {"email"}),
                @UniqueConstraint(columnNames = {"user_name"}),
                @UniqueConstraint(columnNames = {"mobile_number"})
        })
public class PgCustomer {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "user_id", nullable = false, updatable = false)
    private UUID userId;

    @Column(name = "tenant_name", nullable = false, length = 100)
    private String tenantName;

    @Column(name = "email", nullable = false, length = 255)
    private String email;

    @Column(name = "country_code", nullable = false, length = 5)
    private String countryCode;

    @Column(name = "mobile_number", nullable = false, length = 15)
    private String mobileNumber;

    @Column(name = "address", nullable = false, length = 500)
    private String address;

    @Column(name = "user_name", nullable = false, length = 100)
    private String username;

    @Column(name = "password_hash", nullable = false, length = 100)
    private String password;

    @Column(name = "login_tries")
    private Integer loginTries;

    @Column(name = "account_blocked")
    private Boolean accountBlocked = false;

    @Column(nullable = false, length = 20)
    private String role;
// ADMIN, TENANT, SUPPORT

    @Column(nullable = false)
    private Boolean forcePasswordChange = true;

    @Column(nullable = false)
    private Boolean active = true;
}
