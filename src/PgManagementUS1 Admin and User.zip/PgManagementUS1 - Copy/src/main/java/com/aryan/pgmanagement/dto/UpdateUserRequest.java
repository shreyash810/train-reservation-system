package com.aryan.pgmanagement.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class UpdateUserRequest {
    private UUID userId;
    private String username;
    private String email;
    private String role;
}

