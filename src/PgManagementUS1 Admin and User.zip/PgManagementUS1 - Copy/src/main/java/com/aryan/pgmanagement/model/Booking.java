package com.aryan.pgmanagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "booking_id", nullable = false, updatable = false)
    private UUID bookingId;

    @Column(name = "room_id", nullable = false)
    private UUID roomId;

    @Column(name = "user_id", nullable = false)
    private UUID userId;

    @Column(name = "from_date", nullable = false)
    private LocalDate fromDate;

    @Column(name = "to_date", nullable = false)
    private LocalDate toDate;

    @Column(name = "total_cost", nullable = false)
    private double totalCost;

    @Column(name = "payment_method", nullable = false)
    private String paymentMethod;
    // CREDIT_CARD, DEBIT_CARD, UPI, WALLET

    @Column(name = "status", nullable = false)
    private String status;
    // PENDING, CONFIRMED, CANCELLED

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
}
