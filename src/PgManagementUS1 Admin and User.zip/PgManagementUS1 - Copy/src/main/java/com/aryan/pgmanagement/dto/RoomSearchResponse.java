package com.aryan.pgmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;
import java.util.UUID;

@Data
@AllArgsConstructor
public class RoomSearchResponse {

    private UUID roomId;

    private String roomType;

    private int price;

    private List<String> amenities;

    private int roomSize;

    private boolean available;

    private String imageUrl;
}
