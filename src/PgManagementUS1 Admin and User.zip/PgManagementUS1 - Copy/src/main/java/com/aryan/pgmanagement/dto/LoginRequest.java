package com.aryan.pgmanagement.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginRequest {
    @NotBlank(message = "Enter a valid username")
    private String userName;

    @NotBlank(message = "Enter a valid password.")
    private String password;
}
