package com.aryan.pgmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PgManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
