package com.tcs.poweredge.mapper;



import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import com.tcs.poweredge.dto.BillDTO;
import com.tcs.poweredge.dto.CreateBillRequest;
import com.tcs.poweredge.model.Bill;
import com.tcs.poweredge.model.Customer;
import com.tcs.poweredge.model.enums.PaymentStatus;

/**
 * Simple mapper for Bill <-> DTO.
 * Keep it static and dependency-free for a practice project.
 */
public final class BillMapper {

    private BillMapper() {
        // utility class
    }

    // --- Entity -> DTO ---

    public static BillDTO toDTO(Bill bill) {
        if (bill == null) return null;

        return BillDTO.builder()
                .billId(bill.getBillId())
                .customerId(
                        bill.getCustomer() != null ? bill.getCustomer().getCustomerId() : null
                )
                .billingPeriod(bill.getBillingPeriod())
                .billDate(bill.getBillDate())
                .dueDate(bill.getDueDate())
                .billAmount(bill.getBillAmount())
                .lateFee(bill.getLateFee())
                .dueAmount(bill.getDueAmount())
                .paymentStatus(bill.getPaymentStatus())
                .paymentDate(bill.getPaymentDate())
                .connectionType(bill.getConnectionType())
                .connectionStatus(bill.getConnectionStatus())
                .build();
    }

    public static List<BillDTO> toDTOList(List<Bill> bills) {
        if (bills == null) return List.of();
        return bills.stream()
                .filter(Objects::nonNull)
                .map(BillMapper::toDTO)
                .collect(Collectors.toList());
    }

    // --- (Optional) Create helper: Request -> Entity ---

    /**
     * If you prefer to keep entity creation in the mapper, use this.
     * Otherwise, you can remove it and build the entity in the service.
     */
    public static Bill fromCreateRequest(Customer customer, CreateBillRequest req) {
        if (customer == null || req == null) return null;

        BigDecimal late = req.getLateFee() == null ? BigDecimal.ZERO : req.getLateFee();
        BigDecimal dueAmount = (req.getBillAmount() == null ? BigDecimal.ZERO : req.getBillAmount()).add(late);

        return Bill.builder()
                .customer(customer)
                .connectionType(req.getConnectionType())
                .connectionStatus(req.getConnectionStatus())
                .billingPeriod(req.getBillingPeriod())
                .billDate(req.getBillDate())
                .dueDate(req.getDueDate())
                .billAmount(req.getBillAmount())
                .lateFee(late)
                .dueAmount(dueAmount)
                .paymentStatus(PaymentStatus.UNPAID)
                .paymentDate(null)
                .build();
    }
}
