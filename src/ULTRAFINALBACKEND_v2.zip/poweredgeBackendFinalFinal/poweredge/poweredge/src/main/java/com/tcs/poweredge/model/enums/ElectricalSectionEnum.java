package com.tcs.poweredge.model.enums;

public enum ElectricalSectionEnum {
    OFFICE,
    REGION,
    EAST_ZONE,
    WEST_ZONE,
    NORTH_ZONE,
    SOUTH_ZONE
}
