package com.tcs.poweredge.model.enums;


public enum ConnectionType {
    DOMESTIC, COMMERCIAL
}
