package com.tcs.poweredge.dto;

import com.tcs.poweredge.model.enums.ComplaintStatus;
 
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ChangeStatusRequest {
    
    @NotNull
    private ComplaintStatus status;

    // Optional note appended to the complaint notes
    private String note;
}
