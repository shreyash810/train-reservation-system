package com.tcs.poweredge.dto;


import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;

import com.tcs.poweredge.model.enums.ConnectionStatus;
import com.tcs.poweredge.model.enums.ConnectionType;
import com.tcs.poweredge.model.enums.PaymentStatus;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BillDTO {
    private Long billId;
    private Long customerId;

    private String billingPeriod;   // YYYY-MM
    private LocalDate billDate;
    private LocalDate dueDate;

    private BigDecimal billAmount;
    private BigDecimal lateFee;
    private BigDecimal dueAmount;

    private PaymentStatus paymentStatus;
    private LocalDate paymentDate;

    private ConnectionType connectionType;
    private ConnectionStatus connectionStatus;
}
