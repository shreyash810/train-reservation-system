package com.tcs.poweredge.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(
    name = "smes"
)
@Data 
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Sme {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long smeId;

    @NotBlank
    @Size(max = 100)
    private String fname;

    @NotBlank
    @Size(max = 100)
    private String lname;

    @NotBlank
    @Size(max = 15)
    @Column(unique = true)
    private String mobileNumber;

    @OneToOne(mappedBy = "sme" , fetch = FetchType.LAZY)
    private User user;
}
