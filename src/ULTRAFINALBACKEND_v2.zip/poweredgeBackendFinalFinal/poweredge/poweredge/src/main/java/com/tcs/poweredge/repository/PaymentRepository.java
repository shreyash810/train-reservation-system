package com.tcs.poweredge.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcs.poweredge.model.Payment;
import com.tcs.poweredge.model.enums.ModeOfPayment;
import com.tcs.poweredge.model.enums.TransactionStatus;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {

    // --- Uniqueness / lookups ---
    Optional<Payment> findByTransactionId(String transactionId);
    boolean existsByTransactionId(String transactionId);

    // --- Common filters ---
    List<Payment> findAllByCustomer_CustomerId(Long customerId);
    List<Payment> findAllByBill_BillId(Long billId);
    List<Payment> findAllByTransactionStatus(TransactionStatus status);
    List<Payment> findAllByModeOfPayment(ModeOfPayment mode);

    // --- Date range queries ---
    List<Payment> findAllByTransactionDateBetween(LocalDateTime from, LocalDateTime to);

    // --- Combined filters (useful for reporting / dashboards) ---
    List<Payment> findAllByCustomer_CustomerIdAndTransactionStatus(Long customerId, TransactionStatus status);
    List<Payment> findAllByBill_BillIdAndTransactionStatus(Long billId, TransactionStatus status);
}

