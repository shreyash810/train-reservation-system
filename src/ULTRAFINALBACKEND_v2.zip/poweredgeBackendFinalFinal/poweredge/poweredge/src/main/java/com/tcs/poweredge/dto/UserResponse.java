package com.tcs.poweredge.dto;

import java.time.LocalDateTime;

import com.tcs.poweredge.model.enums.CustomerTypeEnum;
import com.tcs.poweredge.model.enums.ElectricalSectionEnum;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class UserResponse {
    Long userId;
    Long customerID;
    String refinedCustomerId;
    String username;
    String email;
    String fname;
    String lname;
    String address;
    String mobileNumber;
    ElectricalSectionEnum electricalSection;
    String consumerNumber;
    CustomerTypeEnum customerType;
    LocalDateTime createdAt;
    LocalDateTime updatedAt;
}
 
