package com.tcs.poweredge.model.enums;


public enum ComplaintType {
    BILLING_ISSUE,
    POWER_OUTAGE,
    METER_FAULT,
    CONNECTION_REQUEST
}

