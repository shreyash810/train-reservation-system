package com.tcs.poweredge.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tcs.poweredge.model.Bill;
import com.tcs.poweredge.model.enums.ConnectionStatus;
import com.tcs.poweredge.model.enums.ConnectionType;
import com.tcs.poweredge.model.enums.PaymentStatus;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


import java.util.List;
import java.util.Optional;

@Repository
public interface BillRepository extends JpaRepository<Bill, Long> {

    
    /**
     * ADMIN: List bills with optional filters + pagination.
     * Any filter param can be null to ignore that condition.
     *
     * Supported filters:
     * - billId
     * - customerId
     * - billingPeriod (exact "YYYY-MM")
     * - paymentStatus
     * - connectionType
     * - connectionStatus
     */
    @Query("""
           SELECT b
           FROM Bill b
           WHERE (:billId IS NULL OR b.billId = :billId)
             AND (:customerId IS NULL OR b.customer.customerId = :customerId)
             AND (:billingPeriod IS NULL OR b.billingPeriod = :billingPeriod)
             AND (:paymentStatus IS NULL OR b.paymentStatus = :paymentStatus)
             AND (:connectionType IS NULL OR b.connectionType = :connectionType)
             AND (:connectionStatus IS NULL OR b.connectionStatus = :connectionStatus)
           """)
    Page<Bill> findForAdminWithOptionalFilters(
            @Param("billId") Long billId,
            @Param("customerId") Long customerId,
            @Param("billingPeriod") String billingPeriod,
            @Param("paymentStatus") PaymentStatus paymentStatus,
            @Param("connectionType") ConnectionType connectionType,
            @Param("connectionStatus") ConnectionStatus connectionStatus,
            Pageable pageable
    );

    // Get all bills of a customer
    List<Bill> findByCustomer_CustomerId(Long customerId);

    // Get a specific bill but ensure ownership (used for customer role)
    Optional<Bill> findByBillIdAndCustomer_CustomerId(Long billId, Long customerId);

    // Get all bills of a given billing period
    List<Bill> findByBillingPeriod(String billingPeriod);

    // Check if bill already exists for customer + period (avoid duplicates)
    boolean existsByCustomer_CustomerIdAndBillingPeriod(Long customerId, String billingPeriod);
}
