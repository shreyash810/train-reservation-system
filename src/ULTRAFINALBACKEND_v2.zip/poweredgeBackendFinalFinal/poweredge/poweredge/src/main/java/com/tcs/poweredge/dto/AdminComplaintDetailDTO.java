package com.tcs.poweredge.dto;


import lombok.Builder;
import lombok.Value;

import java.time.LocalDateTime;

import com.tcs.poweredge.model.enums.ComplaintCategory;
import com.tcs.poweredge.model.enums.ComplaintStatus;
import com.tcs.poweredge.model.enums.ComplaintType;
import com.tcs.poweredge.model.enums.PreferredContactMethod;

@Value
@Builder
public class AdminComplaintDetailDTO {
    Long complaintId;

    // customer
    Long customerId;
    String customerName;

    // core
    ComplaintType complaintType;
    ComplaintCategory category;
    ComplaintStatus status;
    String description;

    // contact
    PreferredContactMethod preferredContactMethod;
    String contactEmail;
    String contactPhone;

    // audit
    LocalDateTime dateSubmitted;
    LocalDateTime lastUpdatedDate;

    // assignee
    Long assignedToUserId;
    String assignedToUserName;

    // internal notes
    String notes;
}

