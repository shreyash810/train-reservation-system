package com.tcs.poweredge.model;

import java.util.ArrayList;
import java.util.List;

import com.tcs.poweredge.model.enums.CustomerTypeEnum;
import com.tcs.poweredge.model.enums.ElectricalSectionEnum;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(
    name = "customers",
    indexes = {
        @Index(name = "idx_customers_mobile", columnList = "mobileNumber"),
        @Index(name = "idx_customers_section", columnList = "electricalSection")
    }
)
@Data 
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long customerId;

    @Size(max=100)
    private String cousumerNumber;

    @NotBlank
    @Size(max = 100)
    private String fname;

    @NotBlank
    @Size(max = 100)
    private String lname;

    @NotBlank
    @Size(max = 255)
    private String address;

    @NotBlank
    @Size(max = 15)
    @Column(unique = true)
    private String mobileNumber;

    @NotNull
    @Enumerated(EnumType.STRING)
    private ElectricalSectionEnum electricalSection;

    @NotNull
    @Enumerated(EnumType.STRING)
    private CustomerTypeEnum customerType;

    @OneToOne(mappedBy = "customer" , fetch = FetchType.LAZY)
    private User user;

    
    @OneToMany(mappedBy = "customer", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Complaint> complaints = new ArrayList<>();

    @OneToMany(mappedBy = "customer", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Complaint> bills = new ArrayList<>();
    
    @Transient
    public String getRefinedCustomerId() {
        if (customerId == null || customerType == null) {
            return null; // or throw an IllegalStateException if you prefer strict behavior
        }

        final String prefix = switch (customerType) {
            case RESIDENTIAL -> "RES";
            case COMMERCIAL  -> "COM";
            default          -> "CUS"; // Fallback if new types are added later
        };

        // Zero-pad customerId to 6 digits (e.g., 1 -> "000001")
        String numericPart = String.format("%06d", customerId);

        return prefix + numericPart;
    }


}
