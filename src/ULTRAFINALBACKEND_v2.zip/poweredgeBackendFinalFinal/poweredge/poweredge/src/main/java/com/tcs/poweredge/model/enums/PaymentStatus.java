package com.tcs.poweredge.model.enums;


public enum PaymentStatus {
    PAID, UNPAID
}

