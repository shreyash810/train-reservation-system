package com.tcs.poweredge.service;

import org.springframework.stereotype.Service;

import com.tcs.poweredge.dto.ComplaintResponse;
import com.tcs.poweredge.dto.CreateComplaintRequest;
import com.tcs.poweredge.model.Complaint;
import com.tcs.poweredge.model.Customer;
import com.tcs.poweredge.model.User;
import com.tcs.poweredge.model.enums.ComplaintStatus;
import com.tcs.poweredge.model.enums.ComplaintType;
import com.tcs.poweredge.repository.ComplaintRepository;
import com.tcs.poweredge.repository.CustomerRepository;
import com.tcs.poweredge.repository.UserRepository;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


@Service
@RequiredArgsConstructor
public class ComplaintService {
    
    private final ComplaintRepository complaintRepository;
    private final CustomerRepository customerRepository;
    private final UserRepository userRepository;

    
    @Transactional
    public ComplaintResponse createComplaintForCurrentCustomer(String username, CreateComplaintRequest request) {
        // Find the user
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new EntityNotFoundException("User not found: " + username));

        // Ensure this user has a linked Customer
        Customer customer = customerRepository.findByUserUsername(username)
                .orElseThrow(() -> new IllegalStateException("Customer not linked to user: " + username));

        // Build entity
        Complaint complaint = new Complaint();
        complaint.setCustomer(customer);
        complaint.setComplaintType(request.getComplaintType());
        complaint.setDescription(request.getDescription());

        // Optional overrides
        complaint.setContactEmail(request.getContactEmail());
        complaint.setContactPhone(request.getContactPhone());
        complaint.setPreferredContactMethod(request.getPreferredContactMethod());

        // Optional assignee
        if (request.getAssignedToUserId() != null) {
            User assigned = userRepository.findById(request.getAssignedToUserId())
                    .orElseThrow(() -> new EntityNotFoundException("Assignee not found: " + request.getAssignedToUserId()));
            complaint.setAssignedTo(assigned);
        }

        // Save (PrePersist will set category, status, timestamps, defaults)
        Complaint saved = complaintRepository.save(complaint);

        // Prepare response
        return new ComplaintResponse(
                saved.getComplaintId(),
                saved.getComplaintType(),
                saved.getCategory(),
                saved.getDescription(),
                saved.getPreferredContactMethod(),
                saved.getContactEmail(),
                saved.getContactPhone(),
                saved.getStatus(),
                saved.getDateSubmitted(),
                saved.getLastUpdatedDate(),
                customer.getCustomerId(),
                customer.getRefinedCustomerId(),
                saved.getAssignedTo() != null ? saved.getAssignedTo().getId() : null
        );
    }


    
    @Transactional
    public Page<ComplaintResponse> listComplaintsForCurrentCustomer(
            String username,
            Pageable pageable,
            Long complaintId,
            ComplaintStatus status,
            ComplaintType type
    ) {
        Customer customer = customerRepository.findByUserUsername(username)
                .orElseThrow(() -> new IllegalStateException("Customer not linked to user: " + username));

        Page<Complaint> page = complaintRepository.findForCustomerWithOptionalFilters(
                complaintId,customer.getCustomerId(), status, type, pageable
        );

        return page.map(c -> new ComplaintResponse(
                c.getComplaintId(),
                c.getComplaintType(),
                c.getCategory(),
                c.getDescription(),
                c.getPreferredContactMethod(),
                c.getContactEmail(),
                c.getContactPhone(),
                c.getStatus(),
                c.getDateSubmitted(),
                c.getLastUpdatedDate(),
                customer.getCustomerId(),
                customer.getRefinedCustomerId(),
                c.getAssignedTo() != null ? c.getAssignedTo().getId() : null
        ));
    }
    

}
