package com.tcs.poweredge.service;


import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.tcs.poweredge.dto.AdminComplaintDetailDTO;
import com.tcs.poweredge.model.Complaint;
import com.tcs.poweredge.model.User;
import com.tcs.poweredge.model.enums.ComplaintCategory;
import com.tcs.poweredge.model.enums.ComplaintStatus;
import com.tcs.poweredge.model.enums.ComplaintType;
import com.tcs.poweredge.model.enums.UserRoleEnum;
import com.tcs.poweredge.repository.ComplaintRepository;
import com.tcs.poweredge.repository.UserRepository;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;

import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;


@Service
@RequiredArgsConstructor
public class ComplaintListingService {
    
    private final UserRepository userRepository;
    private final ComplaintRepository complaintRepository;

    
@Transactional
    
    public AdminComplaintDetailDTO addNote(Long complaintId, Long actorUserId, String note) {
        Complaint c = loadComplaint(complaintId);
        appendNote(c, String.format("NOTE by user %d at %s: %s", actorUserId, LocalDateTime.now(), note));
        c.setLastUpdatedDate(LocalDateTime.now());
        complaintRepository.save(c);
        return toDetailDto(c);
    }

    @Transactional
     
    public AdminComplaintDetailDTO changeStatus(Long complaintId, Long actorUserId, ComplaintStatus newStatus, String note) {
        Complaint c = loadComplaint(complaintId);
        ComplaintStatus old = c.getStatus();
        // Optional: enforce transition rules
        validateStatusTransition(old, newStatus);

        c.setStatus(newStatus);
        c.setLastUpdatedDate(LocalDateTime.now());

        String transitionNote = String.format("STATUS changed %s -> %s by user %d at %s",
                old, newStatus, actorUserId, LocalDateTime.now());
        appendNote(c, (note == null || note.isBlank()) ? transitionNote : (transitionNote + " | " + note));

        complaintRepository.save(c);
        return toDetailDto(c);
    }

    @Transactional
    public AdminComplaintDetailDTO updateDescription(Long complaintId, Long customerUserId, String newDescription) {
        Complaint c = loadComplaint(complaintId);

        // Ensure the acting user is the owner customer (by linked Customer.user.id)
        Long ownerUserId = c.getCustomer() != null && c.getCustomer().getUser() != null
                ? c.getCustomer().getUser().getId() : null;

        if (ownerUserId == null || !ownerUserId.equals(customerUserId)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You can only edit your own complaint's description.");
        }

        // Optional: restrict editing to certain statuses (e.g., only OPEN)
        if (c.getStatus() != ComplaintStatus.OPEN) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Description can only be changed while complaint is OPEN.");
        }

        c.setDescription(newDescription);
        c.setLastUpdatedDate(LocalDateTime.now());
        appendNote(c, String.format("DESCRIPTION updated by customer %d at %s", customerUserId, LocalDateTime.now()));
        complaintRepository.save(c);

        return toDetailDto(c);
    }

    @Transactional
    public AdminComplaintDetailDTO acceptComplaint(Long complaintId, Long smeUserId) {
        Complaint c = loadComplaint(complaintId);

        if (c.getAssignedTo() != null && !c.getAssignedTo().getId().equals(smeUserId)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Complaint already assigned to another SME.");
        }

        User sme = loadUser(smeUserId);
        c.setAssignedTo(sme);

        // Typical flow: accepting sets IN_PROGRESS
        c.setStatus(ComplaintStatus.IN_PROGRESS);
        c.setLastUpdatedDate(LocalDateTime.now());

        appendNote(c, String.format("ACCEPTED by SME %d at %s; status -> IN_PROGRESS", smeUserId, LocalDateTime.now()));
        complaintRepository.save(c);

        return toDetailDto(c);
    }

    @Transactional
    public AdminComplaintDetailDTO assignComplaint(Long complaintId, Long adminUserId, Long smeUserId) {
        Complaint c = loadComplaint(complaintId);
        User sme = loadUser(smeUserId);

        if(sme.getRole() != UserRoleEnum.SME){
            throw new BadCredentialsException("cant assign to customer");
        }

        c.setAssignedTo(sme);
        c.setLastUpdatedDate(LocalDateTime.now());

        appendNote(c, String.format("ASSIGNED to SME %d by admin %d at %s", smeUserId, adminUserId, LocalDateTime.now()));
        complaintRepository.save(c);

        return toDetailDto(c);
    }

    /* ===== Helpers ===== */

    private Complaint loadComplaint(Long complaintId) {
        return complaintRepository.findWithGraphByComplaintId(complaintId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Invalid complaint id: " + complaintId));
    }

    private User loadUser(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Invalid user id: " + userId));
    }

    private void appendNote(Complaint c, String line) {
        String existing = c.getNotes();
        c.setNotes((existing == null || existing.isBlank()) ? line : (existing + "\n" + line));
    }

    private void validateStatusTransition(ComplaintStatus oldStatus, ComplaintStatus newStatus) {
       
        if (oldStatus == ComplaintStatus.CLOSED && newStatus != ComplaintStatus.CLOSED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Cannot change status from CLOSED.");
        }
    
    }

    
    public Page<AdminComplaintDetailDTO> listForSme(
            Authentication authentication,
            Pageable pageable,
            Long complaintId,
            Long assignedToUserId,
            ComplaintStatus status,
            ComplaintType type,
            ComplaintCategory category,
            LocalDateTime submittedFrom,
            LocalDateTime submittedTo,
            String q
    ) {

        Long effectiveAssigneeId = assignedToUserId;

        Page<Complaint> page = complaintRepository.findForAdminWithOptionalFilters(
                complaintId,
                effectiveAssigneeId,
                status,
                type,
                category,
                submittedFrom,
                submittedTo,
                normalizeQ(q),
                pageable
        );

        return page.map(this::toDetailDto);
    }

    
    @Transactional(readOnly = true)
    public AdminComplaintDetailDTO findByComplaintId(Long complaintId) throws Exception {
        try {
            Complaint c = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new BadCredentialsException("Invalid complaint id: " + complaintId));
        return toDetailDto(c);
        } catch (Exception e) {
           return null;
        }
        
    }


    
    public Page<AdminComplaintDetailDTO> listForAdmin(
            Authentication authentication,
            Pageable pageable,
            Long complaintId,
            Long assignedToUserId,
            ComplaintStatus status,
            ComplaintType type,
            ComplaintCategory category,
            LocalDateTime submittedFrom,
            LocalDateTime submittedTo,
            String q
    ) {
        Page<Complaint> page = complaintRepository.findForAdminWithOptionalFilters(
                complaintId,
                assignedToUserId,
                status,
                type,
                category,
                submittedFrom,
                submittedTo,
                normalizeQ(q),
                pageable
        );

        return page.map(this::toDetailDto);
    }

    private String normalizeQ(String q) {
        return (q == null || q.isBlank()) ? null : q.trim();
    }


    private AdminComplaintDetailDTO toDetailDto(Complaint c) {
        return AdminComplaintDetailDTO.builder()
                .complaintId(c.getComplaintId())

                .customerId(c.getCustomer() != null ? c.getCustomer().getCustomerId() : null)
                .customerName(c.getCustomer() != null ? safeCustomerName(c) : null)

                .complaintType(c.getComplaintType())
                .category(c.getCategory())
                .status(c.getStatus())
                .description(c.getDescription())

                .preferredContactMethod(c.getPreferredContactMethod())
                .contactEmail(c.getContactEmail())
                .contactPhone(c.getContactPhone())

                .dateSubmitted(c.getDateSubmitted())
                .lastUpdatedDate(c.getLastUpdatedDate())

                .assignedToUserId(c.getAssignedTo() != null ? c.getAssignedTo().getId() : null)
                .assignedToUserName(c.getAssignedTo() != null ? safeAssigneeName(c) : null)

                .notes(c.getNotes())
                .build();
    }

    private String safeCustomerName(Complaint c) {
        return c.getCustomer().getUser().getUsername();
    }

    private String safeAssigneeName(Complaint c) {
         return c.getAssignedTo().getUsername();
    }

}
