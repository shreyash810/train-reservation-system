package com.tcs.poweredge.service;


import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.poweredge.dto.PaymentCreateRequest;
import com.tcs.poweredge.dto.PaymentResponse;
import com.tcs.poweredge.model.Bill;
import com.tcs.poweredge.model.Customer;
import com.tcs.poweredge.model.Payment;
import com.tcs.poweredge.model.User;
import com.tcs.poweredge.model.enums.PaymentStatus;
import com.tcs.poweredge.repository.BillRepository;
import com.tcs.poweredge.repository.CustomerRepository;
import com.tcs.poweredge.repository.PaymentRepository;
import com.tcs.poweredge.repository.UserRepository;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final BillRepository billRepository;
    private final CustomerRepository customerRepository;
    private final UserRepository userRepository;

    @Transactional
    public PaymentResponse createPayment(PaymentCreateRequest request, Long userId) throws Exception {
        User user = userRepository.findById(userId).orElseThrow(()->new Exception("unknown exception"));
        Long customerId = user.getCustomer().getCustomerId();

        // Check duplicate transactionId (nice error before DB constraint)
        if (paymentRepository.existsByTransactionId(request.getTransactionId())) {
            throw new IllegalArgumentException("transactionId already exists: " + request.getTransactionId());
        }

        // Load bill and customer
        Bill bill = billRepository.findById(request.getBillId())
                .orElseThrow(() -> new IllegalArgumentException("Bill not found: " + request.getBillId()));

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("Customer not found: " + customerId));

       

        // Map DTO -> Entity (timestamps handled by @PrePersist in entity)
        Payment payment = Payment.builder()
                .transactionId(request.getTransactionId())
                .transactionDate(request.getTransactionDate()) // can be null
                .transactionAmount(request.getTransactionAmount())
                .transactionStatus(request.getTransactionStatus())
                .modeOfPayment(request.getModeOfPayment())
                .bill(bill)
                .customer(customer)
                .build();
        
        


        try {
            Payment saved = paymentRepository.save(payment);
            bill.setDueAmount(new BigDecimal(0));
            
            LocalDate paidDate = (saved.getTransactionDate() != null)
                    ? saved.getTransactionDate().atZone(ZoneId.of("UTC")).toLocalDate()
                    : LocalDate.now(ZoneId.of("UTC"));
            bill.setPaymentDate(paidDate);

            bill.setPaymentStatus(PaymentStatus.PAID);
            billRepository.save(bill);
            return toResponse(saved);
        } catch (DataIntegrityViolationException e) {
            // Handles race conditions on unique(transaction_id)
            throw new IllegalArgumentException("transactionId already exists: " + request.getTransactionId());
        }
    }

    private PaymentResponse toResponse(Payment p) {
        return PaymentResponse.builder()
                .paymentId(p.getPaymentId())
                .transactionId(p.getTransactionId())
                .transactionDate(p.getTransactionDate())
                .transactionAmount(p.getTransactionAmount())
                .transactionStatus(p.getTransactionStatus())
                .modeOfPayment(p.getModeOfPayment())
                .billId(p.getBill().getBillId())
                .customerId(p.getCustomer().getCustomerId())
                .createdAt(p.getCreatedAt())
                .build();
    }
}
