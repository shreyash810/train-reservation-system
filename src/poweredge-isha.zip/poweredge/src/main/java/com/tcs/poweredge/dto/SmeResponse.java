package com.tcs.poweredge.dto;


import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SmeResponse {
    private Long employeeId;
    private String fname;
    private String lname;
    private String mobileNumber;
    private Long userId;
    private String userEmail;
}
