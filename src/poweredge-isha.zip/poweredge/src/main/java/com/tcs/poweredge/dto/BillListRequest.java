package com.tcs.poweredge.dto;

import com.tcs.poweredge.model.enums.ConnectionStatus;
import com.tcs.poweredge.model.enums.ConnectionType;
import com.tcs.poweredge.model.enums.PaymentStatus;

import jakarta.validation.constraints.Pattern;
import lombok.*;

/**
 * Request DTO for "list bills" API (CUSTOMER/ADMIN/SME variants).
 * Pagination will be handled via Spring's Pageable in the controller.
 * All filters are optional (nullable).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BillListRequest {

    // Optional: for ADMIN/SME use-cases, or if you want to scope explicitly.
    private Long customerId;

    // Optional filters
    private Long billId;

    // Exact "YYYY-MM" format (e.g., 2025-12)
    @Pattern(regexp = "^[0-9]{4}-[0-9]{2}$", message = "billingPeriod must be in 'YYYY-MM' format")
    private String billingPeriod;

    private PaymentStatus paymentStatus;
    private ConnectionType connectionType;
    private ConnectionStatus connectionStatus;
}

