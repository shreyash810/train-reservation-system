package com.tcs.poweredge.repository;


import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import org.springframework.stereotype.Repository;

import com.tcs.poweredge.model.Complaint;
import com.tcs.poweredge.model.enums.ComplaintCategory;
import com.tcs.poweredge.model.enums.ComplaintStatus;
import com.tcs.poweredge.model.enums.ComplaintType;

@Repository
public interface ComplaintRepository extends JpaRepository<Complaint,Long> {
    
    
    @EntityGraph(attributePaths = {"customer", "customer.user", "assignedTo"})
    Optional<Complaint> findWithGraphByComplaintId(Long complaintId);
    
   
    @Query("""
            SELECT c
            FROM Complaint c
            WHERE c.customer.customerId = :customerId
            AND (:complaintId IS NULL OR c.complaintId = :complaintId)
            AND (:status IS NULL OR c.status = :status)
            AND (:type IS NULL OR c.complaintType = :type)
        """)
    Page<Complaint> findForCustomerWithOptionalFilters(
        @Param("complaintId") Long complaintId,
        @Param("customerId") Long customerId,
        @Param("status") ComplaintStatus status,
        @Param("type") ComplaintType type,
        Pageable pageable
    );

    
    @EntityGraph(attributePaths = {"customer", "assignedTo"})
    @Query("""
        SELECT c
        FROM Complaint c
        WHERE (:complaintId IS NULL OR c.complaintId = :complaintId)
          AND (:assignedTo IS NULL OR c.assignedTo.id = :assignedTo)
          AND (:status IS NULL OR c.status = :status)
          AND (:type IS NULL OR c.complaintType = :type)
          AND (:category IS NULL OR c.category = :category)
          AND (:submittedFrom IS NULL OR c.dateSubmitted >= :submittedFrom)
          AND (:submittedTo IS NULL OR c.dateSubmitted <= :submittedTo)
          AND (
              :q IS NULL OR
              LOWER(c.description) LIKE CONCAT('%', LOWER(:q), '%') OR
              LOWER(c.contactEmail) LIKE CONCAT('%', LOWER(:q), '%') OR
              LOWER(c.contactPhone) LIKE CONCAT('%', LOWER(:q), '%')
          )
        """)
    Page<Complaint> findForAdminWithOptionalFilters(
            @Param("complaintId") Long complaintId,
            @Param("assignedTo") Long assignedTo,
            @Param("status") ComplaintStatus status,
            @Param("type") ComplaintType type,
            @Param("category") ComplaintCategory category,
            @Param("submittedFrom") LocalDateTime submittedFrom,
            @Param("submittedTo") LocalDateTime submittedTo,
            @Param("q") String q,
            Pageable pageable
    );

}
