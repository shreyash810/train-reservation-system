package com.tcs.poweredge.service;
 
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.poweredge.dto.AuthResponse;
import com.tcs.poweredge.dto.LoginRequest;
import com.tcs.poweredge.dto.RegisterRequest;
import com.tcs.poweredge.dto.UserResponse;
import com.tcs.poweredge.mapper.CustomerMapper;
import com.tcs.poweredge.mapper.UserMapper;
import com.tcs.poweredge.model.Customer;
import com.tcs.poweredge.model.User;
import com.tcs.poweredge.model.enums.UserRoleEnum;
import com.tcs.poweredge.repository.CustomerRepository;
import com.tcs.poweredge.repository.UserRepository;
import com.tcs.poweredge.security.JwtService;
import com.tcs.poweredge.security.UserDetailsImpl;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor

public class AuthService {
    
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private final CustomerRepository customerRepository;
    private final UserMapper userMapper;
    private final CustomerMapper customerMapper;

    
    @Transactional
    public UserResponse register(RegisterRequest request) {
        // Normalize input (trim, lower-case email)
        String username = request.getUsername().trim();
        String email = request.getEmail().trim().toLowerCase();
        String rawPassword = request.getPassword();

        // Basic validations
        if (username.isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty");
        }
        if (email.isEmpty()) {
            throw new IllegalArgumentException("Email cannot be empty");
        }
        if (rawPassword == null || rawPassword.length() < 8) {
            throw new IllegalArgumentException("Password must be at least 8 characters");
        }

        // Uniqueness checks
        if (userRepository.existsByUsername(username)) {
            throw new IllegalArgumentException("Username is already taken");
        }
        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("Email is already registered");
        }
        if(customerRepository.existsByMobileNumber(request.getMobileNumber())){
            throw new IllegalArgumentException("Mob is already registered");
        }

        // Hash the password
        // after spring security we will do this
        String hashedPassword = passwordEncoder.encode(rawPassword);

        // Build and persist user
        User user = userMapper.toEntity(request);
        user.setPassword(hashedPassword);
        user.setRole(UserRoleEnum.CUSTOMER);

        Customer customer = customerMapper.toEntity(request);
        Customer savedCustomer = customerRepository.save(customer);

        user.setCustomer(savedCustomer);
        User savedUser = userRepository.saveAndFlush(user);  // Changed: use saveAndFlush to ensure FK is persisted

        UserResponse response = userMapper.toDto(savedUser, savedCustomer);
        return response;
    }

    @Transactional
    public AuthResponse login(LoginRequest request){
        // Authenticate username/password
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword()
                )
        );

        // Store authentication in the SecurityContext (stateless JWT still benefits downstream)
        SecurityContextHolder.getContext().setAuthentication(authentication);

        if (authentication.isAuthenticated()) {
            UserDetailsImpl user = (UserDetailsImpl) authentication.getPrincipal();
            String token = jwtService.generateToken(user);
            String role = userRepository.findByUsername(user.getUsername()).orElseThrow(()->new BadCredentialsException("Invalid username or password")).getRole().toString();
            return new AuthResponse(token,role,user.getUsername(),user.getId());
        } else {
            // Authentication object present but not authenticated
            throw new BadCredentialsException("Invalid username or password");
        }
    }

    public boolean isUserExist(String username){
        return userRepository.existsByUsername(username);
    }
}
