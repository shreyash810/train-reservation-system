package com.tcs.poweredge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoweredgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PoweredgeApplication.class, args);
	}

}
