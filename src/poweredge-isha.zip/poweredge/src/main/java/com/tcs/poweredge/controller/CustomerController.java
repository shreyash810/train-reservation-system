
package com.tcs.poweredge.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.RequestParam;

import com.tcs.poweredge.dto.CustomerListingResponse;
import com.tcs.poweredge.model.enums.CustomerTypeEnum;
import com.tcs.poweredge.model.enums.ElectricalSectionEnum;
import com.tcs.poweredge.service.CustomerListingService;

@RestController
@RequestMapping("/api/admin")
public class CustomerController {

    private final CustomerListingService customerListingService;

    public CustomerController(CustomerListingService customerListingService) {
        this.customerListingService = customerListingService;
    }

    /**
     * List customers with optional filters and pagination.
     *
     * Examples:
     *  GET /customers
     *  GET /customers?electricalSection=SECTION_A
     *  GET /customers?customerType=RESIDENTIAL
     *  GET /customers?electricalSection=SECTION_A&customerType=COMMERCIAL&page=0&size=20&sort=fname,asc
     */
    @GetMapping("/listcustomers")
    @PreAuthorize("hasRole('ADMIN')")
    public Page<CustomerListingResponse> getCustomers(
            @RequestParam(name = "electricalSection", required = false) ElectricalSectionEnum electricalSection,
            @RequestParam(name = "customerType", required = false) CustomerTypeEnum customerType,
            @PageableDefault(size = 20) Pageable pageable
    ) {
        if (electricalSection != null && customerType != null) {
            return customerListingService.getCustomersByElectricalSectionAndCustomerType(
                    electricalSection, customerType, pageable);
        } else if (electricalSection != null) {
            return customerListingService.getCustomersByElectricalSection(electricalSection, pageable);
        } else if (customerType != null) {
            return customerListingService.getCustomersByCustomerType(customerType, pageable);
        } else {
            return customerListingService.getCustomers(pageable);
        }
    }
}
