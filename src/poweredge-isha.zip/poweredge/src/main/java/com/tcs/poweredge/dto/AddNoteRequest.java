package com.tcs.poweredge.dto;
 

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class AddNoteRequest {

    @NotBlank
    private String note;
}


