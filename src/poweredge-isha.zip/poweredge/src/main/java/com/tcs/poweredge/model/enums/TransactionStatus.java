package com.tcs.poweredge.model.enums;


public enum TransactionStatus {
    SUCCESS, FAILED, PENDING
}

