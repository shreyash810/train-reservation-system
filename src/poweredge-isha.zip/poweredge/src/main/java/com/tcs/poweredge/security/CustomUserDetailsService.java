
package com.tcs.poweredge.security;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import com.tcs.poweredge.repository.UserRepository;
import com.tcs.poweredge.model.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    public CustomUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository
                .findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

        // Ensure role prefix for Spring Security conventions
        String authority = "ROLE_" + user.getRole().name();

        // Option 1: Use Spring's built-in User
        // return org.springframework.security.core.userdetails.User
        //         .withUsername(user.getUsername())
        //         .password(user.getPassword())
        //         .authorities(authority)
        //         .build();

       
        return UserDetailsImpl.fromDomainUser(user);
    }
}
