package com.tcs.poweredge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PoweredgeApplicationTests {

	@Test
	void contextLoads() {
	}

}
